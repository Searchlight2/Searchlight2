##---- general libraries ----##
library(ggplot2)
library(reshape)

##---- de sample and group names ----##
samples = c("WT_R1","WT_R2","WT_R3","KO_R1","KO_R2","KO_R3")
sample_groups = c("WT","KO")
sample_groupings = c("WT","WT","WT","KO","KO","KO")
sample_groupings = factor(sample_groupings, levels = sample_groups)
samples_by_sample_group = list(c("WT_R1","WT_R2","WT_R3"),c("KO_R1","KO_R2","KO_R3"))
comparisons = c("KO vs WT")

##---- sets the working directory. If you move the SL2 folder please update this path ----##
setwd("/home/john/Downloads/TEMP/DESEQ2/results/all_genes/de_workflows/KO_vs_WT")

##---- IPA upstream regulator activation and enrichment files ----##
TRUSST_all_gene_sets = read.table(file="data/statistical_analysis/upstream_regulator_analysis/TRUSST/all_uregs_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
TRUSST_enriched_gene_sets = read.table(file="data/statistical_analysis/upstream_regulator_analysis/TRUSST/enriched_uregs_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
TRUSST_activated_gene_sets = read.table(file="data/statistical_analysis/upstream_regulator_analysis/TRUSST/activated_uregs_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
TRUSST_enriched_and_activated_gene_sets = read.table(file="data/statistical_analysis/upstream_regulator_analysis/TRUSST/enriched_and_activated_uregs_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)

##---- SL2 Theme ----##
theme_SL2 <- function () { 
    theme_bw() %+replace% 
        theme(
	    panel.grid = element_blank(),
            panel.background = element_blank(),
            panel.border = element_rect(colour = "black", fill=NA, size=1),
            plot.background = element_blank(), 
            legend.background = element_rect(fill="transparent", colour=NA),
            legend.key = element_rect(fill="transparent", colour=NA),
            plot.title = element_text(size=16, margin = margin(b = 5),hjust=0,vjust=0.5, family="Arial", face="bold"),
            title = element_text(size = 16, margin = margin(b = 5),hjust=0,vjust=0.5, family="Arial", face="bold"),
            axis.text.y = element_text(size = 14, margin = margin(r = 5),hjust=1,vjust=0.5, family="Arial", face="bold",colour="black"),
            axis.text.x = element_text(size = 14, margin = margin(t = 5),hjust=0.5,vjust=1, family="Arial", face="bold",colour="black"), 
            axis.title.y = element_text(size = 16, margin = margin(r = 10),angle = 90,hjust=0.5,vjust=0.5, family="Arial", face="bold"),
            axis.title.x = element_text(size = 16, margin = margin(t = 10),hjust=0.5,vjust=1, family="Arial", face="bold"),
            legend.text=element_text(size=14, family="Arial", face="bold"),
            legend.title=element_blank(), 
            legend.key.size=unit(2.5,"line"),
            plot.margin=unit(c(0.4,0.4,0.4,0.4), "cm")
        )
}

##---- Default Sig and Non-sig Colours  ----##
default_significant_colour = "red"
default_non_significant_colour = "black"

##---- Save Plot Function -----##
save_plot <- function(ggp,plot_height,plot_width,plot_path)
{
  png(plot_path, height=plot_height, width=plot_width, pointsize=5)
  print(ggp)
  dev.off()

  # clears all devices - as a safety measure
  while (dev.cur()>1) dev.off()
}

##---- Top 10 IPA Upstream Regulators Function ----##
get_top10_ura_function <- function(upstream_regulators,significant_upstream_regulators,type) {

  if(type=="enriched")
  {
    top_10_upstream_regulators = head(upstream_regulators[order(upstream_regulators$enrichment_p_value,decreasing=FALSE),],10)
    top_10_upstream_regulators = top_10_upstream_regulators[,c("upstream_regulator","enrichment_p_value","overlapping_genes","log2_fold_enrichment","overlapping_gene_names")]
    top_10_upstream_regulators$significant = top_10_upstream_regulators$upstream_regulator %in% significant_upstream_regulators$upstream_regulator
    top_10_upstream_regulators$significant = as.character(top_10_upstream_regulators$significant)
    colnames(top_10_upstream_regulators) = c("gene_set","p","overlapping_genes","log2_fold_enrichment","overlapping_gene_names","significant")
    return(top_10_upstream_regulators)
  }
  if (type=="activated") 
  {
    top_10_upstream_regulators = head(upstream_regulators[order(upstream_regulators$activation_zscore,decreasing=TRUE),],10)
  }
  if (type=="inhibited") 
  {
    top_10_upstream_regulators = head(upstream_regulators[order(upstream_regulators$activation_zscore,decreasing=FALSE),],10)
  }
  top_10_upstream_regulators = top_10_upstream_regulators[,c("upstream_regulator","activation_zscore","genes_activated","genes_inhibited","activated_gene_names","inhibited_gene_names")]
  top_10_upstream_regulators$significant = top_10_upstream_regulators$upstream_regulator %in% significant_upstream_regulators$upstream_regulator
  top_10_upstream_regulators$significant = as.character(top_10_upstream_regulators$significant)
  colnames(top_10_upstream_regulators) = c("upstream_regulator","activation_zscore","genes_activated","genes_inhibited","activated_gene_names","inhibited_gene_names","significant")
  return(top_10_upstream_regulators)
}

##----- Hypergeometric Gene Sets Bar Chart Function -----##
make_oras_bar_chart <- function(top_10_gene_sets,x_axis_label,y_axis_label,non_significant_colour,significant_colour,bar_outline_size,bar_transparency,legend_position,significant_name,non_significant_name,data_label_size)
{ 
  top_10_gene_sets <- top_10_gene_sets[seq(dim(top_10_gene_sets)[1],1),]
  n_sig = nrow(subset(top_10_gene_sets,significant == "TRUE"))
  n_non_sig = nrow(subset(top_10_gene_sets,significant == "FALSE"))
  

  if (n_sig+n_non_sig == 0)
  {
    ggp = ggplot(data.frame()) + theme_SL2() + geom_blank() + ggtitle("There were too few gene sets sensibly plot this.")
  }
  else if (n_sig == 0)
  {
      ggp = ggplot(data=top_10_gene_sets , aes(x=gene_set, y=-log10(p), fill=significant,group=significant)) + geom_bar(colour="black",stat="identity", position = "dodge", alpha = bar_transparency) + coord_flip() + scale_x_discrete(limits = top_10_gene_sets$gene_set) + ylab(x_axis_label)  + xlab(y_axis_label) + scale_fill_manual(values=c(non_significant_colour),breaks=c("FALSE"),labels=c(non_significant_name)) + theme_SL2() + theme(axis.text.y = element_text(hjust=1),legend.position=legend_position, legend.spacing.x = unit(0.15, 'cm')) + scale_y_continuous(expand=c(0,0), limits=c(0,max(-log10(top_10_gene_sets$p)*1.25))) + geom_text(aes(label=overlapping_genes), position=position_dodge(width=0.9), size=data_label_size, show.legend = FALSE, hjust=-0.5)
  }
  else if (n_non_sig == 0)
  {
      ggp = ggplot(data=top_10_gene_sets , aes(x=gene_set, y=-log10(p), fill=significant,group=significant)) + geom_bar(colour="black",stat="identity", position = "dodge", alpha = bar_transparency) + coord_flip() + scale_x_discrete(limits = top_10_gene_sets$gene_set) + ylab(x_axis_label)  + xlab(y_axis_label) + scale_fill_manual(values=c(significant_colour),breaks=c("TRUE"),labels=c(significant_name)) + theme_SL2() + theme(axis.text.y = element_text(hjust=1),legend.position=legend_position, legend.spacing.x = unit(0.15, 'cm')) + scale_y_continuous(expand=c(0,0), limits=c(0,max(-log10(top_10_gene_sets$p)*1.25))) + geom_text(aes(label=overlapping_genes), position=position_dodge(width=0.9), size=data_label_size, show.legend = FALSE, hjust=-0.5)
  }
  else if (n_sig != 10 && n_non_sig != 0 && n_sig != 0 && n_non_sig != 10)
  {
      ggp = ggplot(data=top_10_gene_sets , aes(x=gene_set, y=-log10(p), fill=significant,group=significant)) + geom_bar(colour="black",stat="identity", position = "dodge", alpha = bar_transparency) + coord_flip() + scale_x_discrete(limits = top_10_gene_sets$gene_set) + ylab(x_axis_label)  + xlab(y_axis_label) + scale_fill_manual(values=c(non_significant_colour,significant_colour),breaks=c("TRUE","FALSE"),labels=c(significant_name, non_significant_name)) + theme_SL2() + theme(axis.text.y = element_text(hjust=1),legend.position=legend_position, legend.spacing.x = unit(0.15, 'cm')) + scale_y_continuous(expand=c(0,0), limits=c(0,max(-log10(top_10_gene_sets$p)*1.25))) + geom_text(aes(label=overlapping_genes), position=position_dodge(width=0.9), size=data_label_size, show.legend = FALSE, hjust=-0.5)
  }
  return(ggp)
}

##----- IPA Upstream Regulators Bar Chart Function -----##
make_ura_bar_chart <- function(top_10_upstream_regulators,x_axis_label,y_axis_label,non_significant_colour,significant_colour,bar_outline_size,bar_transparency,legend_position,significant_name,non_significant_name,data_label_size, direction)
{ 
  top_10_upstream_regulators <- top_10_upstream_regulators[seq(dim(top_10_upstream_regulators)[1],1),]
  n_sig = nrow(subset(top_10_upstream_regulators,significant == "TRUE"))
  n_non_sig = nrow(subset(top_10_upstream_regulators,significant == "FALSE"))
  
  if (direction=="activated") 
  {
  limits = c(0,max(top_10_upstream_regulators$activation_zscore*1.25))
  data_label_just = -0.5
  }
  if (direction=="inhibited") 
  {
  limits = c(min(top_10_upstream_regulators$activation_zscore*1.25),0)
  data_label_just = 1.5
  }
    
  if (n_sig+n_non_sig == 0)
  {
    ggp = ggplot(data.frame()) + theme_SL2() + geom_blank() + ggtitle("There were too few gene sets sensibly plot this.")
  }
  else if (n_sig == 0)
  {
      ggp = ggplot(data=top_10_upstream_regulators , aes(x=upstream_regulator, y=activation_zscore, fill=significant,group=significant)) + geom_bar(colour="black",stat="identity", position = "dodge", alpha = bar_transparency) + coord_flip() + scale_x_discrete(limits = top_10_upstream_regulators$upstream_regulator) + ylab(x_axis_label)  + xlab(y_axis_label) + scale_fill_manual(values=c(non_significant_colour),breaks=c("FALSE"),labels=c(non_significant_name)) + theme_SL2() + theme(axis.text.y = element_text(hjust=1),legend.position=legend_position, legend.spacing.x = unit(0.15, 'cm')) + scale_y_continuous(expand=c(0,0), limits=limits) + geom_text(aes(label=genes_activated+genes_inhibited), position=position_dodge(width=0.9), size=data_label_size, show.legend = FALSE, hjust=data_label_just)
  }
  else if (n_non_sig == 0)
  {
      ggp = ggplot(data=top_10_upstream_regulators , aes(x=upstream_regulator, y=activation_zscore, fill=significant,group=significant)) + geom_bar(colour="black",stat="identity", position = "dodge", alpha = bar_transparency) + coord_flip() + scale_x_discrete(limits = top_10_upstream_regulators$upstream_regulator) + ylab(x_axis_label)  + xlab(y_axis_label) + scale_fill_manual(values=c(significant_colour),breaks=c("TRUE"),labels=c(significant_name)) + theme_SL2() + theme(axis.text.y = element_text(hjust=1),legend.position=legend_position, legend.spacing.x = unit(0.15, 'cm')) + scale_y_continuous(expand=c(0,0), limits=limits) + geom_text(aes(label=genes_activated+genes_inhibited), position=position_dodge(width=0.9), size=data_label_size, show.legend = FALSE, hjust=data_label_just)
  }
  if (n_sig != 10 && n_non_sig != 0 && n_sig != 0 && n_non_sig != 10)
  {
      ggp = ggplot(data=top_10_upstream_regulators , aes(x=upstream_regulator, y=activation_zscore, fill=significant,group=significant)) + geom_bar(colour="black",stat="identity", position = "dodge", alpha = bar_transparency) + coord_flip() + scale_x_discrete(limits = top_10_upstream_regulators$upstream_regulator) + ylab(x_axis_label)  + xlab(y_axis_label) + scale_fill_manual(values=c(non_significant_colour,significant_colour),breaks=c("TRUE","FALSE"),labels=c(significant_name, non_significant_name)) + theme_SL2() + theme(axis.text.y = element_text(hjust=1),legend.position=legend_position, legend.spacing.x = unit(0.15, 'cm')) + scale_y_continuous(expand=c(0,0), limits=limits) + geom_text(aes(label=genes_activated+genes_inhibited), position=position_dodge(width=0.9), size=data_label_size, show.legend = FALSE, hjust=data_label_just)
  }
  return(ggp)
}

##----- IPA Upstream Regulators (Barcharts) -----##

plot_height = 350
plot_width = 500
x_axis_label = "-log10 p-value"
y_axis_label = ""
non_significant_colour = default_non_significant_colour
significant_colour = default_significant_colour
bar_outline_size = 1
bar_transparency = 0.75
legend_position = "bottom"
data_label_size = 5
significant_name = "significant"
non_significant_name = "non-significant"

top_10_upstream_regulators = get_top10_ura_function(TRUSST_all_gene_sets,TRUSST_enriched_gene_sets,"enriched")
ggp = make_oras_bar_chart(top_10_upstream_regulators,x_axis_label,y_axis_label,non_significant_colour,significant_colour,bar_outline_size,bar_transparency,legend_position,significant_name,non_significant_name,data_label_size)
save_plot(ggp,plot_height,plot_width,"plots/upstream_regulator_analysis/TRUSST/enriched/enriched_upstream_regulators_bar_chart.png")

x_axis_label = "activation z-score"
significant_name = "activated"
non_significant_name = "not-activated"

top_10_upstream_regulators = get_top10_ura_function(TRUSST_all_gene_sets,TRUSST_activated_gene_sets, "activated")
ggp = make_ura_bar_chart(top_10_upstream_regulators,x_axis_label,y_axis_label,non_significant_colour,significant_colour,bar_outline_size,bar_transparency,legend_position,significant_name,non_significant_name,data_label_size, "activated")
save_plot(ggp,plot_height,plot_width,"plots/upstream_regulator_analysis/TRUSST/activated/activated_upstream_regulators_bar_chart.png")

x_axis_label = "activation z-score"
significant_name = "inhibited"
non_significant_name = "not-inhibited"

top_10_upstream_regulators = get_top10_ura_function(TRUSST_all_gene_sets,TRUSST_activated_gene_sets, "inhibited")
ggp = make_ura_bar_chart(top_10_upstream_regulators,x_axis_label,y_axis_label,non_significant_colour,significant_colour,bar_outline_size,bar_transparency,legend_position,significant_name,non_significant_name,data_label_size, "inhibited")
save_plot(ggp,plot_height,plot_width,"plots/upstream_regulator_analysis/TRUSST/inhibited/inhibited_upstream_regulators_bar_chart.png")


