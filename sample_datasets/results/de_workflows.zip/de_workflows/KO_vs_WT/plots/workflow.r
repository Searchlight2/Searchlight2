###################################
##         Searchlight 2         ##
###################################



#############################
##      de workflow       ##
#############################



##-------------------------##
##       R libraries       ##
##-------------------------##



##---- general libraries ----##
library(ggplot2)
library(reshape)


##---- heatmap libraries ----##
library(amap)


##---- table libraries ----##
library(grid)
library(gridExtra)
library(gtable)


##---- network libraries ----##
library(GGally)
library(network)
library(sna)



##-------------------------##
##     Core Parameters     ##
##-------------------------##



##---- de sample and group names ----##
samples = c("WT_R1","WT_R2","WT_R3","KO_R1","KO_R2","KO_R3")
sample_groups = c("WT","KO")
sample_groupings = c("WT","WT","WT","KO","KO","KO")
sample_groupings = factor(sample_groupings, levels = sample_groups)
samples_by_sample_group = list(c("WT_R1","WT_R2","WT_R3"),c("KO_R1","KO_R2","KO_R3"))
comparisons = c("KO vs WT")



##-------------------------##
##       Input Files       ##
##-------------------------##



##---- sets the working directory. If you move the SL2 folder please update this path ----##
setwd("/home/john/Downloads/TEMP/DESEQ2/results/all_genes/de_workflows/KO_vs_WT")


##---- de input files ----##
de_annotated = read.table(file="data/de_annotated.csv", header=TRUE,row.names = 2, sep='\t', quote='',check.names = TRUE)
de_annotated_sig = read.table(file="data/de_annotated_significant.csv", header=TRUE,row.names = 2, sep='\t', quote='',check.names = TRUE)


##---- spatial analysis input files ----##
spatial_enrichment_summary = read.table(file="data/statistical_analysis/spatial_enrichment/spatial_enrichment_summary.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
spatial_enrichment_gene_data = read.table(file="data/statistical_analysis/spatial_enrichment/spatial_enrichment_gene_data.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)


##---- de hypergeometric gene set enrichment files ----##
GO_BP_all_gene_sets = read.table(file="data/statistical_analysis/over_representation_analysis/GO_BP/all_significant_genes/all_gene_sets_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
GO_BP_all_signficant_genes_enriched_gene_sets = read.table(file="data/statistical_analysis/over_representation_analysis/GO_BP/all_significant_genes/enriched_gene_sets_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
GO_BP_all_signficant_genes_underenriched_gene_sets = read.table(file="data/statistical_analysis/over_representation_analysis/GO_BP/all_significant_genes/underenriched_gene_sets_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
GO_BP_upregulated_gene_sets = read.table(file="data/statistical_analysis/over_representation_analysis/GO_BP/upregulated_genes/all_gene_sets_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
GO_BP_upregulated_enriched_gene_sets = read.table(file="data/statistical_analysis/over_representation_analysis/GO_BP/upregulated_genes/enriched_gene_sets_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
GO_BP_upregulated_underenriched_gene_sets = read.table(file="data/statistical_analysis/over_representation_analysis/GO_BP/upregulated_genes/underenriched_gene_sets_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
GO_BP_downregulated_gene_sets = read.table(file="data/statistical_analysis/over_representation_analysis/GO_BP/downregulated_genes/all_gene_sets_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
GO_BP_downregulated_enriched_gene_sets = read.table(file="data/statistical_analysis/over_representation_analysis/GO_BP/downregulated_genes/enriched_gene_sets_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
GO_BP_downregulated_underenriched_gene_sets = read.table(file="data/statistical_analysis/over_representation_analysis/GO_BP/downregulated_genes/underenriched_gene_sets_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)


##---- de hypergeometric gene set network files ----##
GO_BP_all_significant_gene_sets_nodes = read.table(file="data/statistical_analysis/over_representation_analysis/GO_BP/all_significant_genes/network_data/enriched_gene_sets_nodes.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
GO_BP_all_significant_gene_sets_edges = read.table(file="data/statistical_analysis/over_representation_analysis/GO_BP/all_significant_genes/network_data/enriched_gene_sets_edges.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
GO_BP_upregulated_gene_sets_nodes = read.table(file="data/statistical_analysis/over_representation_analysis/GO_BP/upregulated_genes/network_data/enriched_gene_sets_nodes.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
GO_BP_upregulated_gene_sets_edges = read.table(file="data/statistical_analysis/over_representation_analysis/GO_BP/upregulated_genes/network_data/enriched_gene_sets_edges.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
GO_BP_downregulated_gene_sets_nodes = read.table(file="data/statistical_analysis/over_representation_analysis/GO_BP/downregulated_genes/network_data/enriched_gene_sets_nodes.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
GO_BP_downregulated_gene_sets_edges = read.table(file="data/statistical_analysis/over_representation_analysis/GO_BP/downregulated_genes/network_data/enriched_gene_sets_edges.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)


##---- IPA upstream regulator activation and enrichment files ----##
TRUSST_all_gene_sets = read.table(file="data/statistical_analysis/upstream_regulator_analysis/TRUSST/all_uregs_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
TRUSST_enriched_gene_sets = read.table(file="data/statistical_analysis/upstream_regulator_analysis/TRUSST/enriched_uregs_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
TRUSST_activated_gene_sets = read.table(file="data/statistical_analysis/upstream_regulator_analysis/TRUSST/activated_uregs_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
TRUSST_enriched_and_activated_gene_sets = read.table(file="data/statistical_analysis/upstream_regulator_analysis/TRUSST/enriched_and_activated_uregs_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)


##---- de IPA UREG network files ----##
TRUSST_enriched_ura_nodes = read.table(file="data/statistical_analysis/upstream_regulator_analysis/TRUSST/network_data/enriched_uregs_nodes.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
TRUSST_enriched_ura_edges = read.table(file="data/statistical_analysis/upstream_regulator_analysis/TRUSST/network_data/enriched_uregs_edges.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
TRUSST_activated_ura_nodes = read.table(file="data/statistical_analysis/upstream_regulator_analysis/TRUSST/network_data/activated_uregs_nodes.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
TRUSST_activated_ura_edges = read.table(file="data/statistical_analysis/upstream_regulator_analysis/TRUSST/network_data/activated_uregs_edges.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)



##-------------------------##
##       Parsed Data       ##
##-------------------------##



##---- de parse ne matrix ----##
ne_matrix = de_annotated[,samples]
ne_matrix_sig = de_annotated_sig[,samples]


##---- transpose and scale ne matrix ----##
ne_matrix_transposed = data.frame(t(ne_matrix))
colnames(ne_matrix_transposed) = rownames(ne_matrix)

ne_matrix_scaled = data.frame(t(scale(t(ne_matrix))))
rownames(ne_matrix_scaled) = rownames(ne_matrix)
ne_matrix_scaled[do.call(cbind, lapply(ne_matrix_scaled, is.nan))] <- 0
ne_matrix_scaled = ne_matrix_scaled[is.finite(rowSums(ne_matrix_scaled)), ]

ne_matrix_scaled_transposed = data.frame(t(ne_matrix_scaled))
colnames(ne_matrix_scaled_transposed) = rownames(ne_matrix_scaled)


##---- transpose and scale significant genes ne matrix ----##
ne_matrix_sig_scaled = data.frame(t(scale(t(ne_matrix_sig))))
rownames(ne_matrix_sig_scaled) = rownames(ne_matrix_sig)
ne_matrix_sig_scaled[do.call(cbind, lapply(ne_matrix_sig_scaled, is.nan))] <- 0
ne_matrix_sig_scaled = ne_matrix_sig_scaled[is.finite(rowSums(ne_matrix_sig_scaled)), ]



##-------------------------##
##   Default Aesthetics    ##
##-------------------------##



##---- SL2 Theme ----##
theme_SL2 <- function () { 
    theme_bw() %+replace% 
        theme(
	    panel.grid = element_blank(),
            panel.background = element_blank(),
            panel.border = element_rect(colour = "black", fill=NA, size=1),
            plot.background = element_blank(), 
            legend.background = element_rect(fill="transparent", colour=NA),
            legend.key = element_rect(fill="transparent", colour=NA),
            plot.title = element_text(size=16, margin = margin(b = 5),hjust=0,vjust=0.5, family="Arial", face="bold"),
            title = element_text(size = 16, margin = margin(b = 5),hjust=0,vjust=0.5, family="Arial", face="bold"),
            axis.text.y = element_text(size = 14, margin = margin(r = 5),hjust=1,vjust=0.5, family="Arial", face="bold",colour="black"),
            axis.text.x = element_text(size = 14, margin = margin(t = 5),hjust=0.5,vjust=1, family="Arial", face="bold",colour="black"), 
            axis.title.y = element_text(size = 16, margin = margin(r = 10),angle = 90,hjust=0.5,vjust=0.5, family="Arial", face="bold"),
            axis.title.x = element_text(size = 16, margin = margin(t = 10),hjust=0.5,vjust=1, family="Arial", face="bold"),
            legend.text=element_text(size=14, family="Arial", face="bold"),
            legend.title=element_blank(), 
            legend.key.size=unit(2.5,"line"),
            plot.margin=unit(c(0.4,0.4,0.4,0.4), "cm")
        )
}


##----- Default GGplot Colours Function -----##
gg_color_hue <- function(n) {
  hues = seq(15, 375, length = n + 1)
  hcl(h = hues, l = 65, c = 100)[1:n]
}


##---- Default Sample and Sample Group Colours  ----##
number_of_sample_groups = length(sample_groups)
default_sample_group_colours = gg_color_hue(number_of_sample_groups)
default_samples_colours = c(default_sample_group_colours[1],default_sample_group_colours[1],default_sample_group_colours[1],default_sample_group_colours[2],default_sample_group_colours[2],default_sample_group_colours[2])


##---- Default Sample Labels  ----##
default_sample_labels = c("WT_R1","WT_R2","WT_R3","KO_R1","KO_R2","KO_R3") # note: changing this won't change the order the samples appear on the plots. Merely what they are labelled as. 


##---- Default Sample Group Labels  ----##
default_sample_group_labels = c("WT","KO") # note: changing this won't change the order the groups appear on the plots. Merely what they are labelled as.


##---- Default Three Tone Heatmap Colours  ----##
default_three_tone_heatmap_colours = c("blue","pink","red")


##---- Default Sig and Non-sig Colours  ----##
default_significant_colour = "red"
default_non_significant_colour = "black"


##---- Default Two Tone Greyscale  ----##
default_two_tone_greyscale = c("grey75","grey50")


##---- Default Comaparison Labels  ----##
default_comparison_labels = c("KO vs WT") # note: changing this won't change the order the comparisons appear on the plots. Merely what they are labelled as.


##---- Default Two Tone Network Node Colours  ----##
default_two_tone_network_node_colours = c("grey90","red")


##---- Default Network Edge Colour  ----##
default_network_edge_colour = "grey50"


##---- Default Four Tone Network Node Colours  ----##
default_four_tone_network_node_colours_high = c("lightpink","red")
default_four_tone_network_node_colours_low = c("lightskyblue1","blue")



##-------------------------##
##     Helper Functions    ##
##-------------------------##



##---- Save Plot Function -----##
save_plot <- function(ggp,plot_height,plot_width,plot_path)
{
  png(plot_path, height=plot_height, width=plot_width, pointsize=5)
  print(ggp)
  dev.off()

  # clears all devices - as a safety measure
  while (dev.cur()>1) dev.off()
}


##----- Clustering Method -----##
cluster_matrix <- function(mx,cluster_x,cluster_y,distance_method,clustering_method,reorder_function)
{
  x.cluster = hclust(Dist(t(mx), method=distance_method), method=clustering_method)
  y.cluster = hclust(Dist(mx, method=distance_method), method=clustering_method)
  
  x.dd = as.dendrogram(x.cluster)
  y.dd = as.dendrogram(y.cluster)
  x.dd.reorder = reorder(x.dd,0,FUN=reorder_function)
  y.dd.reorder = reorder(y.dd,0,FUN=reorder_function)
  x.order = order.dendrogram(x.dd.reorder)
  y.order = order.dendrogram(y.dd.reorder)

  if(cluster_x == TRUE && cluster_y == TRUE) 
  {
      mx_clustered = mx[y.order,x.order]
  }
  
  if(cluster_x == TRUE && cluster_y == FALSE)
  {
      mx_clustered = mx[,x.order]
  }
  
  if(cluster_x == FALSE && cluster_y == TRUE)
  {
      mx_clustered = mx[y.order,]
  }
  if(cluster_x == FALSE && cluster_y == FALSE) 
  {
      mx_clustered = mx
  }
  return(mx_clustered)
}


##---- Save Table Function -----##
save_table <- function(gt,plot_height,plot_width,plot_path)
{
  png(plot_path, height=plot_height, width=plot_width, pointsize=5)
  grid.arrange(gt)
  dev.off()

  while (dev.cur()>1) dev.off()
}


##---- Top 10 Genes by Mean Expression Function ----##
get_top_10_genes_by_mean_expression <- function(index) {
  samples_in_sample_group = unlist(samples_by_sample_group[index])
  top_10_genes = row.names(head(ne_matrix[order(rowMeans(ne_matrix[,samples_in_sample_group]),decreasing=TRUE),],10))
  return(top_10_genes)
}


##---- Top 10 Differential Genes Function ----##
get_top_10_differential_genes <- function(direction,type) {

  if(type=="log2fold") 
  {
    top_10_genes = row.names(head(de_annotated[order(de_annotated$log2fold,decreasing=direction),],10))
  }
  if(type=="p")
  {
    if (direction == TRUE) {de_annotated_direction = subset(de_annotated,log2fold > 0)}
    else {de_annotated_direction = subset(de_annotated,log2fold < 0)}
    top_10_genes = row.names(head(de_annotated_direction[order(de_annotated_direction$p,decreasing=FALSE),],10))
  }
  return(top_10_genes)
}


##---- Top 10 Gene Sets by Hypergeometric P-value Function ----##
get_top10_oras_by_p_value <- function(gene_sets,enriched_gene_sets,type) {

  if(type=="enrichment")
  {
    top_10_gene_sets = head(gene_sets[order(gene_sets$enrichment_p_value,decreasing=FALSE),],10)
    top_10_gene_sets = top_10_gene_sets[,c("gene_set","enrichment_p_value","overlapping_genes","log2_fold_enrichment","overlapping_gene_names")]
  }
  if(type=="underenrichment")
  {
    top_10_gene_sets = head(gene_sets[order(gene_sets$underenrichment_p_value,decreasing=FALSE),],10)
    top_10_gene_sets = top_10_gene_sets[,c("gene_set","underenrichment_p_value","overlapping_genes","log2_fold_enrichment","overlapping_gene_names")]
  }
  top_10_gene_sets$significant = top_10_gene_sets$gene_set %in% enriched_gene_sets$gene_set
  top_10_gene_sets$significant = as.character(top_10_gene_sets$significant)
  colnames(top_10_gene_sets) = c("gene_set","p","overlapping_genes","log2_fold_enrichment","overlapping_gene_names","significant")
  return(top_10_gene_sets)
}


##---- scale values from 0 to 1 function ----##
range_0_to_1_function <- function(x){(x-min(x))/(max(x)-min(x))}


##---- Top 10 IPA Upstream Regulators Function ----##
get_top10_ura_function <- function(upstream_regulators,significant_upstream_regulators,type) {

  if(type=="enriched")
  {
    top_10_upstream_regulators = head(upstream_regulators[order(upstream_regulators$enrichment_p_value,decreasing=FALSE),],10)
    top_10_upstream_regulators = top_10_upstream_regulators[,c("upstream_regulator","enrichment_p_value","overlapping_genes","log2_fold_enrichment","overlapping_gene_names")]
    top_10_upstream_regulators$significant = top_10_upstream_regulators$upstream_regulator %in% significant_upstream_regulators$upstream_regulator
    top_10_upstream_regulators$significant = as.character(top_10_upstream_regulators$significant)
    colnames(top_10_upstream_regulators) = c("gene_set","p","overlapping_genes","log2_fold_enrichment","overlapping_gene_names","significant")
    return(top_10_upstream_regulators)
  }
  if (type=="activated") 
  {
    top_10_upstream_regulators = head(upstream_regulators[order(upstream_regulators$activation_zscore,decreasing=TRUE),],10)
  }
  if (type=="inhibited") 
  {
    top_10_upstream_regulators = head(upstream_regulators[order(upstream_regulators$activation_zscore,decreasing=FALSE),],10)
  }
  top_10_upstream_regulators = top_10_upstream_regulators[,c("upstream_regulator","activation_zscore","genes_activated","genes_inhibited","activated_gene_names","inhibited_gene_names")]
  top_10_upstream_regulators$significant = top_10_upstream_regulators$upstream_regulator %in% significant_upstream_regulators$upstream_regulator
  top_10_upstream_regulators$significant = as.character(top_10_upstream_regulators$significant)
  colnames(top_10_upstream_regulators) = c("upstream_regulator","activation_zscore","genes_activated","genes_inhibited","activated_gene_names","inhibited_gene_names","significant")
  return(top_10_upstream_regulators)
}



##-------------------------##
##      Plot Functions     ##
##-------------------------##



##----- Distribution of Expression Values Function -----##
make_distribution_of_expression_values_plot <- function(plot_sample,plot_colour,transparency,line_thickness,x_axis_label,y_axis_label,legend_position) 
{
  ggp = ggplot(ne_matrix, aes(log(x=ne_matrix[[plot_sample]]+0.001,10))) + geom_density(colour=plot_colour,fill=plot_colour, alpha=transparency,size=line_thickness) + xlab(x_axis_label) + ylab(y_axis_label) + ggtitle(plot_sample) + theme_SL2() + theme(legend.position=legend_position) + scale_x_continuous(expand=c(0,0)) + scale_y_continuous(expand=c(0,0))
  return(ggp)
}


##----- PCA Contribution of Components Function -----##
make_PCA_contribution_of_components_plot <- function(x_axis_label,y_axis_label,dot_size,dot_transparency,dot_colour,line_type,line_colour,line_size)
{

prcomp_data = prcomp(as.matrix(sapply(ne_matrix_scaled_transposed, as.numeric)))
vars = apply(prcomp_data$x, 2, var)
prcomp_props = data.frame(round(vars / sum(vars),4) * 100)
prcomp_props$PC = row.names(prcomp_props)
colnames(prcomp_props) = c("prop","PC")
prcomp_props$PC = factor(prcomp_props$PC, levels = row.names(prcomp_props))
ggp = ggplot(data=prcomp_props,aes(x=PC,y=prop,group=1)) + geom_line(linetype=line_type,colour=line_colour,size=line_size) + geom_point(size=dot_size,alpha=dot_transparency,colour=dot_colour) + xlab(x_axis_label) + ylab(y_axis_label) + theme_SL2() + theme(legend.position="None", legend.title = element_blank())                                              

return(ggp)
}


##----- PCA Scatter Plot Function -----##
make_PCA_scatterplot <- function(plot_sample_groupings,component_x,component_y,x_axis_label,y_axis_label,plot_sample_group_colours,plot_sample_group_labels,plot_sample_labels,dot_size,dot_transparency,legend_position,sample_label_size,show_proportion_of_variance)
{

  prcomp_data = prcomp(as.matrix(sapply(ne_matrix_scaled_transposed, as.numeric)))
  prcomp_coordinates = data.frame(prcomp_data$x)
    
  if (show_proportion_of_variance == TRUE) 
  {
    vars = apply(prcomp_data$x, 2, var)
    prop_x = round(vars[component_x] / sum(vars),4) * 100
    prop_y = round(vars[component_y] / sum(vars),4) * 100
    
    x_axis_label = paste(x_axis_label, " (",prop_x,"%)",sep="")
    y_axis_label = paste(y_axis_label, " (",prop_y,"%)",sep="")
  }
  
  ggp = ggplot(data=prcomp_coordinates, aes(x=prcomp_coordinates[,component_x], y=prcomp_coordinates[,component_y], colour=plot_sample_groupings, group=plot_sample_groupings,fill=plot_sample_groupings)) + geom_point(size=dot_size,alpha=dot_transparency) + scale_color_manual(values=plot_sample_group_colours,labels=plot_sample_group_labels, breaks=sample_groups) + scale_fill_manual(values=plot_sample_group_colours,labels=plot_sample_group_labels, breaks=sample_groups) + xlab(x_axis_label) + ylab(y_axis_label) + theme_SL2() + theme(legend.position=legend_position, legend.title = element_blank(), legend.spacing.x = unit(0.25, 'cm')) + geom_text(data=prcomp_coordinates,aes(label=plot_sample_labels),hjust=0.5, vjust=-1, size=sample_label_size, show.legend = FALSE) + xlim(c(min(prcomp_coordinates[,component_x])*1.25,max(prcomp_coordinates[,component_x])*1.25)) + ylim(c(min(prcomp_coordinates[,component_y])*1.25,max(prcomp_coordinates[,component_y])*1.25))                                                 
  return(ggp) 
}


##----- Correlation Analysis Heatmap Function  -----##
make_correlation_analysis_heatmap <- function(colours,sample_names,cluster_x,cluster_y,distance_method,clustering_method,reorder_function)
{
  ne_matrix_scaled_correlated = cor(ne_matrix_scaled,method="spearman")
  row.names(ne_matrix_scaled_correlated) = sample_names
  colnames(ne_matrix_scaled_correlated) = sample_names
  
  ne_matrix_scaled_correlated_clustered = cluster_matrix(ne_matrix_scaled_correlated,cluster_x,cluster_y,distance_method,clustering_method,reorder_function)
  ne_matrix_scaled_correlated_clustered_melted <- melt(ne_matrix_scaled_correlated_clustered)
  ne_matrix_scaled_correlated_clustered_melted$X1 = factor(ne_matrix_scaled_correlated_clustered_melted$X1, levels=colnames(ne_matrix_scaled_correlated_clustered))
  ne_matrix_scaled_correlated_clustered_melted$X2 = factor(ne_matrix_scaled_correlated_clustered_melted$X2, levels=row.names(ne_matrix_scaled_correlated_clustered))

  ggp = ggplot(ne_matrix_scaled_correlated_clustered_melted, aes(x = X1, y = X2, fill = value)) + geom_tile() + scale_fill_gradientn(limits=c(-1, 1),colours = colorRampPalette(colours)(100)) + ylab('') + xlab('') + theme_SL2() + theme(legend.position="right", legend.title = element_blank(), legend.spacing.x = unit(0.25, 'cm'),axis.text.x = element_text(angle = 90, hjust = 1), axis.ticks=element_blank()) + scale_x_discrete(expand=c(0,0)) + scale_y_discrete(expand=c(0,0))
  return(ggp)
}


##----- Most Expressed Genes Table Function  -----##
make_most_expressed_genes_table <- function(top_10_genes,header_size,text_size,border_thickness)
{
  ne_matrix_top_10 = ne_matrix[top_10_genes,]
  mean_matrix_top_10 = ne_matrix_top_10[,0]
  mean_matrix_top_10$Gene = rownames(mean_matrix_top_10)
  for (index in 1:length(sample_groups))
  { 
    mean_matrix_top_10[[sample_groups[index]]] = round(rowMeans(ne_matrix_top_10[,unlist(samples_by_sample_group[index])]),2)
  }

  table_theme <- gridExtra::ttheme_minimal(core = list(fg_params=list(cex = text_size)),colhead = list(fg_params=list(cex = header_size)))

  gt <- tableGrob(mean_matrix_top_10, theme=table_theme, rows=NULL)
  gt <- gtable_add_grob(gt,grobs = rectGrob(gp = gpar(fill = NA, lwd = border_thickness)),t = 2, b = nrow(gt), l = 1, r = ncol(gt))
  gt <- gtable_add_grob(gt,grobs = rectGrob(gp = gpar(fill = NA, lwd = border_thickness)),t = 1, l = 1, r = ncol(gt))
  gt <- gtable_add_grob(gt,grobs = rectGrob(gp = gpar(fill = NA, lwd = border_thickness)),t = 1, b = nrow(gt), l = 1, r = 1)
}


##----- Gene Expression Violin Plot Function  -----##
make_gene_expression_violin_plot <- function(matrix,gene,violin_transparency,violin_width,violin_line_thickness,violin_colours,violin_labels,trim_violin,jitter_dot_size,jitter_dot_colour,jitter_dot_width,summary_colour,summary_size,x_axis_label,y_axis_label,legend_position)
{
  ggp = ggplot(matrix, aes(x=sample_groupings, y=matrix[[gene]], color=sample_groupings, group=sample_groupings, fill=sample_groupings)) + geom_violin(trim=trim_violin, scale="width", width=violin_width, alpha = violin_transparency, size=violin_line_thickness) + geom_jitter(size=jitter_dot_size, colour=jitter_dot_colour, width=jitter_dot_width, height=0, show.legend = FALSE) + stat_summary(position=position_dodge(0.75), colour = summary_colour, size = summary_size, geom="pointrange", show.legend = FALSE) + scale_color_manual(values=violin_colours,breaks=sample_groups,labels=violin_labels,limits=sample_groups) + scale_fill_manual(values=violin_colours,breaks=sample_groups,labels=violin_labels,limits=sample_groups) + scale_x_discrete(breaks=sample_groups,labels=violin_labels,limits=sample_groups) + ylim(0, max(matrix[[gene]] * 1.25)) + xlab(x_axis_label) + ylab(y_axis_label) + ggtitle(gene) + theme_SL2() + theme(legend.position=legend_position, axis.text.x = element_text(angle = 45, hjust = 1))
  return(ggp)
}


##----- Volcano Plot Function -----##
make_volcano_plot <- function(non_significant_colour,significant_colour,dot_size,dot_transparency,significant_name,non_significant_name,x_axis_label,y_axis_label,legend_position,data_label_size) 
{
  ggp = ggplot(data=de_annotated, aes(x=log2fold, y=-log10(p), colour=sig, group=sig,fill=sig)) + geom_point(size=dot_size,alpha=dot_transparency) + scale_color_manual(values=c(non_significant_colour,significant_colour),breaks=c("True","False"),labels=c(significant_name, non_significant_name)) + scale_fill_manual(values=c(non_significant_colour,significant_colour),breaks=c("True","False"),labels=c(significant_name, non_significant_name)) + xlab(x_axis_label) + ylab(y_axis_label) + theme_SL2() + theme(legend.position=legend_position, legend.title = element_blank()) + geom_text(data=de_annotated_sig,aes(label=rownames(de_annotated_sig)),hjust=-0.1, vjust=-0.1, size=data_label_size, show.legend = FALSE)
  return(ggp)
}


##----- MA Plot Function -----##
make_MA_plot <- function(non_significant_colour,significant_colour,dot_size,dot_transparency,significant_name,non_significant_name,x_axis_label,y_axis_label,legend_position,data_label_size) 
{
  de_annotated_parsed = de_annotated
  de_annotated_parsed$row_means = rowMeans(ne_matrix)
  de_annotated_parsed_significant = subset(de_annotated_parsed,sig == "True")
  
  ggp = ggplot(data=de_annotated_parsed, aes(x=log(row_means+0.001,10), y=log2fold, colour=sig, group=sig,fill=sig)) + geom_point(size=dot_size,alpha=dot_transparency) + scale_color_manual(values=c(non_significant_colour,significant_colour),breaks=c("True","False"),labels=c(significant_name, non_significant_name)) + scale_fill_manual(values=c(non_significant_colour,significant_colour),breaks=c("True","False"),labels=c(significant_name, non_significant_name)) + xlab(x_axis_label) + ylab(y_axis_label) + theme_SL2() + theme(legend.position=legend_position, legend.title = element_blank()) + geom_text(data=de_annotated_parsed_significant,aes(label=rownames(de_annotated_parsed_significant)),hjust=-0.1, vjust=-0.1, size=data_label_size, show.legend = FALSE)
  return(ggp)
}


##----- Number of Significant Genes Barchart Function -----##
make_number_of_significant_genes_barchart <- function(x_axis_label,y_axis_label,comparison_labels,direction_labels,bar_colours,legend_position,data_label_size,bar_outline_size) 
{
  upregulated = nrow(subset(de_annotated_sig,log2fold > 0))
  downregulated = nrow(subset(de_annotated_sig,log2fold < 0))
  dat <- data.frame(
    comparison = factor(comparisons, levels=comparisons),
    upregulated = c(upregulated),
    downregulated = c(downregulated)
  )

  dat.m <- melt(dat, id.vars = "comparison")
  ggp = ggplot(data=dat.m , aes(x=comparison, y=value, fill=variable)) + geom_bar(colour="black", stat="identity", position = "dodge", size=bar_outline_size) + xlab(x_axis_label) + ylab(y_axis_label) + theme_SL2() + geom_text(aes(label=value), position=position_dodge(width=0.9), size=data_label_size, show.legend = FALSE, vjust=2) + scale_color_manual(values=bar_colours,labels=direction_labels) + scale_fill_manual(values=bar_colours,labels=direction_labels) + scale_x_discrete(labels=comparison_labels) + theme(legend.position=legend_position, legend.spacing.x = unit(0.25, 'cm')) + scale_y_continuous(expand=c(0,0), limits=c(0,max(dat.m$value*1.1)))
  return(ggp)
}


##----- Significant Genes Heatmap Function  -----##
make_significant_genes_heatmap <- function(matrix_scaled,colours,sample_names,cluster_x,cluster_y,distance_method,clustering_method,reorder_function)
{

  if(nrow(matrix_scaled) >= 2) 
  {
    matrix_scaled_renamed = as.matrix(matrix_scaled)
    colnames(matrix_scaled_renamed) = sample_names
  
    matrix_scaled_renamed_clustered = cluster_matrix(matrix_scaled_renamed,cluster_x,cluster_y,distance_method,clustering_method,reorder_function)
    matrix_scaled_renamed_clustered_melted <- melt(matrix_scaled_renamed_clustered)
    matrix_scaled_renamed_clustered_melted$X1 = factor(matrix_scaled_renamed_clustered_melted$X1, levels=row.names(matrix_scaled_renamed_clustered))
    matrix_scaled_renamed_clustered_melted$X2 = factor(matrix_scaled_renamed_clustered_melted$X2, levels=colnames(matrix_scaled_renamed_clustered))

    hm.palette <- colorRampPalette(colours)
    ggp = ggplot(matrix_scaled_renamed_clustered_melted, aes(x = X2, y = X1, fill = value)) + geom_tile() + scale_fill_gradientn(colours = hm.palette(100)) + ylab('') + xlab('') + theme_SL2() + theme(legend.position="right", legend.title = element_blank(), legend.spacing.x = unit(0.25, 'cm'),axis.text.x = element_text(angle = 90, hjust = 1), axis.ticks=element_blank()) + scale_x_discrete(expand=c(0,0)) + scale_y_discrete(expand=c(0,0))
    return(ggp)
  }
  else
  {
    return(ggplot(data.frame()) + theme_SL2() + geom_blank() + ggtitle("There were too few genes to sensibly plot this."))
  }
}


##----- Most Differential Genes Table Function -----##
make_most_differential_genes_table <- function(top_10_genes,header_size,text_size,border_thickness)
{
  de_annotated_top_10 = de_annotated[top_10_genes,]
  de_annotated_top_10$Gene = row.names(de_annotated_top_10)
  de_annotated_top_10 = de_annotated_top_10[,c("Gene","log2fold","p","p.adj")]

  table_theme <- gridExtra::ttheme_minimal(core = list(fg_params=list(cex = text_size)),colhead = list(fg_params=list(cex = header_size)))

  gt <- tableGrob(de_annotated_top_10, theme=table_theme, rows=NULL)
  gt <- gtable_add_grob(gt,grobs = rectGrob(gp = gpar(fill = NA, lwd = border_thickness)),t = 2, b = nrow(gt), l = 1, r = ncol(gt))
  gt <- gtable_add_grob(gt,grobs = rectGrob(gp = gpar(fill = NA, lwd = border_thickness)),t = 1, l = 1, r = ncol(gt))
  gt <- gtable_add_grob(gt,grobs = rectGrob(gp = gpar(fill = NA, lwd = border_thickness)),t = 1, b = nrow(gt), l = 1, r = 1)
  
  return(gt)
}


##----- Spatial Enrichement Table Function  -----##
make_spatial_enrichment_table <- function(spatial_enrichment_summary,header_size,text_size,border_thickness)
{
  spatial_enrichment_summary_table = spatial_enrichment_summary[,c("chromosome","total_genes","expressed_genes","de_valid_genes","significant_genes","upregulated_genes","downregulated_genes","expressed_genes_bias_log2fold","expressed_genes_bias_p","significant_genes_bias_log2fold","significant_genes_bias_p","direction_bias_swing","direction_bias_p")]
  colnames(spatial_enrichment_summary_table) = c("chromosome","total genes","expressed genes","de valid genes","significant genes","upregulated genes","downregulated genes","expressed genes bias (log2fold)","expressed genes bias (p)","significant genes bias (log2fold)","significant genes bias (p)","direction bias (swing)","direction bias (p)")
  spatial_enrichment_summary_table = spatial_enrichment_summary_table[order(as.numeric(as.character(spatial_enrichment_summary_table$chromosome))),]
  table_theme <- gridExtra::ttheme_minimal(core = list(fg_params=list(cex = text_size)),colhead = list(fg_params=list(cex = header_size)))

  gt <- tableGrob(spatial_enrichment_summary_table, theme=table_theme, rows=NULL)
  gt <- gtable_add_grob(gt,grobs = rectGrob(gp = gpar(fill = NA, lwd = border_thickness)),t = 2, b = nrow(gt), l = 1, r = ncol(gt))
  gt <- gtable_add_grob(gt,grobs = rectGrob(gp = gpar(fill = NA, lwd = border_thickness)),t = 1, l = 1, r = ncol(gt))
  gt <- gtable_add_grob(gt,grobs = rectGrob(gp = gpar(fill = NA, lwd = border_thickness)),t = 1, b = nrow(gt), l = 1, r = 1)
  
  return(gt)
}


##---- Spatial Analysis Fold Distribution Function ----##
make_spatial_enrichment_fold_distribution_plot <- function(current_chromosome,non_significant_colour,significant_colour,dot_size,dot_transparency,significant_name,non_significant_name,x_axis_label,y_axis_label,legend_position,data_label_size) 
{
  chromosome_data = subset(de_annotated,chromosome==current_chromosome & de_valid=="True")
  chromosome_data_sig = subset(de_annotated_sig,chromosome==current_chromosome & de_valid=="True")
  
  if (nrow(chromosome_data) > 1)
  {
    ggp = ggplot(data=chromosome_data, aes(x=start+((stop-start)/2), y=log2fold, colour=sig, group=sig,fill=sig)) + geom_point(size=dot_size,alpha=dot_transparency) + scale_color_manual(values=c(non_significant_colour,significant_colour),breaks=c("True","False"),labels=c(significant_name, non_significant_name)) + scale_fill_manual(values=c(non_significant_colour,significant_colour),breaks=c("True","False"),labels=c(significant_name, non_significant_name)) + xlab(x_axis_label) + ylab(y_axis_label) + theme_SL2() + theme(legend.position=legend_position, legend.title = element_blank()) + geom_text(data=chromosome_data_sig,aes(label=rownames(chromosome_data_sig)),hjust=-0.1, vjust=-0.1, size=data_label_size, show.legend = FALSE) + ggtitle(paste("chromosome ",current_chromosome,sep="")) + ylim(c(-max(abs(chromosome_data$log2fold))*1.1,max(abs(chromosome_data$log2fold))*1.1))
    return(ggp)
  }
  else
  {
    return(ggplot(data.frame()) + theme_SL2() + geom_blank() + ggtitle("There were too few valid genes to sensibly plot this."))
  }
}


##---- Spatial Enrichment Gene Distribution Function ----##
make_spatial_enrichment_gene_distribution_plot <- function(current_chromosome,non_significant_colour,significant_colour,density_curve_transparency,density_curve_line_thickness,significant_name,non_significant_name,x_axis_label,y_axis_label,legend_position) 
{
  chromosome_data = subset(de_annotated,chromosome==current_chromosome & de_valid=="True")
  
  if (nrow(chromosome_data) > 1)
  {
    ggp = ggplot(chromosome_data, aes(x=start+((stop-start)/2), colour=sig, group=sig,fill=sig)) + geom_density(alpha=density_curve_transparency,size=density_curve_line_thickness, adjust=0.25) + scale_color_manual(values=c(non_significant_colour,significant_colour),breaks=c("True","False"),labels=c(significant_name, non_significant_name)) + scale_fill_manual(values=c(non_significant_colour,significant_colour),breaks=c("True","False"),labels=c(significant_name, non_significant_name)) + xlab(x_axis_label) + ylab(y_axis_label) + ggtitle(paste("chromosome ",current_chromosome,sep="")) + theme_SL2() + theme(legend.position=legend_position)
    return(ggp)
  }
  else
  {
    return(ggplot(data.frame()) + theme_SL2() + geom_blank() + ggtitle("There were too few valid genes to sensibly plot this."))
  }
}


##----- Hypergeometric Gene Sets Bar Chart Function -----##
make_oras_bar_chart <- function(top_10_gene_sets,x_axis_label,y_axis_label,non_significant_colour,significant_colour,bar_outline_size,bar_transparency,legend_position,significant_name,non_significant_name,data_label_size)
{ 
  top_10_gene_sets <- top_10_gene_sets[seq(dim(top_10_gene_sets)[1],1),]
  n_sig = nrow(subset(top_10_gene_sets,significant == "TRUE"))
  n_non_sig = nrow(subset(top_10_gene_sets,significant == "FALSE"))
  

  if (n_sig+n_non_sig == 0)
  {
    ggp = ggplot(data.frame()) + theme_SL2() + geom_blank() + ggtitle("There were too few gene sets sensibly plot this.")
  }
  else if (n_sig == 0)
  {
      ggp = ggplot(data=top_10_gene_sets , aes(x=gene_set, y=-log10(p), fill=significant,group=significant)) + geom_bar(colour="black",stat="identity", position = "dodge", alpha = bar_transparency) + coord_flip() + scale_x_discrete(limits = top_10_gene_sets$gene_set) + ylab(x_axis_label)  + xlab(y_axis_label) + scale_fill_manual(values=c(non_significant_colour),breaks=c("FALSE"),labels=c(non_significant_name)) + theme_SL2() + theme(axis.text.y = element_text(hjust=1),legend.position=legend_position, legend.spacing.x = unit(0.15, 'cm')) + scale_y_continuous(expand=c(0,0), limits=c(0,max(-log10(top_10_gene_sets$p)*1.25))) + geom_text(aes(label=overlapping_genes), position=position_dodge(width=0.9), size=data_label_size, show.legend = FALSE, hjust=-0.5)
  }
  else if (n_non_sig == 0)
  {
      ggp = ggplot(data=top_10_gene_sets , aes(x=gene_set, y=-log10(p), fill=significant,group=significant)) + geom_bar(colour="black",stat="identity", position = "dodge", alpha = bar_transparency) + coord_flip() + scale_x_discrete(limits = top_10_gene_sets$gene_set) + ylab(x_axis_label)  + xlab(y_axis_label) + scale_fill_manual(values=c(significant_colour),breaks=c("TRUE"),labels=c(significant_name)) + theme_SL2() + theme(axis.text.y = element_text(hjust=1),legend.position=legend_position, legend.spacing.x = unit(0.15, 'cm')) + scale_y_continuous(expand=c(0,0), limits=c(0,max(-log10(top_10_gene_sets$p)*1.25))) + geom_text(aes(label=overlapping_genes), position=position_dodge(width=0.9), size=data_label_size, show.legend = FALSE, hjust=-0.5)
  }
  else if (n_sig != 10 && n_non_sig != 0 && n_sig != 0 && n_non_sig != 10)
  {
      ggp = ggplot(data=top_10_gene_sets , aes(x=gene_set, y=-log10(p), fill=significant,group=significant)) + geom_bar(colour="black",stat="identity", position = "dodge", alpha = bar_transparency) + coord_flip() + scale_x_discrete(limits = top_10_gene_sets$gene_set) + ylab(x_axis_label)  + xlab(y_axis_label) + scale_fill_manual(values=c(non_significant_colour,significant_colour),breaks=c("TRUE","FALSE"),labels=c(significant_name, non_significant_name)) + theme_SL2() + theme(axis.text.y = element_text(hjust=1),legend.position=legend_position, legend.spacing.x = unit(0.15, 'cm')) + scale_y_continuous(expand=c(0,0), limits=c(0,max(-log10(top_10_gene_sets$p)*1.25))) + geom_text(aes(label=overlapping_genes), position=position_dodge(width=0.9), size=data_label_size, show.legend = FALSE, hjust=-0.5)
  }
  return(ggp)
}


##----- Hypergeometric Gene Set Boxplot Function -----##
make_ora_boxplot <- function(gene_set,plot_title,box_transparency,box_line_thickness,box_colours,box_labels,x_axis_label,y_axis_label,legend_position)
{
  genes_in_gene_set = unlist(lapply(gene_set$overlapping_gene_names, function(x) unlist(strsplit(as.character(x),","))))
  if(length(genes_in_gene_set) > 1) 
  {
    ne_matrix_scaled_transposed_genes_in_gene_set = ne_matrix_scaled_transposed[,genes_in_gene_set]
    ne_matrix_scaled_transposed_genes_in_gene_set$sample_groupings = sample_groupings
    ne_matrix_scaled_transposed_genes_in_gene_set_melted = melt(ne_matrix_scaled_transposed_genes_in_gene_set,id.vars = "sample_groupings")
    ggp = ggplot(ne_matrix_scaled_transposed_genes_in_gene_set_melted, aes(x=variable, y=value, fill=sample_groupings)) + geom_boxplot(position=position_dodge(0.75),outlier.shape = NA, alpha=box_transparency,size=box_line_thickness) + theme_SL2() + theme(axis.text.x = element_text(angle = 90, hjust=1, vjust=0.5),legend.position=legend_position) + ggtitle(plot_title) + scale_color_manual(values=box_colours,breaks=sample_groups,labels=box_labels) + scale_fill_manual(values=box_colours,breaks=sample_groups,labels=box_labels) + xlab(x_axis_label) + ylab(y_axis_label)
    return(ggp)
  }
  return(ggplot(data.frame()) + theme_SL2() + geom_blank() + ggtitle("There were too few genes to sensibly plot this."))
}


##---- Hypergeometric Gene Set Network Plot Function ----##
make_ora_network_plot <- function(edges,nodes,node_colours,node_outer_max_size,node_inner_max_size,node_label_size,edge_colour,edge_transparency, edge_width)
{
  if (nrow(edges) > 0) {
  
    edges_source_target <- edges[c(1,2)]

    net = 0
    net = network(edges_source_target, directed = FALSE)
 
    # gets the node sizes
    x = data.frame(node = network.vertex.names(net))
    x = merge(x, nodes, by = "node", sort = FALSE)$node_size
    net %v% "node_size" = as.numeric(x)

    # scales log10p from 0 to 1
    nodes$log10_p = -log(nodes$enrichment_p_value,10)
    nodes = nodes[order(nodes$log10_p),]
    nodes$log10_p_scaled_0_to_1 = range_0_to_1_function(nodes$log10_p)

    # pass node colours to the network
    colour_ramp_function = colorRamp(node_colours)
    colours = colour_ramp_function(nodes$log10_p_scaled_0_to_1)
    nodes$node_colour = rgb(colours, maxColorValue=256)
    x = data.frame(node = network.vertex.names(net))
    x = merge(x, nodes, by = "node", sort = FALSE)$node_colour
    net %v% "node_colour" = as.character(x)

    ggp = ggnet2(net, alpha = 1, color = 'node_colour', size = 0,edge.color = edge_colour, edge.size = edges$overlap_ratio*edge_width, edge.alpha = edge_transparency) + xlab("") + ylab("") + theme_SL2() + theme(legend.position="none") + geom_point(aes(color = color), size=(get.vertex.attribute(net,"node_size")*node_outer_max_size)/max(get.vertex.attribute(net,"node_size")), alpha = 0.5) + geom_point(aes(color = color), size=(get.vertex.attribute(net,"node_size")*node_inner_max_size)/max(get.vertex.attribute(net,"node_size")), alpha = 1) + geom_text(aes(label = network.vertex.names(net)), color = "black", size=node_label_size)
    return(ggp)
  }
  return(ggplot(data.frame()) + theme_SL2() + geom_blank() + ggtitle("There were too few nodes to sensibly plot this."))
}


##----- IPA Upstream Regulators Bar Chart Function -----##
make_ura_bar_chart <- function(top_10_upstream_regulators,x_axis_label,y_axis_label,non_significant_colour,significant_colour,bar_outline_size,bar_transparency,legend_position,significant_name,non_significant_name,data_label_size, direction)
{ 
  top_10_upstream_regulators <- top_10_upstream_regulators[seq(dim(top_10_upstream_regulators)[1],1),]
  n_sig = nrow(subset(top_10_upstream_regulators,significant == "TRUE"))
  n_non_sig = nrow(subset(top_10_upstream_regulators,significant == "FALSE"))
  
  if (direction=="activated") 
  {
  limits = c(0,max(top_10_upstream_regulators$activation_zscore*1.25))
  data_label_just = -0.5
  }
  if (direction=="inhibited") 
  {
  limits = c(min(top_10_upstream_regulators$activation_zscore*1.25),0)
  data_label_just = 1.5
  }
    
  if (n_sig+n_non_sig == 0)
  {
    ggp = ggplot(data.frame()) + theme_SL2() + geom_blank() + ggtitle("There were too few gene sets sensibly plot this.")
  }
  else if (n_sig == 0)
  {
      ggp = ggplot(data=top_10_upstream_regulators , aes(x=upstream_regulator, y=activation_zscore, fill=significant,group=significant)) + geom_bar(colour="black",stat="identity", position = "dodge", alpha = bar_transparency) + coord_flip() + scale_x_discrete(limits = top_10_upstream_regulators$upstream_regulator) + ylab(x_axis_label)  + xlab(y_axis_label) + scale_fill_manual(values=c(non_significant_colour),breaks=c("FALSE"),labels=c(non_significant_name)) + theme_SL2() + theme(axis.text.y = element_text(hjust=1),legend.position=legend_position, legend.spacing.x = unit(0.15, 'cm')) + scale_y_continuous(expand=c(0,0), limits=limits) + geom_text(aes(label=genes_activated+genes_inhibited), position=position_dodge(width=0.9), size=data_label_size, show.legend = FALSE, hjust=data_label_just)
  }
  else if (n_non_sig == 0)
  {
      ggp = ggplot(data=top_10_upstream_regulators , aes(x=upstream_regulator, y=activation_zscore, fill=significant,group=significant)) + geom_bar(colour="black",stat="identity", position = "dodge", alpha = bar_transparency) + coord_flip() + scale_x_discrete(limits = top_10_upstream_regulators$upstream_regulator) + ylab(x_axis_label)  + xlab(y_axis_label) + scale_fill_manual(values=c(significant_colour),breaks=c("TRUE"),labels=c(significant_name)) + theme_SL2() + theme(axis.text.y = element_text(hjust=1),legend.position=legend_position, legend.spacing.x = unit(0.15, 'cm')) + scale_y_continuous(expand=c(0,0), limits=limits) + geom_text(aes(label=genes_activated+genes_inhibited), position=position_dodge(width=0.9), size=data_label_size, show.legend = FALSE, hjust=data_label_just)
  }
  if (n_sig != 10 && n_non_sig != 0 && n_sig != 0 && n_non_sig != 10)
  {
      ggp = ggplot(data=top_10_upstream_regulators , aes(x=upstream_regulator, y=activation_zscore, fill=significant,group=significant)) + geom_bar(colour="black",stat="identity", position = "dodge", alpha = bar_transparency) + coord_flip() + scale_x_discrete(limits = top_10_upstream_regulators$upstream_regulator) + ylab(x_axis_label)  + xlab(y_axis_label) + scale_fill_manual(values=c(non_significant_colour,significant_colour),breaks=c("TRUE","FALSE"),labels=c(significant_name, non_significant_name)) + theme_SL2() + theme(axis.text.y = element_text(hjust=1),legend.position=legend_position, legend.spacing.x = unit(0.15, 'cm')) + scale_y_continuous(expand=c(0,0), limits=limits) + geom_text(aes(label=genes_activated+genes_inhibited), position=position_dodge(width=0.9), size=data_label_size, show.legend = FALSE, hjust=data_label_just)
  }
  return(ggp)
}


##----- IPA Upstream Regulator Boxplots Function -----##
make_IPA_upstream_regulator_boxplot <- function(gene_set,plot_title,box_transparency,box_line_thickness,box_colours,box_labels,x_axis_label,y_axis_label,legend_position)
{
  activating_genes_in_gene_set = unlist(lapply(gene_set$activated_gene_names, function(x) unlist(strsplit(as.character(x),","))))
  inactivating_genes_in_gene_set = unlist(lapply(gene_set$inhibited_gene_names, function(x) unlist(strsplit(as.character(x),","))))
  genes_in_gene_set = c(activating_genes_in_gene_set,inactivating_genes_in_gene_set)
  if(length(genes_in_gene_set) > 1) 
  {
    ne_matrix_scaled_transposed_genes_in_gene_set = ne_matrix_scaled_transposed[,genes_in_gene_set]
    ne_matrix_scaled_transposed_genes_in_gene_set$sample_groupings = sample_groupings
    ne_matrix_scaled_transposed_genes_in_gene_set_melted = melt(ne_matrix_scaled_transposed_genes_in_gene_set,id.vars = "sample_groupings")
    ggp = ggplot(ne_matrix_scaled_transposed_genes_in_gene_set_melted, aes(x=variable, y=value, fill=sample_groupings)) + geom_boxplot(position=position_dodge(0.75),outlier.shape = NA, alpha=box_transparency,size=box_line_thickness) + theme_SL2() + theme(axis.text.x = element_text(angle = 90, hjust=1, vjust=0.5),legend.position=legend_position) + ggtitle(plot_title) + scale_color_manual(values=box_colours,breaks=sample_groups,labels=box_labels) + scale_fill_manual(values=box_colours,breaks=sample_groups,labels=box_labels) + xlab(x_axis_label) + ylab(y_axis_label)
    return(ggp)
  }
  return(ggplot(data.frame()) + theme_SL2() + geom_blank() + ggtitle("There are too few genes to sensibly plot this."))
}


##---- IPA UREG Network Plot Function ----##
make_ura_network_plot <- function(edges,nodes,activated_node_colours,inhibited_node_colours,node_outer_max_size,node_inner_max_size,node_label_size,edge_colour,edge_transparency,edge_width)
{
  if (nrow(edges) > 0) {

    # starts the network
    net = 0
    edges_source_target <- edges[c(1,2)]
    net = network(edges_source_target, directed = FALSE)
    
    # scales the node colours from -1 to 1, diverging from 0
    nodes = nodes[order(-nodes$activation_zscore),]
    nodes$activation_zscore_scaled_0_to_1 = range_0_to_1_function(abs(nodes$activation_zscore))
    colour_ramp_up = colorRamp(activated_node_colours)
    nodes$colour_ramp_up = rgb(colour_ramp_up(nodes$activation_zscore_scaled_0_to_1),maxColorValue=256)
    colour_ramp_down = colorRamp(inhibited_node_colours)
    nodes$colour_ramp_down = rgb(colour_ramp_down(nodes$activation_zscore_scaled_0_to_1),maxColorValue=256)
    nodes$node_colour = c(subset(nodes,activation_zscore > 0)$colour_ramp_up,subset(nodes,activation_zscore < 0)$colour_ramp_down)
    x = data.frame(node = network.vertex.names(net))
    x = merge(x, nodes, by = "node", sort = FALSE)$node_colour
    net %v% "node_colour" = as.character(x)

    # pass the node sizes to the network
    x = data.frame(node = network.vertex.names(net))
    x = merge(x, nodes, by = "node", sort = FALSE)$node_size
    net %v% "node_size" = as.numeric(x)

    plot = ggnet2(net, alpha = 1, color = 'node_colour', size = 0,edge.color = edge_colour, edge.size = edges$overlap_ratio*edge_width, edge.alpha = edge_transparency) + xlab("") + ylab("") + theme_SL2() + theme(legend.position="none") + geom_point(aes(color = color), size=(get.vertex.attribute(net,"node_size")*node_outer_max_size)/max(get.vertex.attribute(net,"node_size")), alpha = 0.5) + geom_point(aes(color = color), size=(get.vertex.attribute(net,"node_size")*node_inner_max_size)/max(get.vertex.attribute(net,"node_size")), alpha = 1) + geom_text(aes(label = network.vertex.names(net)), color = "black", size=node_label_size)
    return(plot)
  }
  return(ggplot(data.frame()) + theme_SL2() + geom_blank() + ggtitle("There were too few nodes to sensibly plot this."))
}



##-------------------------##
##          Plots          ##
##-------------------------##



##----- Distribution of Expression Values -----##

plot_height = 250
plot_width = 250
transparency = 0.5
line_thickness = 1
x_axis_label = "expression (log10)"
y_axis_label = "density"
legend_position = "none"

for(plot_sample_index in 1:length(samples))
{
  plot_sample = samples[plot_sample_index]
  plot_colour = default_samples_colours[plot_sample_index]
  ggp = make_distribution_of_expression_values_plot(plot_sample,plot_colour,transparency,line_thickness,x_axis_label,y_axis_label,legend_position)
  save_plot(ggp,plot_height,plot_width,paste("plots/distribution_of_expression_values/",plot_sample,"_distribution_of_expression_values.png",sep=""))
}


##----- PCA (Contribution of Components) -----##

plot_height = 300
plot_width = 400
x_axis_label = "component"
y_axis_label = "proportion of variance (%)"
dot_size = 4
dot_transparency = 1
dot_colour = "red"
line_type = "solid"
line_colour = "black"
line_size = 1

ggp = make_PCA_contribution_of_components_plot(x_axis_label,y_axis_label,dot_size,dot_transparency,dot_colour,line_type,line_colour,line_size)
save_plot(ggp,plot_height,plot_width,"plots/PCA/PCA_contribution_of_components.png")


##----- PCA (Scatter Plots) -----##

plot_height = 300
plot_width = 300
plot_sample_group_colours = default_sample_group_colours
plot_sample_group_labels = default_sample_group_labels
plot_sample_labels = default_sample_labels
plot_sample_groupings = sample_groupings
dot_size = 4
dot_transparency = 1
legend_position = "bottom"
sample_label_size = 4.5
show_proportion_of_variance = TRUE

component_x = 1
component_y = 2
x_axis_label = "PC1"
y_axis_label = "PC2"
ggp = make_PCA_scatterplot(plot_sample_groupings,component_x,component_y,x_axis_label,y_axis_label,plot_sample_group_colours,plot_sample_group_labels,plot_sample_labels,dot_size,dot_transparency,legend_position,sample_label_size,show_proportion_of_variance)
save_plot(ggp,plot_height,plot_width,"plots/PCA/PCA_1_vs_PCA_2_scatter_plot_labelled.png")

sample_label_size = 0 
ggp = make_PCA_scatterplot(plot_sample_groupings,component_x,component_y,x_axis_label,y_axis_label,plot_sample_group_colours,plot_sample_group_labels,plot_sample_labels,dot_size,dot_transparency,legend_position,sample_label_size,show_proportion_of_variance)
save_plot(ggp,plot_height,plot_width,"plots/PCA/PCA_1_vs_PCA_2_scatter_plot_unlabelled.png")

component_x = 3
component_y = 4
x_axis_label = "PC3"
y_axis_label = "PC4"
sample_label_size = 4.5
ggp = make_PCA_scatterplot(plot_sample_groupings,component_x,component_y,x_axis_label,y_axis_label,plot_sample_group_colours,plot_sample_group_labels,plot_sample_labels,dot_size,dot_transparency,legend_position,sample_label_size,show_proportion_of_variance)
save_plot(ggp,plot_height,plot_width,"plots/PCA/PCA_3_vs_PCA_4_scatter_plot_labelled.png")

sample_label_size = 0
ggp = make_PCA_scatterplot(plot_sample_groupings,component_x,component_y,x_axis_label,y_axis_label,plot_sample_group_colours,plot_sample_group_labels,plot_sample_labels,dot_size,dot_transparency,legend_position,sample_label_size,show_proportion_of_variance)
save_plot(ggp,plot_height,plot_width,"plots/PCA/PCA_3_vs_PCA_4_scatter_plot_unlabelled.png")


##----- Correlation Analysis Heatmap -----##

plot_height = 600
plot_width = 750
colours = default_three_tone_heatmap_colours
sample_names = default_sample_labels
distance_method = "spearman"
clustering_method = "average"
reorder_function = "average"
cluster_x = FALSE
cluster_y = FALSE

ggp = make_correlation_analysis_heatmap(colours,sample_names,cluster_x,cluster_y,distance_method,clustering_method,reorder_function)
save_plot(ggp,plot_height,plot_width,"plots/correlation_analysis/correlation_analysis_heatmap.png")

cluster_x = TRUE
cluster_y = TRUE
ggp = make_correlation_analysis_heatmap(colours,sample_names,cluster_x,cluster_y,distance_method,clustering_method,reorder_function)
save_plot(ggp,plot_height,plot_width,"plots/correlation_analysis/correlation_analysis_heatmap_clustered.png")

##----- Most Expressed Genes (Tables) -----##

plot_height = 300
plot_width = 750
header_size = 1.25
text_size = 1.25
border_thickness = 2

for(sample_group_index in 1:length(sample_groups))
{
  sample_group = sample_groups[sample_group_index]
  top_10_genes = get_top_10_genes_by_mean_expression(sample_group_index)
  gt = make_most_expressed_genes_table(top_10_genes,header_size,text_size,border_thickness)
  save_table(gt,plot_height,plot_width,paste("plots/most_expressed_genes/",sample_group,"_most_expressed_genes_table.png",sep=""))
}


##----- Most Expressed Genes (Violin Plots) -----##

plot_height = 300
plot_width = 300
violin_transparency = 0.5
violin_width = 0.75
violin_line_thickness = 1
violin_colours = default_sample_group_colours 	# note: changing this won't change the order the groups appear in the x axis. Merely what they are coloured as.
violin_labels = default_sample_group_labels	# note: changing this won't change the order the groups appear in the x axis. Merely what they are named as.
trim_violin = FALSE
jitter_dot_size = 2
jitter_dot_colour = "black"
jitter_dot_width = 0.2
summary_colour = "red"
summary_size = 0.25
x_axis_label = ""
y_axis_label = "expression"
legend_position = "none"

for(sample_group_index in 1:length(sample_groups))
{
  sample_group = sample_groups[sample_group_index]
  top_10_genes = get_top_10_genes_by_mean_expression(sample_group_index)
  
  for (gene_index in 1:10)
  {
    gene = top_10_genes[gene_index]
    ggp = make_gene_expression_violin_plot(ne_matrix_transposed,gene,violin_transparency,violin_width,violin_line_thickness,violin_colours,violin_labels,trim_violin,jitter_dot_size,jitter_dot_colour,jitter_dot_width,summary_colour,summary_size,x_axis_label,y_axis_label,legend_position)
    save_plot(ggp,plot_height,plot_width,paste("plots/most_expressed_genes/",sample_group,"_no.",gene_index,"_most_expressed_gene.png",sep=""))
  }
}


##----- Volcano Plot  -----##

plot_height = 500
plot_width = 600
non_significant_colour = default_non_significant_colour
significant_colour = default_significant_colour
dot_size = 1.5
dot_transparency = 1
significant_name = "significant"
non_significant_name = "non-significant"
x_axis_label = "log2 fold change"
y_axis_label = "-log10 p-value"
legend_position = "bottom"
data_label_size = 4.5

ggp = make_volcano_plot(non_significant_colour,significant_colour,dot_size,dot_transparency,significant_name,non_significant_name,x_axis_label,y_axis_label,legend_position,data_label_size)
save_plot(ggp,plot_height,plot_width,"plots/volcano_plot/volcano_plot_labelled.png")

data_label_size = 0
ggp = make_volcano_plot(non_significant_colour,significant_colour,dot_size,dot_transparency,significant_name,non_significant_name,x_axis_label,y_axis_label,legend_position,data_label_size)
save_plot(ggp,plot_height,plot_width,"plots/volcano_plot/volcano_plot_unlabelled.png")



##----- MA Plot -----##

plot_height = 500
plot_width = 600
non_significant_colour = default_non_significant_colour
significant_colour = default_significant_colour
dot_size = 1.5
dot_transparency = 1
significant_name = "significant"
non_significant_name = "non-significant"
x_axis_label = "mean expression (log10)"
y_axis_label = "log2 fold change"
legend_position = "bottom"
data_label_size = 4.5

ggp = make_MA_plot(non_significant_colour,significant_colour,dot_size,dot_transparency,significant_name,non_significant_name,x_axis_label,y_axis_label,legend_position,data_label_size)
save_plot(ggp,plot_height,plot_width,"plots/MA_plot/MA_plot_labelled.png")

data_label_size = 0

ggp = make_MA_plot(non_significant_colour,significant_colour,dot_size,dot_transparency,significant_name,non_significant_name,x_axis_label,y_axis_label,legend_position,data_label_size)
save_plot(ggp,plot_height,plot_width,"plots/MA_plot/MA_plot_unlabelled.png")



##----- Number of Significant Genes Barchart -----##

plot_height = 350
plot_width = 350
x_axis_label = ""
y_axis_label = "number of significant genes"
comparison_labels = default_comparison_labels # note: changing this won't change the order the comparisons appear in the x axis. Merely what they are labelled as.
direction_labels = c("up","down") # note: changing this won't change the order the bars appear in the x axis. Merely what they are labelled as.
bar_colours = default_two_tone_greyscale # note: changing this won't change the order the bars appear in the x axis. Merely what they are coloured as.
legend_position = "bottom"
data_label_size = 5
bar_outline_size = 1

ggp = make_number_of_significant_genes_barchart(x_axis_label,y_axis_label,comparison_labels,direction_labels,bar_colours,legend_position,data_label_size,bar_outline_size)
save_plot(ggp,plot_height,plot_width,"plots/number_of_significant_genes/number_of_significant_genes_barchart.png")


##----- Significant Genes Heatmap  -----##

plot_height = 750
plot_width = 500
colours = default_three_tone_heatmap_colours
sample_names = default_sample_labels
distance_method = "spearman"
clustering_method = "average"
reorder_function = "average"

cluster_x = FALSE
cluster_y = TRUE

ggp = make_significant_genes_heatmap(ne_matrix_sig_scaled,colours,sample_names,cluster_x,cluster_y,distance_method,clustering_method,reorder_function)
save_plot(ggp,plot_height,plot_width,"plots/significant_genes_heatmap/significant_genes_heatmap.png")

cluster_x = TRUE
cluster_y = TRUE

ggp = make_significant_genes_heatmap(ne_matrix_sig_scaled,colours,sample_names,cluster_x,cluster_y,distance_method,clustering_method,reorder_function)
save_plot(ggp,plot_height,plot_width,"plots/significant_genes_heatmap/significant_genes_heatmap_column_clustered.png")


##----- Most Differential Genes (Tables) -----##

plot_height = 300
plot_width = 400
header_size = 1.25
text_size = 1.25
border_thickness = 2

top_10_genes = get_top_10_differential_genes(TRUE,"p") # upregulated, by p
gt = make_most_differential_genes_table(top_10_genes,header_size,text_size,border_thickness)
save_table(gt,plot_height,plot_width,"plots/most_differential_genes/most_upregulated_by_p_value/most_upregulated_genes_table.png")

top_10_genes = get_top_10_differential_genes(FALSE,"p") # downregulated, by p
gt = make_most_differential_genes_table(top_10_genes,header_size,text_size,border_thickness)
save_table(gt,plot_height,plot_width,"plots/most_differential_genes/most_downregulated_by_p_value/most_downregulated_genes_table.png")

top_10_genes = get_top_10_differential_genes(TRUE,"log2fold") # upregulated, by log2fold
gt = make_most_differential_genes_table(top_10_genes,header_size,text_size,border_thickness)
save_table(gt,plot_height,plot_width,"plots/most_differential_genes/most_upregulated_by_log2fold/most_upregulated_genes_table.png")

top_10_genes = get_top_10_differential_genes(FALSE,"log2fold") # downregulated, by log2fold
gt = make_most_differential_genes_table(top_10_genes,header_size,text_size,border_thickness)
save_table(gt,plot_height,plot_width,"plots/most_differential_genes/most_downregulated_by_log2fold/most_downregulated_genes_table.png")


##----- Most Differential Genes (Violin Plots) -----##

plot_height = 300
plot_width = 300
violin_transparency = 0.5
violin_width = 0.75
violin_line_thickness = 1
violin_colours = default_sample_group_colours 	# note: changing this won't change the order the groups appear in the x axis. Merely what they are coloured as.
violin_labels = default_sample_group_labels	# note: changing this won't change the order the groups appear in the x axis. Merely what they are named as.
trim_violin = FALSE
jitter_dot_size = 2
jitter_dot_colour = "black"
jitter_dot_width = 0.2
summary_colour = "red"
summary_size = 0.25
x_axis_label = ""
y_axis_label = "expression"
legend_position = "none"

top_10_genes = get_top_10_differential_genes(TRUE,"p") # upregulated, by p
for (gene_index in 1:10)
{
  gene = top_10_genes[gene_index]
  ggp = make_gene_expression_violin_plot(ne_matrix_transposed,gene,violin_transparency,violin_width,violin_line_thickness,violin_colours,violin_labels,trim_violin,jitter_dot_size,jitter_dot_colour,jitter_dot_width,summary_colour,summary_size,x_axis_label,y_axis_label,legend_position)
  save_plot(ggp,plot_height,plot_width,paste("plots/most_differential_genes/most_upregulated_by_p_value/no.",gene_index,"_most_upregulated_gene.png",sep=""))
}

top_10_genes = get_top_10_differential_genes(FALSE,"p") # downregulated, by p
for (gene_index in 1:10)
{
  gene = top_10_genes[gene_index]
  ggp = make_gene_expression_violin_plot(ne_matrix_transposed,gene,violin_transparency,violin_width,violin_line_thickness,violin_colours,violin_labels,trim_violin,jitter_dot_size,jitter_dot_colour,jitter_dot_width,summary_colour,summary_size,x_axis_label,y_axis_label,legend_position)
  save_plot(ggp,plot_height,plot_width,paste("plots/most_differential_genes/most_downregulated_by_p_value/no.",gene_index,"_most_downregulated_gene.png",sep=""))
}

top_10_genes = get_top_10_differential_genes(TRUE,"log2fold") # upregulated, by log2fold
for (gene_index in 1:10)
{
  gene = top_10_genes[gene_index]
  ggp = make_gene_expression_violin_plot(ne_matrix_transposed,gene,violin_transparency,violin_width,violin_line_thickness,violin_colours,violin_labels,trim_violin,jitter_dot_size,jitter_dot_colour,jitter_dot_width,summary_colour,summary_size,x_axis_label,y_axis_label,legend_position)
  save_plot(ggp,plot_height,plot_width,paste("plots/most_differential_genes/most_upregulated_by_log2fold/no.",gene_index,"_most_upregulated_gene.png",sep=""))
}

top_10_genes = get_top_10_differential_genes(FALSE,"log2fold") # downregulated, by log2fold
for (gene_index in 1:10)
{
  gene = top_10_genes[gene_index]
  ggp = make_gene_expression_violin_plot(ne_matrix_transposed,gene,violin_transparency,violin_width,violin_line_thickness,violin_colours,violin_labels,trim_violin,jitter_dot_size,jitter_dot_colour,jitter_dot_width,summary_colour,summary_size,x_axis_label,y_axis_label,legend_position)
  save_plot(ggp,plot_height,plot_width,paste("plots/most_differential_genes/most_downregulated_by_log2fold/no.",gene_index,"_most_downregulated_gene.png",sep=""))
}


##----- Spatial Enrichement (Table) -----##

plot_height = 700
plot_width = 2100
header_size = 1.25
text_size = 1.25
border_thickness = 2

gt = make_spatial_enrichment_table(spatial_enrichment_summary,header_size,text_size,border_thickness)
save_table(gt,plot_height,plot_width,"plots/spatial_enrichment/spatial_enrichment_table.png")


##----- Spatial Enrichment Distribution Plots -----##

plot_height = 300
plot_width = 750
non_significant_colour = default_non_significant_colour
significant_colour = default_significant_colour
dot_size = 1.5
dot_transparency = 1
significant_name = "significant"
non_significant_name = "non-significant"
x_axis_label = "gene location"
y_axis_label = "log2 fold change"
legend_position = "bottom"
density_curve_transparency = 0.5
density_curve_line_thickness = 0

chromosomes = unique(factor(de_annotated$chromosome))

for (chromosome in chromosomes) 
{
data_label_size = 4.5
ggp = make_spatial_enrichment_fold_distribution_plot(chromosome,non_significant_colour,significant_colour,dot_size,dot_transparency,significant_name,non_significant_name,x_axis_label,y_axis_label,legend_position,data_label_size)
save_plot(ggp,plot_height,plot_width,paste("plots/spatial_enrichment/fold_distribution_chr_",chromosome,"_labelled.png",sep=""))

data_label_size = 0
ggp = make_spatial_enrichment_fold_distribution_plot(chromosome,non_significant_colour,significant_colour,dot_size,dot_transparency,significant_name,non_significant_name,x_axis_label,y_axis_label,legend_position,data_label_size)
save_plot(ggp,plot_height,plot_width,paste("plots/spatial_enrichment/fold_distribution_chr_",chromosome,"_unlabelled.png",sep=""))
}

x_axis_label = "gene location"
y_axis_label = "gene density"

for (chromosome in chromosomes) 
{
ggp = make_spatial_enrichment_gene_distribution_plot(chromosome,non_significant_colour,significant_colour,density_curve_transparency,density_curve_line_thickness,significant_name,non_significant_name,x_axis_label,y_axis_label,legend_position)
save_plot(ggp,plot_height,plot_width,paste("plots/spatial_enrichment/gene_distribution_chr_",chromosome,".png",sep=""))
}


##----- Hypergeometric Enriched Gene Sets (Bar Charts) -----##

plot_height = 350
plot_width = 1000
x_axis_label = "-log10 p-value"
y_axis_label = ""
non_significant_colour = default_non_significant_colour
significant_colour = default_significant_colour
bar_outline_size = 1
bar_transparency = 0.75
legend_position = "bottom"
significant_name = "significant"
non_significant_name = "non-significant"
data_label_size = 5

top_10_gene_sets = get_top10_oras_by_p_value(GO_BP_all_gene_sets,GO_BP_all_signficant_genes_enriched_gene_sets,"enrichment")
ggp <- make_oras_bar_chart(top_10_gene_sets,x_axis_label,y_axis_label,non_significant_colour,significant_colour,bar_outline_size,bar_transparency,legend_position,significant_name,non_significant_name,data_label_size)
save_plot(ggp,plot_height,plot_width,"plots/over_representation_analysis/GO_BP/enriched_amongst_all_significant_genes/enriched_gene_sets_barchart.png")

top_10_gene_sets = get_top10_oras_by_p_value(GO_BP_downregulated_gene_sets,GO_BP_downregulated_enriched_gene_sets,"enrichment")
ggp <- make_oras_bar_chart(top_10_gene_sets,x_axis_label,y_axis_label,non_significant_colour,significant_colour,bar_outline_size,bar_transparency,legend_position,significant_name,non_significant_name,data_label_size)
save_plot(ggp,plot_height,plot_width,"plots/over_representation_analysis/GO_BP/enriched_amongst_downregulated_genes/enriched_gene_sets_barchart.png")

top_10_gene_sets = get_top10_oras_by_p_value(GO_BP_upregulated_gene_sets,GO_BP_upregulated_enriched_gene_sets,"enrichment")
ggp <- make_oras_bar_chart(top_10_gene_sets,x_axis_label,y_axis_label,non_significant_colour,significant_colour,bar_outline_size,bar_transparency,legend_position,significant_name,non_significant_name,data_label_size)
save_plot(ggp,plot_height,plot_width,"plots/over_representation_analysis/GO_BP/enriched_amongst_upregulated_genes/enriched_gene_sets_barchart.png")



##----- Hypergeometric Enriched Gene Sets (Boxplot) -----##

plot_height = 250
plot_width = 1000
box_transparency = 0.75
box_line_thickness = 0.75
box_colours = default_sample_group_colours 	# note: changing this won't change the order the groups appear in the x axis. Merely what they are coloured as.
box_labels = default_sample_group_labels	# note: changing this won't change the order the groups appear in the x axis. Merely what they are named as.
x_axis_label = ""
y_axis_label = "expression (z-score)"
legend_position = "right"

top_10_gene_sets = get_top10_oras_by_p_value(GO_BP_all_gene_sets,GO_BP_all_signficant_genes_enriched_gene_sets,"enrichment")
for(gene_set_index in 1:10)
{
  gene_set = top_10_gene_sets[gene_set_index,]
  plot_title = gene_set[["gene_set"]]
  ggp = make_ora_boxplot(gene_set,plot_title,box_transparency,box_line_thickness,box_colours,box_labels,x_axis_label,y_axis_label,legend_position)
  save_plot(ggp,plot_height,plot_width,paste("plots/over_representation_analysis/GO_BP/enriched_amongst_all_significant_genes/no.",gene_set_index,"_most_enriched_gene_set.png",sep=""))
}

top_10_gene_sets = get_top10_oras_by_p_value(GO_BP_downregulated_gene_sets,GO_BP_downregulated_enriched_gene_sets,"enrichment")
for(gene_set_index in 1:10)
{
  gene_set = top_10_gene_sets[gene_set_index,]
  plot_title = gene_set[["gene_set"]]
  ggp = make_ora_boxplot(gene_set,plot_title,box_transparency,box_line_thickness,box_colours,box_labels,x_axis_label,y_axis_label,legend_position)
  save_plot(ggp,plot_height,plot_width,paste("plots/over_representation_analysis/GO_BP/enriched_amongst_downregulated_genes/no.",gene_set_index,"_most_enriched_gene_set.png",sep=""))
}

top_10_gene_sets = get_top10_oras_by_p_value(GO_BP_upregulated_gene_sets,GO_BP_upregulated_enriched_gene_sets,"enrichment")
for(gene_set_index in 1:10)
{
  gene_set = top_10_gene_sets[gene_set_index,]
  plot_title = gene_set[["gene_set"]]
  ggp = make_ora_boxplot(gene_set,plot_title,box_transparency,box_line_thickness,box_colours,box_labels,x_axis_label,y_axis_label,legend_position)
  save_plot(ggp,plot_height,plot_width,paste("plots/over_representation_analysis/GO_BP/enriched_amongst_upregulated_genes/no.",gene_set_index,"_most_enriched_gene_set.png",sep=""))
}



##---- Hypergeometric Gene Set (Network Plots) ----##

plot_height = 1000
plot_width = 1500

node_colours = default_two_tone_network_node_colours
node_outer_max_size = 25
node_inner_max_size = 20
node_label_size = 3
edge_colour = default_network_edge_colour
edge_transparency = 0.5
edge_width = 2

ggp = make_ora_network_plot(GO_BP_all_significant_gene_sets_edges,GO_BP_all_significant_gene_sets_nodes,node_colours,node_outer_max_size,node_inner_max_size,node_label_size,edge_colour,edge_transparency,edge_width)
save_plot(ggp,plot_height,plot_width,"plots/over_representation_analysis/GO_BP/enriched_amongst_all_significant_genes/enriched_gene_sets_network_plot.png")

ggp = make_ora_network_plot(GO_BP_upregulated_gene_sets_edges,GO_BP_upregulated_gene_sets_nodes,node_colours,node_outer_max_size,node_inner_max_size,node_label_size,edge_colour,edge_transparency,edge_width)
save_plot(ggp,plot_height,plot_width,"plots/over_representation_analysis/GO_BP/enriched_amongst_upregulated_genes/enriched_gene_sets_network_plot.png")

ggp = make_ora_network_plot(GO_BP_downregulated_gene_sets_edges,GO_BP_downregulated_gene_sets_nodes,node_colours,node_outer_max_size,node_inner_max_size,node_label_size,edge_colour,edge_transparency,edge_width)
save_plot(ggp,plot_height,plot_width,"plots/over_representation_analysis/GO_BP/enriched_amongst_downregulated_genes/enriched_gene_sets_network_plot.png")



##----- Hypergeometric Underenriched Gene Sets (Bar Charts) -----##

plot_height = 350
plot_width = 1000
x_axis_label = "-log10 p-value"
y_axis_label = ""
non_significant_colour = default_non_significant_colour
significant_colour = default_significant_colour
bar_outline_size = 1
bar_transparency = 0.75
legend_position = "bottom"
significant_name = "significant"
non_significant_name = "non-significant"
data_label_size = 5

top_10_gene_sets = get_top10_oras_by_p_value(GO_BP_all_gene_sets,GO_BP_all_signficant_genes_underenriched_gene_sets,"underenrichment")
ggp = make_oras_bar_chart(top_10_gene_sets,x_axis_label,y_axis_label,non_significant_colour,significant_colour,bar_outline_size,bar_transparency,legend_position,significant_name,non_significant_name,data_label_size)
save_plot(ggp,plot_height,plot_width,"plots/over_representation_analysis/GO_BP/underenriched_amongst_all_significant_genes/underenriched_gene_sets_barchart.png")

top_10_gene_sets = get_top10_oras_by_p_value(GO_BP_downregulated_gene_sets,GO_BP_downregulated_underenriched_gene_sets,"underenrichment")
ggp = make_oras_bar_chart(top_10_gene_sets,x_axis_label,y_axis_label,non_significant_colour,significant_colour,bar_outline_size,bar_transparency,legend_position,significant_name,non_significant_name,data_label_size)
save_plot(ggp,plot_height,plot_width,"plots/over_representation_analysis/GO_BP/underenriched_amongst_downregulated_genes/underenriched_gene_sets_barchart.png")

top_10_gene_sets = get_top10_oras_by_p_value(GO_BP_upregulated_gene_sets,GO_BP_upregulated_underenriched_gene_sets,"underenrichment")
ggp = make_oras_bar_chart(top_10_gene_sets,x_axis_label,y_axis_label,non_significant_colour,significant_colour,bar_outline_size,bar_transparency,legend_position,significant_name,non_significant_name,data_label_size)
save_plot(ggp,plot_height,plot_width,"plots/over_representation_analysis/GO_BP/underenriched_amongst_upregulated_genes/underenriched_gene_sets_barchart.png")



##----- IPA Upstream Regulators (Barcharts) -----##

plot_height = 350
plot_width = 500
x_axis_label = "-log10 p-value"
y_axis_label = ""
non_significant_colour = default_non_significant_colour
significant_colour = default_significant_colour
bar_outline_size = 1
bar_transparency = 0.75
legend_position = "bottom"
data_label_size = 5
significant_name = "significant"
non_significant_name = "non-significant"

top_10_upstream_regulators = get_top10_ura_function(TRUSST_all_gene_sets,TRUSST_enriched_gene_sets,"enriched")
ggp = make_oras_bar_chart(top_10_upstream_regulators,x_axis_label,y_axis_label,non_significant_colour,significant_colour,bar_outline_size,bar_transparency,legend_position,significant_name,non_significant_name,data_label_size)
save_plot(ggp,plot_height,plot_width,"plots/upstream_regulator_analysis/TRUSST/enriched/enriched_upstream_regulators_bar_chart.png")

x_axis_label = "activation z-score"
significant_name = "activated"
non_significant_name = "not-activated"

top_10_upstream_regulators = get_top10_ura_function(TRUSST_all_gene_sets,TRUSST_activated_gene_sets, "activated")
ggp = make_ura_bar_chart(top_10_upstream_regulators,x_axis_label,y_axis_label,non_significant_colour,significant_colour,bar_outline_size,bar_transparency,legend_position,significant_name,non_significant_name,data_label_size, "activated")
save_plot(ggp,plot_height,plot_width,"plots/upstream_regulator_analysis/TRUSST/activated/activated_upstream_regulators_bar_chart.png")

x_axis_label = "activation z-score"
significant_name = "inhibited"
non_significant_name = "not-inhibited"

top_10_upstream_regulators = get_top10_ura_function(TRUSST_all_gene_sets,TRUSST_activated_gene_sets, "inhibited")
ggp = make_ura_bar_chart(top_10_upstream_regulators,x_axis_label,y_axis_label,non_significant_colour,significant_colour,bar_outline_size,bar_transparency,legend_position,significant_name,non_significant_name,data_label_size, "inhibited")
save_plot(ggp,plot_height,plot_width,"plots/upstream_regulator_analysis/TRUSST/inhibited/inhibited_upstream_regulators_bar_chart.png")



##----- IPA Upstream Regulators (Boxplots) -----##

plot_height = 250
plot_width = 1000
box_transparency = 0.75
box_line_thickness = 0.75
box_colours = default_sample_group_colours 	# note: changing this won't change the order the groups appear in the x axis. Merely what they are coloured as.
box_labels = default_sample_group_labels	# note: changing this won't change the order the groups appear in the x axis. Merely what they are named as.
x_axis_label = ""
y_axis_label = "expression (z-score)"
legend_position = "right"

top_10_upstream_regulators = get_top10_ura_function(TRUSST_all_gene_sets,TRUSST_enriched_gene_sets,"enriched")
for(upstream_regulator_index in 1:10)
{
  upstream_regulator = top_10_upstream_regulators[upstream_regulator_index,]
  plot_title = upstream_regulator[["gene_set"]]
  ggp = make_ora_boxplot(upstream_regulator,plot_title,box_transparency,box_line_thickness,box_colours,box_labels,x_axis_label,y_axis_label,legend_position)
  save_plot(ggp,plot_height,plot_width,paste("plots/upstream_regulator_analysis/TRUSST/enriched/no.",upstream_regulator_index,"_most_enriched_upstream_regulator.png",sep=""))
}

top_10_upstream_regulators = get_top10_ura_function(TRUSST_all_gene_sets,TRUSST_activated_gene_sets, "activated")
for(upstream_regulator_index in 1:10)
{
  upstream_regulator = top_10_upstream_regulators[upstream_regulator_index,]
  plot_title = upstream_regulator[["upstream_regulator"]]
  ggp = make_IPA_upstream_regulator_boxplot(upstream_regulator,plot_title,box_transparency,box_line_thickness,box_colours,box_labels,x_axis_label,y_axis_label,legend_position)
  save_plot(ggp,plot_height,plot_width,paste("plots/upstream_regulator_analysis/TRUSST/activated/no.",upstream_regulator_index,"_most_activated_upstream_regulator.png",sep=""))
}

top_10_upstream_regulators = get_top10_ura_function(TRUSST_all_gene_sets,TRUSST_activated_gene_sets, "inhibited")
for(upstream_regulator_index in 1:10)
{
  upstream_regulator = top_10_upstream_regulators[upstream_regulator_index,]
  plot_title = upstream_regulator[["upstream_regulator"]]
  ggp = make_IPA_upstream_regulator_boxplot(upstream_regulator,plot_title,box_transparency,box_line_thickness,box_colours,box_labels,x_axis_label,y_axis_label,legend_position)
  save_plot(ggp,plot_height,plot_width,paste("plots/upstream_regulator_analysis/TRUSST/inhibited/no.",upstream_regulator_index,"_most_inhibited_upstream_regulator.png",sep=""))
}



##---- IPA UREG (Network Plots) ----##

plot_height = 1000
plot_width = 1500

node_colours = default_two_tone_network_node_colours
activated_node_colours = default_four_tone_network_node_colours_high
inhibited_node_colours = default_four_tone_network_node_colours_low
node_outer_max_size = 50
node_inner_max_size = 40
node_label_size = 3
edge_colour = default_network_edge_colour
edge_transparency = 0.5
edge_width = 4

ggp = make_ora_network_plot(TRUSST_enriched_ura_edges,TRUSST_enriched_ura_nodes,node_colours,node_outer_max_size,node_inner_max_size,node_label_size,edge_colour,edge_transparency,edge_width)
save_plot(ggp,plot_height,plot_width,"plots/upstream_regulator_analysis/TRUSST/enriched_gene_sets_network_plot.png")

ggp = make_ura_network_plot(TRUSST_activated_ura_edges,TRUSST_activated_ura_nodes,activated_node_colours,inhibited_node_colours,node_outer_max_size,node_inner_max_size,node_label_size,edge_colour,edge_transparency,edge_width)
save_plot(ggp,plot_height,plot_width,"plots/upstream_regulator_analysis/TRUSST/activated_and_inhibited_gene_sets_network_plot.png")





##---- image and session info ----##
save.image("/home/john/Downloads/TEMP/DESEQ2/results/all_genes/de_workflows/KO_vs_WT/plots/workflow.rdata")
write.table(capture.output(sessionInfo()), file="/home/john/Downloads/TEMP/DESEQ2/results/all_genes/de_workflows/KO_vs_WT/plots/workflow_session_info.txt")
