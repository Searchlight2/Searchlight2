##---- general libraries ----##
library(ggplot2)
library(reshape)

##---- sets the working directory. If you move the SL2 folder please update this path ----##
setwd("/home/john/Downloads/TEMP/DESEQ2/results/all_genes/de_workflows/KO_vs_WT")

##---- de input files ----##
de_annotated = read.table(file="data/de_annotated.csv", header=TRUE,row.names = 2, sep='\t', quote='',check.names = TRUE)
de_annotated_sig = read.table(file="data/de_annotated_significant.csv", header=TRUE,row.names = 2, sep='\t', quote='',check.names = TRUE)

##---- SL2 Theme ----##
theme_SL2 <- function () { 
    theme_bw() %+replace% 
        theme(
	    panel.grid = element_blank(),
            panel.background = element_blank(),
            panel.border = element_rect(colour = "black", fill=NA, size=1),
            plot.background = element_blank(), 
            legend.background = element_rect(fill="transparent", colour=NA),
            legend.key = element_rect(fill="transparent", colour=NA),
            plot.title = element_text(size=16, margin = margin(b = 5),hjust=0,vjust=0.5, family="Arial", face="bold"),
            title = element_text(size = 16, margin = margin(b = 5),hjust=0,vjust=0.5, family="Arial", face="bold"),
            axis.text.y = element_text(size = 14, margin = margin(r = 5),hjust=1,vjust=0.5, family="Arial", face="bold",colour="black"),
            axis.text.x = element_text(size = 14, margin = margin(t = 5),hjust=0.5,vjust=1, family="Arial", face="bold",colour="black"), 
            axis.title.y = element_text(size = 16, margin = margin(r = 10),angle = 90,hjust=0.5,vjust=0.5, family="Arial", face="bold"),
            axis.title.x = element_text(size = 16, margin = margin(t = 10),hjust=0.5,vjust=1, family="Arial", face="bold"),
            legend.text=element_text(size=14, family="Arial", face="bold"),
            legend.title=element_blank(), 
            legend.key.size=unit(2.5,"line"),
            plot.margin=unit(c(0.4,0.4,0.4,0.4), "cm")
        )
}

##---- Default Sig and Non-sig Colours  ----##
default_significant_colour = "red"
default_non_significant_colour = "black"

##---- Save Plot Function -----##
save_plot <- function(ggp,plot_height,plot_width,plot_path)
{
  png(plot_path, height=plot_height, width=plot_width, pointsize=5)
  print(ggp)
  dev.off()

  # clears all devices - as a safety measure
  while (dev.cur()>1) dev.off()
}

##---- Spatial Analysis Fold Distribution Function ----##
make_spatial_enrichment_fold_distribution_plot <- function(current_chromosome,non_significant_colour,significant_colour,dot_size,dot_transparency,significant_name,non_significant_name,x_axis_label,y_axis_label,legend_position,data_label_size) 
{
  chromosome_data = subset(de_annotated,chromosome==current_chromosome & de_valid=="True")
  chromosome_data_sig = subset(de_annotated_sig,chromosome==current_chromosome & de_valid=="True")
  
  if (nrow(chromosome_data) > 1)
  {
    ggp = ggplot(data=chromosome_data, aes(x=start+((stop-start)/2), y=log2fold, colour=sig, group=sig,fill=sig)) + geom_point(size=dot_size,alpha=dot_transparency) + scale_color_manual(values=c(non_significant_colour,significant_colour),breaks=c("True","False"),labels=c(significant_name, non_significant_name)) + scale_fill_manual(values=c(non_significant_colour,significant_colour),breaks=c("True","False"),labels=c(significant_name, non_significant_name)) + xlab(x_axis_label) + ylab(y_axis_label) + theme_SL2() + theme(legend.position=legend_position, legend.title = element_blank()) + geom_text(data=chromosome_data_sig,aes(label=rownames(chromosome_data_sig)),hjust=-0.1, vjust=-0.1, size=data_label_size, show.legend = FALSE) + ggtitle(paste("chromosome ",current_chromosome,sep="")) + ylim(c(-max(abs(chromosome_data$log2fold))*1.1,max(abs(chromosome_data$log2fold))*1.1))
    return(ggp)
  }
  else
  {
    return(ggplot(data.frame()) + theme_SL2() + geom_blank() + ggtitle("There were too few valid genes to sensibly plot this."))
  }
}

##---- Spatial Enrichment Gene Distribution Function ----##
make_spatial_enrichment_gene_distribution_plot <- function(current_chromosome,non_significant_colour,significant_colour,density_curve_transparency,density_curve_line_thickness,significant_name,non_significant_name,x_axis_label,y_axis_label,legend_position) 
{
  chromosome_data = subset(de_annotated,chromosome==current_chromosome & de_valid=="True")
  
  if (nrow(chromosome_data) > 1)
  {
    ggp = ggplot(chromosome_data, aes(x=start+((stop-start)/2), colour=sig, group=sig,fill=sig)) + geom_density(alpha=density_curve_transparency,size=density_curve_line_thickness, adjust=0.25) + scale_color_manual(values=c(non_significant_colour,significant_colour),breaks=c("True","False"),labels=c(significant_name, non_significant_name)) + scale_fill_manual(values=c(non_significant_colour,significant_colour),breaks=c("True","False"),labels=c(significant_name, non_significant_name)) + xlab(x_axis_label) + ylab(y_axis_label) + ggtitle(paste("chromosome ",current_chromosome,sep="")) + theme_SL2() + theme(legend.position=legend_position)
    return(ggp)
  }
  else
  {
    return(ggplot(data.frame()) + theme_SL2() + geom_blank() + ggtitle("There were too few valid genes to sensibly plot this."))
  }
}

##----- Spatial Enrichment Distribution Plots -----##

plot_height = 300
plot_width = 750
non_significant_colour = default_non_significant_colour
significant_colour = default_significant_colour
dot_size = 1.5
dot_transparency = 1
significant_name = "significant"
non_significant_name = "non-significant"
x_axis_label = "gene location"
y_axis_label = "log2 fold change"
legend_position = "bottom"
density_curve_transparency = 0.5
density_curve_line_thickness = 0

chromosomes = unique(factor(de_annotated$chromosome))

for (chromosome in chromosomes) 
{
data_label_size = 4.5
ggp = make_spatial_enrichment_fold_distribution_plot(chromosome,non_significant_colour,significant_colour,dot_size,dot_transparency,significant_name,non_significant_name,x_axis_label,y_axis_label,legend_position,data_label_size)
save_plot(ggp,plot_height,plot_width,paste("plots/spatial_enrichment/fold_distribution_chr_",chromosome,"_labelled.png",sep=""))

data_label_size = 0
ggp = make_spatial_enrichment_fold_distribution_plot(chromosome,non_significant_colour,significant_colour,dot_size,dot_transparency,significant_name,non_significant_name,x_axis_label,y_axis_label,legend_position,data_label_size)
save_plot(ggp,plot_height,plot_width,paste("plots/spatial_enrichment/fold_distribution_chr_",chromosome,"_unlabelled.png",sep=""))
}

x_axis_label = "gene location"
y_axis_label = "gene density"

for (chromosome in chromosomes) 
{
ggp = make_spatial_enrichment_gene_distribution_plot(chromosome,non_significant_colour,significant_colour,density_curve_transparency,density_curve_line_thickness,significant_name,non_significant_name,x_axis_label,y_axis_label,legend_position)
save_plot(ggp,plot_height,plot_width,paste("plots/spatial_enrichment/gene_distribution_chr_",chromosome,".png",sep=""))
}

