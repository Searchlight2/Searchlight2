##---- general libraries ----##
library(ggplot2)
library(reshape)

##---- de sample and group names ----##
samples = c("WT_R1","WT_R2","WT_R3","KO_R1","KO_R2","KO_R3")
sample_groups = c("WT","KO")
sample_groupings = c("WT","WT","WT","KO","KO","KO")
sample_groupings = factor(sample_groupings, levels = sample_groups)
samples_by_sample_group = list(c("WT_R1","WT_R2","WT_R3"),c("KO_R1","KO_R2","KO_R3"))
comparisons = c("KO vs WT")

##---- sets the working directory. If you move the SL2 folder please update this path ----##
setwd("/home/john/Downloads/TEMP/DESEQ2/results/all_genes/de_workflows/KO_vs_WT")

##---- de input files ----##
de_annotated = read.table(file="data/de_annotated.csv", header=TRUE,row.names = 2, sep='\t', quote='',check.names = TRUE)
de_annotated_sig = read.table(file="data/de_annotated_significant.csv", header=TRUE,row.names = 2, sep='\t', quote='',check.names = TRUE)

##---- de parse ne matrix ----##
ne_matrix = de_annotated[,samples]
ne_matrix_sig = de_annotated_sig[,samples]

##---- transpose and scale ne matrix ----##
ne_matrix_transposed = data.frame(t(ne_matrix))
colnames(ne_matrix_transposed) = rownames(ne_matrix)

ne_matrix_scaled = data.frame(t(scale(t(ne_matrix))))
rownames(ne_matrix_scaled) = rownames(ne_matrix)
ne_matrix_scaled[do.call(cbind, lapply(ne_matrix_scaled, is.nan))] <- 0
ne_matrix_scaled = ne_matrix_scaled[is.finite(rowSums(ne_matrix_scaled)), ]

ne_matrix_scaled_transposed = data.frame(t(ne_matrix_scaled))
colnames(ne_matrix_scaled_transposed) = rownames(ne_matrix_scaled)

##---- SL2 Theme ----##
theme_SL2 <- function () { 
    theme_bw() %+replace% 
        theme(
	    panel.grid = element_blank(),
            panel.background = element_blank(),
            panel.border = element_rect(colour = "black", fill=NA, size=1),
            plot.background = element_blank(), 
            legend.background = element_rect(fill="transparent", colour=NA),
            legend.key = element_rect(fill="transparent", colour=NA),
            plot.title = element_text(size=16, margin = margin(b = 5),hjust=0,vjust=0.5, family="Arial", face="bold"),
            title = element_text(size = 16, margin = margin(b = 5),hjust=0,vjust=0.5, family="Arial", face="bold"),
            axis.text.y = element_text(size = 14, margin = margin(r = 5),hjust=1,vjust=0.5, family="Arial", face="bold",colour="black"),
            axis.text.x = element_text(size = 14, margin = margin(t = 5),hjust=0.5,vjust=1, family="Arial", face="bold",colour="black"), 
            axis.title.y = element_text(size = 16, margin = margin(r = 10),angle = 90,hjust=0.5,vjust=0.5, family="Arial", face="bold"),
            axis.title.x = element_text(size = 16, margin = margin(t = 10),hjust=0.5,vjust=1, family="Arial", face="bold"),
            legend.text=element_text(size=14, family="Arial", face="bold"),
            legend.title=element_blank(), 
            legend.key.size=unit(2.5,"line"),
            plot.margin=unit(c(0.4,0.4,0.4,0.4), "cm")
        )
}

##----- Default GGplot Colours Function -----##
gg_color_hue <- function(n) {
  hues = seq(15, 375, length = n + 1)
  hcl(h = hues, l = 65, c = 100)[1:n]
}

##---- Default Sample and Sample Group Colours  ----##
number_of_sample_groups = length(sample_groups)
default_sample_group_colours = gg_color_hue(number_of_sample_groups)
default_samples_colours = c(default_sample_group_colours[1],default_sample_group_colours[1],default_sample_group_colours[1],default_sample_group_colours[2],default_sample_group_colours[2],default_sample_group_colours[2])

##---- Default Sample Labels  ----##
default_sample_labels = c("WT_R1","WT_R2","WT_R3","KO_R1","KO_R2","KO_R3") # note: changing this won't change the order the samples appear on the plots. Merely what they are labelled as. 

##---- Default Sample Group Labels  ----##
default_sample_group_labels = c("WT","KO") # note: changing this won't change the order the groups appear on the plots. Merely what they are labelled as.

##---- Save Plot Function -----##
save_plot <- function(ggp,plot_height,plot_width,plot_path)
{
  png(plot_path, height=plot_height, width=plot_width, pointsize=5)
  print(ggp)
  dev.off()

  # clears all devices - as a safety measure
  while (dev.cur()>1) dev.off()
}

##----- PCA Scatter Plot Function -----##
make_PCA_scatterplot <- function(plot_sample_groupings,component_x,component_y,x_axis_label,y_axis_label,plot_sample_group_colours,plot_sample_group_labels,plot_sample_labels,dot_size,dot_transparency,legend_position,sample_label_size,show_proportion_of_variance)
{

  prcomp_data = prcomp(as.matrix(sapply(ne_matrix_scaled_transposed, as.numeric)))
  prcomp_coordinates = data.frame(prcomp_data$x)
    
  if (show_proportion_of_variance == TRUE) 
  {
    vars = apply(prcomp_data$x, 2, var)
    prop_x = round(vars[component_x] / sum(vars),4) * 100
    prop_y = round(vars[component_y] / sum(vars),4) * 100
    
    x_axis_label = paste(x_axis_label, " (",prop_x,"%)",sep="")
    y_axis_label = paste(y_axis_label, " (",prop_y,"%)",sep="")
  }
  
  ggp = ggplot(data=prcomp_coordinates, aes(x=prcomp_coordinates[,component_x], y=prcomp_coordinates[,component_y], colour=plot_sample_groupings, group=plot_sample_groupings,fill=plot_sample_groupings)) + geom_point(size=dot_size,alpha=dot_transparency) + scale_color_manual(values=plot_sample_group_colours,labels=plot_sample_group_labels, breaks=sample_groups) + scale_fill_manual(values=plot_sample_group_colours,labels=plot_sample_group_labels, breaks=sample_groups) + xlab(x_axis_label) + ylab(y_axis_label) + theme_SL2() + theme(legend.position=legend_position, legend.title = element_blank(), legend.spacing.x = unit(0.25, 'cm')) + geom_text(data=prcomp_coordinates,aes(label=plot_sample_labels),hjust=0.5, vjust=-1, size=sample_label_size, show.legend = FALSE) + xlim(c(min(prcomp_coordinates[,component_x])*1.25,max(prcomp_coordinates[,component_x])*1.25)) + ylim(c(min(prcomp_coordinates[,component_y])*1.25,max(prcomp_coordinates[,component_y])*1.25))                                                 
  return(ggp) 
}

##----- PCA (Scatter Plots) -----##

plot_height = 300
plot_width = 300
plot_sample_group_colours = default_sample_group_colours
plot_sample_group_labels = default_sample_group_labels
plot_sample_labels = default_sample_labels
plot_sample_groupings = sample_groupings
dot_size = 4
dot_transparency = 1
legend_position = "bottom"
sample_label_size = 4.5
show_proportion_of_variance = TRUE

component_x = 1
component_y = 2
x_axis_label = "PC1"
y_axis_label = "PC2"
ggp = make_PCA_scatterplot(plot_sample_groupings,component_x,component_y,x_axis_label,y_axis_label,plot_sample_group_colours,plot_sample_group_labels,plot_sample_labels,dot_size,dot_transparency,legend_position,sample_label_size,show_proportion_of_variance)
save_plot(ggp,plot_height,plot_width,"plots/PCA/PCA_1_vs_PCA_2_scatter_plot_labelled.png")

sample_label_size = 0 
ggp = make_PCA_scatterplot(plot_sample_groupings,component_x,component_y,x_axis_label,y_axis_label,plot_sample_group_colours,plot_sample_group_labels,plot_sample_labels,dot_size,dot_transparency,legend_position,sample_label_size,show_proportion_of_variance)
save_plot(ggp,plot_height,plot_width,"plots/PCA/PCA_1_vs_PCA_2_scatter_plot_unlabelled.png")

component_x = 3
component_y = 4
x_axis_label = "PC3"
y_axis_label = "PC4"
sample_label_size = 4.5
ggp = make_PCA_scatterplot(plot_sample_groupings,component_x,component_y,x_axis_label,y_axis_label,plot_sample_group_colours,plot_sample_group_labels,plot_sample_labels,dot_size,dot_transparency,legend_position,sample_label_size,show_proportion_of_variance)
save_plot(ggp,plot_height,plot_width,"plots/PCA/PCA_3_vs_PCA_4_scatter_plot_labelled.png")

sample_label_size = 0
ggp = make_PCA_scatterplot(plot_sample_groupings,component_x,component_y,x_axis_label,y_axis_label,plot_sample_group_colours,plot_sample_group_labels,plot_sample_labels,dot_size,dot_transparency,legend_position,sample_label_size,show_proportion_of_variance)
save_plot(ggp,plot_height,plot_width,"plots/PCA/PCA_3_vs_PCA_4_scatter_plot_unlabelled.png")

