##---- general libraries ----##
library(ggplot2)
library(reshape)

##---- de sample and group names ----##
samples = c("WT_R1","WT_R2","WT_R3","KO_R1","KO_R2","KO_R3")
sample_groups = c("WT","KO")
sample_groupings = c("WT","WT","WT","KO","KO","KO")
sample_groupings = factor(sample_groupings, levels = sample_groups)
samples_by_sample_group = list(c("WT_R1","WT_R2","WT_R3"),c("KO_R1","KO_R2","KO_R3"))
comparisons = c("KO vs WT")

##---- sets the working directory. If you move the SL2 folder please update this path ----##
setwd("/home/john/Downloads/TEMP/DESEQ2/results/all_genes/de_workflows/KO_vs_WT")

##---- de input files ----##
de_annotated = read.table(file="data/de_annotated.csv", header=TRUE,row.names = 2, sep='\t', quote='',check.names = TRUE)
de_annotated_sig = read.table(file="data/de_annotated_significant.csv", header=TRUE,row.names = 2, sep='\t', quote='',check.names = TRUE)

##---- de parse ne matrix ----##
ne_matrix = de_annotated[,samples]
ne_matrix_sig = de_annotated_sig[,samples]

##---- transpose and scale ne matrix ----##
ne_matrix_transposed = data.frame(t(ne_matrix))
colnames(ne_matrix_transposed) = rownames(ne_matrix)

ne_matrix_scaled = data.frame(t(scale(t(ne_matrix))))
rownames(ne_matrix_scaled) = rownames(ne_matrix)
ne_matrix_scaled[do.call(cbind, lapply(ne_matrix_scaled, is.nan))] <- 0
ne_matrix_scaled = ne_matrix_scaled[is.finite(rowSums(ne_matrix_scaled)), ]

ne_matrix_scaled_transposed = data.frame(t(ne_matrix_scaled))
colnames(ne_matrix_scaled_transposed) = rownames(ne_matrix_scaled)

##---- SL2 Theme ----##
theme_SL2 <- function () { 
    theme_bw() %+replace% 
        theme(
	    panel.grid = element_blank(),
            panel.background = element_blank(),
            panel.border = element_rect(colour = "black", fill=NA, size=1),
            plot.background = element_blank(), 
            legend.background = element_rect(fill="transparent", colour=NA),
            legend.key = element_rect(fill="transparent", colour=NA),
            plot.title = element_text(size=16, margin = margin(b = 5),hjust=0,vjust=0.5, family="Arial", face="bold"),
            title = element_text(size = 16, margin = margin(b = 5),hjust=0,vjust=0.5, family="Arial", face="bold"),
            axis.text.y = element_text(size = 14, margin = margin(r = 5),hjust=1,vjust=0.5, family="Arial", face="bold",colour="black"),
            axis.text.x = element_text(size = 14, margin = margin(t = 5),hjust=0.5,vjust=1, family="Arial", face="bold",colour="black"), 
            axis.title.y = element_text(size = 16, margin = margin(r = 10),angle = 90,hjust=0.5,vjust=0.5, family="Arial", face="bold"),
            axis.title.x = element_text(size = 16, margin = margin(t = 10),hjust=0.5,vjust=1, family="Arial", face="bold"),
            legend.text=element_text(size=14, family="Arial", face="bold"),
            legend.title=element_blank(), 
            legend.key.size=unit(2.5,"line"),
            plot.margin=unit(c(0.4,0.4,0.4,0.4), "cm")
        )
}

##----- Default GGplot Colours Function -----##
gg_color_hue <- function(n) {
  hues = seq(15, 375, length = n + 1)
  hcl(h = hues, l = 65, c = 100)[1:n]
}

##---- Default Sample and Sample Group Colours  ----##
number_of_sample_groups = length(sample_groups)
default_sample_group_colours = gg_color_hue(number_of_sample_groups)
default_samples_colours = c(default_sample_group_colours[1],default_sample_group_colours[1],default_sample_group_colours[1],default_sample_group_colours[2],default_sample_group_colours[2],default_sample_group_colours[2])

##---- Default Sample Group Labels  ----##
default_sample_group_labels = c("WT","KO") # note: changing this won't change the order the groups appear on the plots. Merely what they are labelled as.

##---- Save Plot Function -----##
save_plot <- function(ggp,plot_height,plot_width,plot_path)
{
  png(plot_path, height=plot_height, width=plot_width, pointsize=5)
  print(ggp)
  dev.off()

  # clears all devices - as a safety measure
  while (dev.cur()>1) dev.off()
}

##---- Top 10 Genes by Mean Expression Function ----##
get_top_10_genes_by_mean_expression <- function(index) {
  samples_in_sample_group = unlist(samples_by_sample_group[index])
  top_10_genes = row.names(head(ne_matrix[order(rowMeans(ne_matrix[,samples_in_sample_group]),decreasing=TRUE),],10))
  return(top_10_genes)
}

##----- Gene Expression Violin Plot Function  -----##
make_gene_expression_violin_plot <- function(matrix,gene,violin_transparency,violin_width,violin_line_thickness,violin_colours,violin_labels,trim_violin,jitter_dot_size,jitter_dot_colour,jitter_dot_width,summary_colour,summary_size,x_axis_label,y_axis_label,legend_position)
{
  ggp = ggplot(matrix, aes(x=sample_groupings, y=matrix[[gene]], color=sample_groupings, group=sample_groupings, fill=sample_groupings)) + geom_violin(trim=trim_violin, scale="width", width=violin_width, alpha = violin_transparency, size=violin_line_thickness) + geom_jitter(size=jitter_dot_size, colour=jitter_dot_colour, width=jitter_dot_width, height=0, show.legend = FALSE) + stat_summary(position=position_dodge(0.75), colour = summary_colour, size = summary_size, geom="pointrange", show.legend = FALSE) + scale_color_manual(values=violin_colours,breaks=sample_groups,labels=violin_labels,limits=sample_groups) + scale_fill_manual(values=violin_colours,breaks=sample_groups,labels=violin_labels,limits=sample_groups) + scale_x_discrete(breaks=sample_groups,labels=violin_labels,limits=sample_groups) + ylim(0, max(matrix[[gene]] * 1.25)) + xlab(x_axis_label) + ylab(y_axis_label) + ggtitle(gene) + theme_SL2() + theme(legend.position=legend_position, axis.text.x = element_text(angle = 45, hjust = 1))
  return(ggp)
}

##----- Most Expressed Genes (Violin Plots) -----##

plot_height = 300
plot_width = 300
violin_transparency = 0.5
violin_width = 0.75
violin_line_thickness = 1
violin_colours = default_sample_group_colours 	# note: changing this won't change the order the groups appear in the x axis. Merely what they are coloured as.
violin_labels = default_sample_group_labels	# note: changing this won't change the order the groups appear in the x axis. Merely what they are named as.
trim_violin = FALSE
jitter_dot_size = 2
jitter_dot_colour = "black"
jitter_dot_width = 0.2
summary_colour = "red"
summary_size = 0.25
x_axis_label = ""
y_axis_label = "expression"
legend_position = "none"

for(sample_group_index in 1:length(sample_groups))
{
  sample_group = sample_groups[sample_group_index]
  top_10_genes = get_top_10_genes_by_mean_expression(sample_group_index)
  
  for (gene_index in 1:10)
  {
    gene = top_10_genes[gene_index]
    ggp = make_gene_expression_violin_plot(ne_matrix_transposed,gene,violin_transparency,violin_width,violin_line_thickness,violin_colours,violin_labels,trim_violin,jitter_dot_size,jitter_dot_colour,jitter_dot_width,summary_colour,summary_size,x_axis_label,y_axis_label,legend_position)
    save_plot(ggp,plot_height,plot_width,paste("plots/most_expressed_genes/",sample_group,"_no.",gene_index,"_most_expressed_gene.png",sep=""))
  }
}

