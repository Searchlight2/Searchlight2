##---- general libraries ----##
library(ggplot2)
library(reshape)

##---- de sample and group names ----##
samples = c("WT_R1","WT_R2","WT_R3","KO_R1","KO_R2","KO_R3")
sample_groups = c("WT","KO")
sample_groupings = c("WT","WT","WT","KO","KO","KO")
sample_groupings = factor(sample_groupings, levels = sample_groups)
samples_by_sample_group = list(c("WT_R1","WT_R2","WT_R3"),c("KO_R1","KO_R2","KO_R3"))
comparisons = c("KO vs WT")

##---- sets the working directory. If you move the SL2 folder please update this path ----##
setwd("/home/john/Downloads/TEMP/DESEQ2/results/all_genes/de_workflows/KO_vs_WT")

##---- de input files ----##
de_annotated = read.table(file="data/de_annotated.csv", header=TRUE,row.names = 2, sep='\t', quote='',check.names = TRUE)
de_annotated_sig = read.table(file="data/de_annotated_significant.csv", header=TRUE,row.names = 2, sep='\t', quote='',check.names = TRUE)

##---- de parse ne matrix ----##
ne_matrix = de_annotated[,samples]
ne_matrix_sig = de_annotated_sig[,samples]

##---- SL2 Theme ----##
theme_SL2 <- function () { 
    theme_bw() %+replace% 
        theme(
	    panel.grid = element_blank(),
            panel.background = element_blank(),
            panel.border = element_rect(colour = "black", fill=NA, size=1),
            plot.background = element_blank(), 
            legend.background = element_rect(fill="transparent", colour=NA),
            legend.key = element_rect(fill="transparent", colour=NA),
            plot.title = element_text(size=16, margin = margin(b = 5),hjust=0,vjust=0.5, family="Arial", face="bold"),
            title = element_text(size = 16, margin = margin(b = 5),hjust=0,vjust=0.5, family="Arial", face="bold"),
            axis.text.y = element_text(size = 14, margin = margin(r = 5),hjust=1,vjust=0.5, family="Arial", face="bold",colour="black"),
            axis.text.x = element_text(size = 14, margin = margin(t = 5),hjust=0.5,vjust=1, family="Arial", face="bold",colour="black"), 
            axis.title.y = element_text(size = 16, margin = margin(r = 10),angle = 90,hjust=0.5,vjust=0.5, family="Arial", face="bold"),
            axis.title.x = element_text(size = 16, margin = margin(t = 10),hjust=0.5,vjust=1, family="Arial", face="bold"),
            legend.text=element_text(size=14, family="Arial", face="bold"),
            legend.title=element_blank(), 
            legend.key.size=unit(2.5,"line"),
            plot.margin=unit(c(0.4,0.4,0.4,0.4), "cm")
        )
}

##----- Default GGplot Colours Function -----##
gg_color_hue <- function(n) {
  hues = seq(15, 375, length = n + 1)
  hcl(h = hues, l = 65, c = 100)[1:n]
}

##---- Default Sample and Sample Group Colours  ----##
number_of_sample_groups = length(sample_groups)
default_sample_group_colours = gg_color_hue(number_of_sample_groups)
default_samples_colours = c(default_sample_group_colours[1],default_sample_group_colours[1],default_sample_group_colours[1],default_sample_group_colours[2],default_sample_group_colours[2],default_sample_group_colours[2])

##---- Default Sample Labels  ----##
default_sample_labels = c("WT_R1","WT_R2","WT_R3","KO_R1","KO_R2","KO_R3") # note: changing this won't change the order the samples appear on the plots. Merely what they are labelled as. 

##---- Save Plot Function -----##
save_plot <- function(ggp,plot_height,plot_width,plot_path)
{
  png(plot_path, height=plot_height, width=plot_width, pointsize=5)
  print(ggp)
  dev.off()

  # clears all devices - as a safety measure
  while (dev.cur()>1) dev.off()
}

##----- Distribution of Expression Values Function -----##
make_distribution_of_expression_values_plot <- function(plot_sample,plot_colour,transparency,line_thickness,x_axis_label,y_axis_label,legend_position) 
{
  ggp = ggplot(ne_matrix, aes(log(x=ne_matrix[[plot_sample]]+0.001,10))) + geom_density(colour=plot_colour,fill=plot_colour, alpha=transparency,size=line_thickness) + xlab(x_axis_label) + ylab(y_axis_label) + ggtitle(plot_sample) + theme_SL2() + theme(legend.position=legend_position) + scale_x_continuous(expand=c(0,0)) + scale_y_continuous(expand=c(0,0))
  return(ggp)
}

##----- Distribution of Expression Values -----##

plot_height = 250
plot_width = 250
transparency = 0.5
line_thickness = 1
x_axis_label = "expression (log10)"
y_axis_label = "density"
legend_position = "none"

for(plot_sample_index in 1:length(samples))
{
  plot_sample = samples[plot_sample_index]
  plot_colour = default_samples_colours[plot_sample_index]
  ggp = make_distribution_of_expression_values_plot(plot_sample,plot_colour,transparency,line_thickness,x_axis_label,y_axis_label,legend_position)
  save_plot(ggp,plot_height,plot_width,paste("plots/distribution_of_expression_values/",plot_sample,"_distribution_of_expression_values.png",sep=""))
}

