##---- general libraries ----##
library(ggplot2)
library(reshape)

##---- table libraries ----##
library(grid)
library(gridExtra)
library(gtable)

##---- sets the working directory. If you move the SL2 folder please update this path ----##
setwd("/home/john/Downloads/TEMP/DESEQ2/results/all_genes/de_workflows/KO_RESCUE_vs_KO")

##---- spatial analysis input files ----##
spatial_enrichment_summary = read.table(file="data/statistical_analysis/spatial_enrichment/spatial_enrichment_summary.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
spatial_enrichment_gene_data = read.table(file="data/statistical_analysis/spatial_enrichment/spatial_enrichment_gene_data.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)

##---- SL2 Theme ----##
theme_SL2 <- function () { 
    theme_bw() %+replace% 
        theme(
	    panel.grid = element_blank(),
            panel.background = element_blank(),
            panel.border = element_rect(colour = "black", fill=NA, size=1),
            plot.background = element_blank(), 
            legend.background = element_rect(fill="transparent", colour=NA),
            legend.key = element_rect(fill="transparent", colour=NA),
            plot.title = element_text(size=16, margin = margin(b = 5),hjust=0,vjust=0.5, family="Arial", face="bold"),
            title = element_text(size = 16, margin = margin(b = 5),hjust=0,vjust=0.5, family="Arial", face="bold"),
            axis.text.y = element_text(size = 14, margin = margin(r = 5),hjust=1,vjust=0.5, family="Arial", face="bold",colour="black"),
            axis.text.x = element_text(size = 14, margin = margin(t = 5),hjust=0.5,vjust=1, family="Arial", face="bold",colour="black"), 
            axis.title.y = element_text(size = 16, margin = margin(r = 10),angle = 90,hjust=0.5,vjust=0.5, family="Arial", face="bold"),
            axis.title.x = element_text(size = 16, margin = margin(t = 10),hjust=0.5,vjust=1, family="Arial", face="bold"),
            legend.text=element_text(size=14, family="Arial", face="bold"),
            legend.title=element_blank(), 
            legend.key.size=unit(2.5,"line"),
            plot.margin=unit(c(0.4,0.4,0.4,0.4), "cm")
        )
}

##---- Save Table Function -----##
save_table <- function(gt,plot_height,plot_width,plot_path)
{
  png(plot_path, height=plot_height, width=plot_width, pointsize=5)
  grid.arrange(gt)
  dev.off()

  while (dev.cur()>1) dev.off()
}

##----- Spatial Enrichement Table Function  -----##
make_spatial_enrichment_table <- function(spatial_enrichment_summary,header_size,text_size,border_thickness)
{
  spatial_enrichment_summary_table = spatial_enrichment_summary[,c("chromosome","total_genes","expressed_genes","de_valid_genes","significant_genes","upregulated_genes","downregulated_genes","expressed_genes_bias_log2fold","expressed_genes_bias_p","significant_genes_bias_log2fold","significant_genes_bias_p","direction_bias_swing","direction_bias_p")]
  colnames(spatial_enrichment_summary_table) = c("chromosome","total genes","expressed genes","de valid genes","significant genes","upregulated genes","downregulated genes","expressed genes bias (log2fold)","expressed genes bias (p)","significant genes bias (log2fold)","significant genes bias (p)","direction bias (swing)","direction bias (p)")
  spatial_enrichment_summary_table = spatial_enrichment_summary_table[order(as.numeric(as.character(spatial_enrichment_summary_table$chromosome))),]
  table_theme <- gridExtra::ttheme_minimal(core = list(fg_params=list(cex = text_size)),colhead = list(fg_params=list(cex = header_size)))

  gt <- tableGrob(spatial_enrichment_summary_table, theme=table_theme, rows=NULL)
  gt <- gtable_add_grob(gt,grobs = rectGrob(gp = gpar(fill = NA, lwd = border_thickness)),t = 2, b = nrow(gt), l = 1, r = ncol(gt))
  gt <- gtable_add_grob(gt,grobs = rectGrob(gp = gpar(fill = NA, lwd = border_thickness)),t = 1, l = 1, r = ncol(gt))
  gt <- gtable_add_grob(gt,grobs = rectGrob(gp = gpar(fill = NA, lwd = border_thickness)),t = 1, b = nrow(gt), l = 1, r = 1)
  
  return(gt)
}

##----- Spatial Enrichement (Table) -----##

plot_height = 700
plot_width = 2100
header_size = 1.25
text_size = 1.25
border_thickness = 2

gt = make_spatial_enrichment_table(spatial_enrichment_summary,header_size,text_size,border_thickness)
save_table(gt,plot_height,plot_width,"plots/spatial_enrichment/spatial_enrichment_table.png")

