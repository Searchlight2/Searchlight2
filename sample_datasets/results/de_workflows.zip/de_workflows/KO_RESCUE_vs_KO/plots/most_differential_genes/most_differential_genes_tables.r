##---- general libraries ----##
library(ggplot2)
library(reshape)

##---- table libraries ----##
library(grid)
library(gridExtra)
library(gtable)

##---- de sample and group names ----##
samples = c("KO_R1","KO_R2","KO_R3","KO_RESCUE_R1","KO_RESCUE_R2","KO_RESCUE_R3")
sample_groups = c("KO","KO_RESCUE")
sample_groupings = c("KO","KO","KO","KO_RESCUE","KO_RESCUE","KO_RESCUE")
sample_groupings = factor(sample_groupings, levels = sample_groups)
samples_by_sample_group = list(c("KO_R1","KO_R2","KO_R3"),c("KO_RESCUE_R1","KO_RESCUE_R2","KO_RESCUE_R3"))
comparisons = c("KO_RESCUE vs KO")

##---- sets the working directory. If you move the SL2 folder please update this path ----##
setwd("/home/john/Downloads/TEMP/DESEQ2/results/all_genes/de_workflows/KO_RESCUE_vs_KO")

##---- de input files ----##
de_annotated = read.table(file="data/de_annotated.csv", header=TRUE,row.names = 2, sep='\t', quote='',check.names = TRUE)
de_annotated_sig = read.table(file="data/de_annotated_significant.csv", header=TRUE,row.names = 2, sep='\t', quote='',check.names = TRUE)

##---- de parse ne matrix ----##
ne_matrix = de_annotated[,samples]
ne_matrix_sig = de_annotated_sig[,samples]

##---- transpose and scale ne matrix ----##
ne_matrix_transposed = data.frame(t(ne_matrix))
colnames(ne_matrix_transposed) = rownames(ne_matrix)

ne_matrix_scaled = data.frame(t(scale(t(ne_matrix))))
rownames(ne_matrix_scaled) = rownames(ne_matrix)
ne_matrix_scaled[do.call(cbind, lapply(ne_matrix_scaled, is.nan))] <- 0
ne_matrix_scaled = ne_matrix_scaled[is.finite(rowSums(ne_matrix_scaled)), ]

ne_matrix_scaled_transposed = data.frame(t(ne_matrix_scaled))
colnames(ne_matrix_scaled_transposed) = rownames(ne_matrix_scaled)

##---- SL2 Theme ----##
theme_SL2 <- function () { 
    theme_bw() %+replace% 
        theme(
	    panel.grid = element_blank(),
            panel.background = element_blank(),
            panel.border = element_rect(colour = "black", fill=NA, size=1),
            plot.background = element_blank(), 
            legend.background = element_rect(fill="transparent", colour=NA),
            legend.key = element_rect(fill="transparent", colour=NA),
            plot.title = element_text(size=16, margin = margin(b = 5),hjust=0,vjust=0.5, family="Arial", face="bold"),
            title = element_text(size = 16, margin = margin(b = 5),hjust=0,vjust=0.5, family="Arial", face="bold"),
            axis.text.y = element_text(size = 14, margin = margin(r = 5),hjust=1,vjust=0.5, family="Arial", face="bold",colour="black"),
            axis.text.x = element_text(size = 14, margin = margin(t = 5),hjust=0.5,vjust=1, family="Arial", face="bold",colour="black"), 
            axis.title.y = element_text(size = 16, margin = margin(r = 10),angle = 90,hjust=0.5,vjust=0.5, family="Arial", face="bold"),
            axis.title.x = element_text(size = 16, margin = margin(t = 10),hjust=0.5,vjust=1, family="Arial", face="bold"),
            legend.text=element_text(size=14, family="Arial", face="bold"),
            legend.title=element_blank(), 
            legend.key.size=unit(2.5,"line"),
            plot.margin=unit(c(0.4,0.4,0.4,0.4), "cm")
        )
}

##---- Save Table Function -----##
save_table <- function(gt,plot_height,plot_width,plot_path)
{
  png(plot_path, height=plot_height, width=plot_width, pointsize=5)
  grid.arrange(gt)
  dev.off()

  while (dev.cur()>1) dev.off()
}

##---- Top 10 Differential Genes Function ----##
get_top_10_differential_genes <- function(direction,type) {

  if(type=="log2fold") 
  {
    top_10_genes = row.names(head(de_annotated[order(de_annotated$log2fold,decreasing=direction),],10))
  }
  if(type=="p")
  {
    if (direction == TRUE) {de_annotated_direction = subset(de_annotated,log2fold > 0)}
    else {de_annotated_direction = subset(de_annotated,log2fold < 0)}
    top_10_genes = row.names(head(de_annotated_direction[order(de_annotated_direction$p,decreasing=FALSE),],10))
  }
  return(top_10_genes)
}

##----- Most Differential Genes Table Function -----##
make_most_differential_genes_table <- function(top_10_genes,header_size,text_size,border_thickness)
{
  de_annotated_top_10 = de_annotated[top_10_genes,]
  de_annotated_top_10$Gene = row.names(de_annotated_top_10)
  de_annotated_top_10 = de_annotated_top_10[,c("Gene","log2fold","p","p.adj")]

  table_theme <- gridExtra::ttheme_minimal(core = list(fg_params=list(cex = text_size)),colhead = list(fg_params=list(cex = header_size)))

  gt <- tableGrob(de_annotated_top_10, theme=table_theme, rows=NULL)
  gt <- gtable_add_grob(gt,grobs = rectGrob(gp = gpar(fill = NA, lwd = border_thickness)),t = 2, b = nrow(gt), l = 1, r = ncol(gt))
  gt <- gtable_add_grob(gt,grobs = rectGrob(gp = gpar(fill = NA, lwd = border_thickness)),t = 1, l = 1, r = ncol(gt))
  gt <- gtable_add_grob(gt,grobs = rectGrob(gp = gpar(fill = NA, lwd = border_thickness)),t = 1, b = nrow(gt), l = 1, r = 1)
  
  return(gt)
}

##----- Most Differential Genes (Tables) -----##

plot_height = 300
plot_width = 400
header_size = 1.25
text_size = 1.25
border_thickness = 2

top_10_genes = get_top_10_differential_genes(TRUE,"p") # upregulated, by p
gt = make_most_differential_genes_table(top_10_genes,header_size,text_size,border_thickness)
save_table(gt,plot_height,plot_width,"plots/most_differential_genes/most_upregulated_by_p_value/most_upregulated_genes_table.png")

top_10_genes = get_top_10_differential_genes(FALSE,"p") # downregulated, by p
gt = make_most_differential_genes_table(top_10_genes,header_size,text_size,border_thickness)
save_table(gt,plot_height,plot_width,"plots/most_differential_genes/most_downregulated_by_p_value/most_downregulated_genes_table.png")

top_10_genes = get_top_10_differential_genes(TRUE,"log2fold") # upregulated, by log2fold
gt = make_most_differential_genes_table(top_10_genes,header_size,text_size,border_thickness)
save_table(gt,plot_height,plot_width,"plots/most_differential_genes/most_upregulated_by_log2fold/most_upregulated_genes_table.png")

top_10_genes = get_top_10_differential_genes(FALSE,"log2fold") # downregulated, by log2fold
gt = make_most_differential_genes_table(top_10_genes,header_size,text_size,border_thickness)
save_table(gt,plot_height,plot_width,"plots/most_differential_genes/most_downregulated_by_log2fold/most_downregulated_genes_table.png")

