##---- general libraries ----##
library(ggplot2)
library(reshape)

##---- de sample and group names ----##
samples = c("KO_R1","KO_R2","KO_R3","KO_RESCUE_R1","KO_RESCUE_R2","KO_RESCUE_R3")
sample_groups = c("KO","KO_RESCUE")
sample_groupings = c("KO","KO","KO","KO_RESCUE","KO_RESCUE","KO_RESCUE")
sample_groupings = factor(sample_groupings, levels = sample_groups)
samples_by_sample_group = list(c("KO_R1","KO_R2","KO_R3"),c("KO_RESCUE_R1","KO_RESCUE_R2","KO_RESCUE_R3"))
comparisons = c("KO_RESCUE vs KO")

##---- sets the working directory. If you move the SL2 folder please update this path ----##
setwd("/home/john/Downloads/TEMP/DESEQ2/results/all_genes/de_workflows/KO_RESCUE_vs_KO")

##---- de input files ----##
de_annotated = read.table(file="data/de_annotated.csv", header=TRUE,row.names = 2, sep='\t', quote='',check.names = TRUE)
de_annotated_sig = read.table(file="data/de_annotated_significant.csv", header=TRUE,row.names = 2, sep='\t', quote='',check.names = TRUE)

##---- de hypergeometric gene set enrichment files ----##
GO_BP_all_gene_sets = read.table(file="data/statistical_analysis/over_representation_analysis/GO_BP/all_significant_genes/all_gene_sets_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
GO_BP_all_signficant_genes_enriched_gene_sets = read.table(file="data/statistical_analysis/over_representation_analysis/GO_BP/all_significant_genes/enriched_gene_sets_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
GO_BP_all_signficant_genes_underenriched_gene_sets = read.table(file="data/statistical_analysis/over_representation_analysis/GO_BP/all_significant_genes/underenriched_gene_sets_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
GO_BP_upregulated_gene_sets = read.table(file="data/statistical_analysis/over_representation_analysis/GO_BP/upregulated_genes/all_gene_sets_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
GO_BP_upregulated_enriched_gene_sets = read.table(file="data/statistical_analysis/over_representation_analysis/GO_BP/upregulated_genes/enriched_gene_sets_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
GO_BP_upregulated_underenriched_gene_sets = read.table(file="data/statistical_analysis/over_representation_analysis/GO_BP/upregulated_genes/underenriched_gene_sets_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
GO_BP_downregulated_gene_sets = read.table(file="data/statistical_analysis/over_representation_analysis/GO_BP/downregulated_genes/all_gene_sets_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
GO_BP_downregulated_enriched_gene_sets = read.table(file="data/statistical_analysis/over_representation_analysis/GO_BP/downregulated_genes/enriched_gene_sets_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
GO_BP_downregulated_underenriched_gene_sets = read.table(file="data/statistical_analysis/over_representation_analysis/GO_BP/downregulated_genes/underenriched_gene_sets_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)

##---- de parse ne matrix ----##
ne_matrix = de_annotated[,samples]
ne_matrix_sig = de_annotated_sig[,samples]

##---- transpose and scale ne matrix ----##
ne_matrix_transposed = data.frame(t(ne_matrix))
colnames(ne_matrix_transposed) = rownames(ne_matrix)

ne_matrix_scaled = data.frame(t(scale(t(ne_matrix))))
rownames(ne_matrix_scaled) = rownames(ne_matrix)
ne_matrix_scaled[do.call(cbind, lapply(ne_matrix_scaled, is.nan))] <- 0
ne_matrix_scaled = ne_matrix_scaled[is.finite(rowSums(ne_matrix_scaled)), ]

ne_matrix_scaled_transposed = data.frame(t(ne_matrix_scaled))
colnames(ne_matrix_scaled_transposed) = rownames(ne_matrix_scaled)

##---- SL2 Theme ----##
theme_SL2 <- function () { 
    theme_bw() %+replace% 
        theme(
	    panel.grid = element_blank(),
            panel.background = element_blank(),
            panel.border = element_rect(colour = "black", fill=NA, size=1),
            plot.background = element_blank(), 
            legend.background = element_rect(fill="transparent", colour=NA),
            legend.key = element_rect(fill="transparent", colour=NA),
            plot.title = element_text(size=16, margin = margin(b = 5),hjust=0,vjust=0.5, family="Arial", face="bold"),
            title = element_text(size = 16, margin = margin(b = 5),hjust=0,vjust=0.5, family="Arial", face="bold"),
            axis.text.y = element_text(size = 14, margin = margin(r = 5),hjust=1,vjust=0.5, family="Arial", face="bold",colour="black"),
            axis.text.x = element_text(size = 14, margin = margin(t = 5),hjust=0.5,vjust=1, family="Arial", face="bold",colour="black"), 
            axis.title.y = element_text(size = 16, margin = margin(r = 10),angle = 90,hjust=0.5,vjust=0.5, family="Arial", face="bold"),
            axis.title.x = element_text(size = 16, margin = margin(t = 10),hjust=0.5,vjust=1, family="Arial", face="bold"),
            legend.text=element_text(size=14, family="Arial", face="bold"),
            legend.title=element_blank(), 
            legend.key.size=unit(2.5,"line"),
            plot.margin=unit(c(0.4,0.4,0.4,0.4), "cm")
        )
}

##----- Default GGplot Colours Function -----##
gg_color_hue <- function(n) {
  hues = seq(15, 375, length = n + 1)
  hcl(h = hues, l = 65, c = 100)[1:n]
}

##---- Default Sample and Sample Group Colours  ----##
number_of_sample_groups = length(sample_groups)
default_sample_group_colours = gg_color_hue(number_of_sample_groups)
default_samples_colours = c(default_sample_group_colours[1],default_sample_group_colours[1],default_sample_group_colours[1],default_sample_group_colours[2],default_sample_group_colours[2],default_sample_group_colours[2])

##---- Default Sample Group Labels  ----##
default_sample_group_labels = c("KO","KO_RESCUE") # note: changing this won't change the order the groups appear on the plots. Merely what they are labelled as.

##---- Save Plot Function -----##
save_plot <- function(ggp,plot_height,plot_width,plot_path)
{
  png(plot_path, height=plot_height, width=plot_width, pointsize=5)
  print(ggp)
  dev.off()

  # clears all devices - as a safety measure
  while (dev.cur()>1) dev.off()
}

##---- Top 10 Gene Sets by Hypergeometric P-value Function ----##
get_top10_oras_by_p_value <- function(gene_sets,enriched_gene_sets,type) {

  if(type=="enrichment")
  {
    top_10_gene_sets = head(gene_sets[order(gene_sets$enrichment_p_value,decreasing=FALSE),],10)
    top_10_gene_sets = top_10_gene_sets[,c("gene_set","enrichment_p_value","overlapping_genes","log2_fold_enrichment","overlapping_gene_names")]
  }
  if(type=="underenrichment")
  {
    top_10_gene_sets = head(gene_sets[order(gene_sets$underenrichment_p_value,decreasing=FALSE),],10)
    top_10_gene_sets = top_10_gene_sets[,c("gene_set","underenrichment_p_value","overlapping_genes","log2_fold_enrichment","overlapping_gene_names")]
  }
  top_10_gene_sets$significant = top_10_gene_sets$gene_set %in% enriched_gene_sets$gene_set
  top_10_gene_sets$significant = as.character(top_10_gene_sets$significant)
  colnames(top_10_gene_sets) = c("gene_set","p","overlapping_genes","log2_fold_enrichment","overlapping_gene_names","significant")
  return(top_10_gene_sets)
}

##----- Hypergeometric Gene Set Boxplot Function -----##
make_ora_boxplot <- function(gene_set,plot_title,box_transparency,box_line_thickness,box_colours,box_labels,x_axis_label,y_axis_label,legend_position)
{
  genes_in_gene_set = unlist(lapply(gene_set$overlapping_gene_names, function(x) unlist(strsplit(as.character(x),","))))
  if(length(genes_in_gene_set) > 1) 
  {
    ne_matrix_scaled_transposed_genes_in_gene_set = ne_matrix_scaled_transposed[,genes_in_gene_set]
    ne_matrix_scaled_transposed_genes_in_gene_set$sample_groupings = sample_groupings
    ne_matrix_scaled_transposed_genes_in_gene_set_melted = melt(ne_matrix_scaled_transposed_genes_in_gene_set,id.vars = "sample_groupings")
    ggp = ggplot(ne_matrix_scaled_transposed_genes_in_gene_set_melted, aes(x=variable, y=value, fill=sample_groupings)) + geom_boxplot(position=position_dodge(0.75),outlier.shape = NA, alpha=box_transparency,size=box_line_thickness) + theme_SL2() + theme(axis.text.x = element_text(angle = 90, hjust=1, vjust=0.5),legend.position=legend_position) + ggtitle(plot_title) + scale_color_manual(values=box_colours,breaks=sample_groups,labels=box_labels) + scale_fill_manual(values=box_colours,breaks=sample_groups,labels=box_labels) + xlab(x_axis_label) + ylab(y_axis_label)
    return(ggp)
  }
  return(ggplot(data.frame()) + theme_SL2() + geom_blank() + ggtitle("There were too few genes to sensibly plot this."))
}

##----- Hypergeometric Enriched Gene Sets (Boxplot) -----##

plot_height = 250
plot_width = 1000
box_transparency = 0.75
box_line_thickness = 0.75
box_colours = default_sample_group_colours 	# note: changing this won't change the order the groups appear in the x axis. Merely what they are coloured as.
box_labels = default_sample_group_labels	# note: changing this won't change the order the groups appear in the x axis. Merely what they are named as.
x_axis_label = ""
y_axis_label = "expression (z-score)"
legend_position = "right"

top_10_gene_sets = get_top10_oras_by_p_value(GO_BP_all_gene_sets,GO_BP_all_signficant_genes_enriched_gene_sets,"enrichment")
for(gene_set_index in 1:10)
{
  gene_set = top_10_gene_sets[gene_set_index,]
  plot_title = gene_set[["gene_set"]]
  ggp = make_ora_boxplot(gene_set,plot_title,box_transparency,box_line_thickness,box_colours,box_labels,x_axis_label,y_axis_label,legend_position)
  save_plot(ggp,plot_height,plot_width,paste("plots/over_representation_analysis/GO_BP/enriched_amongst_all_significant_genes/no.",gene_set_index,"_most_enriched_gene_set.png",sep=""))
}

top_10_gene_sets = get_top10_oras_by_p_value(GO_BP_downregulated_gene_sets,GO_BP_downregulated_enriched_gene_sets,"enrichment")
for(gene_set_index in 1:10)
{
  gene_set = top_10_gene_sets[gene_set_index,]
  plot_title = gene_set[["gene_set"]]
  ggp = make_ora_boxplot(gene_set,plot_title,box_transparency,box_line_thickness,box_colours,box_labels,x_axis_label,y_axis_label,legend_position)
  save_plot(ggp,plot_height,plot_width,paste("plots/over_representation_analysis/GO_BP/enriched_amongst_downregulated_genes/no.",gene_set_index,"_most_enriched_gene_set.png",sep=""))
}

top_10_gene_sets = get_top10_oras_by_p_value(GO_BP_upregulated_gene_sets,GO_BP_upregulated_enriched_gene_sets,"enrichment")
for(gene_set_index in 1:10)
{
  gene_set = top_10_gene_sets[gene_set_index,]
  plot_title = gene_set[["gene_set"]]
  ggp = make_ora_boxplot(gene_set,plot_title,box_transparency,box_line_thickness,box_colours,box_labels,x_axis_label,y_axis_label,legend_position)
  save_plot(ggp,plot_height,plot_width,paste("plots/over_representation_analysis/GO_BP/enriched_amongst_upregulated_genes/no.",gene_set_index,"_most_enriched_gene_set.png",sep=""))
}


