##---- general libraries ----##
library(ggplot2)
library(reshape)

##---- de sample and group names ----##
samples = c("KO_R1","KO_R2","KO_R3","KO_RESCUE_R1","KO_RESCUE_R2","KO_RESCUE_R3")
sample_groups = c("KO","KO_RESCUE")
sample_groupings = c("KO","KO","KO","KO_RESCUE","KO_RESCUE","KO_RESCUE")
sample_groupings = factor(sample_groupings, levels = sample_groups)
samples_by_sample_group = list(c("KO_R1","KO_R2","KO_R3"),c("KO_RESCUE_R1","KO_RESCUE_R2","KO_RESCUE_R3"))
comparisons = c("KO_RESCUE vs KO")

##---- sets the working directory. If you move the SL2 folder please update this path ----##
setwd("/home/john/Downloads/TEMP/DESEQ2/results/all_genes/de_workflows/KO_RESCUE_vs_KO")

##---- de input files ----##
de_annotated = read.table(file="data/de_annotated.csv", header=TRUE,row.names = 2, sep='\t', quote='',check.names = TRUE)
de_annotated_sig = read.table(file="data/de_annotated_significant.csv", header=TRUE,row.names = 2, sep='\t', quote='',check.names = TRUE)

##---- IPA upstream regulator activation and enrichment files ----##
TRUSST_all_gene_sets = read.table(file="data/statistical_analysis/upstream_regulator_analysis/TRUSST/all_uregs_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
TRUSST_enriched_gene_sets = read.table(file="data/statistical_analysis/upstream_regulator_analysis/TRUSST/enriched_uregs_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
TRUSST_activated_gene_sets = read.table(file="data/statistical_analysis/upstream_regulator_analysis/TRUSST/activated_uregs_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
TRUSST_enriched_and_activated_gene_sets = read.table(file="data/statistical_analysis/upstream_regulator_analysis/TRUSST/enriched_and_activated_uregs_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)

##---- de parse ne matrix ----##
ne_matrix = de_annotated[,samples]
ne_matrix_sig = de_annotated_sig[,samples]

##---- transpose and scale ne matrix ----##
ne_matrix_transposed = data.frame(t(ne_matrix))
colnames(ne_matrix_transposed) = rownames(ne_matrix)

ne_matrix_scaled = data.frame(t(scale(t(ne_matrix))))
rownames(ne_matrix_scaled) = rownames(ne_matrix)
ne_matrix_scaled[do.call(cbind, lapply(ne_matrix_scaled, is.nan))] <- 0
ne_matrix_scaled = ne_matrix_scaled[is.finite(rowSums(ne_matrix_scaled)), ]

ne_matrix_scaled_transposed = data.frame(t(ne_matrix_scaled))
colnames(ne_matrix_scaled_transposed) = rownames(ne_matrix_scaled)

##---- SL2 Theme ----##
theme_SL2 <- function () { 
    theme_bw() %+replace% 
        theme(
	    panel.grid = element_blank(),
            panel.background = element_blank(),
            panel.border = element_rect(colour = "black", fill=NA, size=1),
            plot.background = element_blank(), 
            legend.background = element_rect(fill="transparent", colour=NA),
            legend.key = element_rect(fill="transparent", colour=NA),
            plot.title = element_text(size=16, margin = margin(b = 5),hjust=0,vjust=0.5, family="Arial", face="bold"),
            title = element_text(size = 16, margin = margin(b = 5),hjust=0,vjust=0.5, family="Arial", face="bold"),
            axis.text.y = element_text(size = 14, margin = margin(r = 5),hjust=1,vjust=0.5, family="Arial", face="bold",colour="black"),
            axis.text.x = element_text(size = 14, margin = margin(t = 5),hjust=0.5,vjust=1, family="Arial", face="bold",colour="black"), 
            axis.title.y = element_text(size = 16, margin = margin(r = 10),angle = 90,hjust=0.5,vjust=0.5, family="Arial", face="bold"),
            axis.title.x = element_text(size = 16, margin = margin(t = 10),hjust=0.5,vjust=1, family="Arial", face="bold"),
            legend.text=element_text(size=14, family="Arial", face="bold"),
            legend.title=element_blank(), 
            legend.key.size=unit(2.5,"line"),
            plot.margin=unit(c(0.4,0.4,0.4,0.4), "cm")
        )
}

##----- Default GGplot Colours Function -----##
gg_color_hue <- function(n) {
  hues = seq(15, 375, length = n + 1)
  hcl(h = hues, l = 65, c = 100)[1:n]
}

##---- Default Sample and Sample Group Colours  ----##
number_of_sample_groups = length(sample_groups)
default_sample_group_colours = gg_color_hue(number_of_sample_groups)
default_samples_colours = c(default_sample_group_colours[1],default_sample_group_colours[1],default_sample_group_colours[1],default_sample_group_colours[2],default_sample_group_colours[2],default_sample_group_colours[2])

##---- Default Sample Group Labels  ----##
default_sample_group_labels = c("KO","KO_RESCUE") # note: changing this won't change the order the groups appear on the plots. Merely what they are labelled as.

##---- Save Plot Function -----##
save_plot <- function(ggp,plot_height,plot_width,plot_path)
{
  png(plot_path, height=plot_height, width=plot_width, pointsize=5)
  print(ggp)
  dev.off()

  # clears all devices - as a safety measure
  while (dev.cur()>1) dev.off()
}

##---- Top 10 IPA Upstream Regulators Function ----##
get_top10_ura_function <- function(upstream_regulators,significant_upstream_regulators,type) {

  if(type=="enriched")
  {
    top_10_upstream_regulators = head(upstream_regulators[order(upstream_regulators$enrichment_p_value,decreasing=FALSE),],10)
    top_10_upstream_regulators = top_10_upstream_regulators[,c("upstream_regulator","enrichment_p_value","overlapping_genes","log2_fold_enrichment","overlapping_gene_names")]
    top_10_upstream_regulators$significant = top_10_upstream_regulators$upstream_regulator %in% significant_upstream_regulators$upstream_regulator
    top_10_upstream_regulators$significant = as.character(top_10_upstream_regulators$significant)
    colnames(top_10_upstream_regulators) = c("gene_set","p","overlapping_genes","log2_fold_enrichment","overlapping_gene_names","significant")
    return(top_10_upstream_regulators)
  }
  if (type=="activated") 
  {
    top_10_upstream_regulators = head(upstream_regulators[order(upstream_regulators$activation_zscore,decreasing=TRUE),],10)
  }
  if (type=="inhibited") 
  {
    top_10_upstream_regulators = head(upstream_regulators[order(upstream_regulators$activation_zscore,decreasing=FALSE),],10)
  }
  top_10_upstream_regulators = top_10_upstream_regulators[,c("upstream_regulator","activation_zscore","genes_activated","genes_inhibited","activated_gene_names","inhibited_gene_names")]
  top_10_upstream_regulators$significant = top_10_upstream_regulators$upstream_regulator %in% significant_upstream_regulators$upstream_regulator
  top_10_upstream_regulators$significant = as.character(top_10_upstream_regulators$significant)
  colnames(top_10_upstream_regulators) = c("upstream_regulator","activation_zscore","genes_activated","genes_inhibited","activated_gene_names","inhibited_gene_names","significant")
  return(top_10_upstream_regulators)
}

##----- Hypergeometric Gene Set Boxplot Function -----##
make_ora_boxplot <- function(gene_set,plot_title,box_transparency,box_line_thickness,box_colours,box_labels,x_axis_label,y_axis_label,legend_position)
{
  genes_in_gene_set = unlist(lapply(gene_set$overlapping_gene_names, function(x) unlist(strsplit(as.character(x),","))))
  if(length(genes_in_gene_set) > 1) 
  {
    ne_matrix_scaled_transposed_genes_in_gene_set = ne_matrix_scaled_transposed[,genes_in_gene_set]
    ne_matrix_scaled_transposed_genes_in_gene_set$sample_groupings = sample_groupings
    ne_matrix_scaled_transposed_genes_in_gene_set_melted = melt(ne_matrix_scaled_transposed_genes_in_gene_set,id.vars = "sample_groupings")
    ggp = ggplot(ne_matrix_scaled_transposed_genes_in_gene_set_melted, aes(x=variable, y=value, fill=sample_groupings)) + geom_boxplot(position=position_dodge(0.75),outlier.shape = NA, alpha=box_transparency,size=box_line_thickness) + theme_SL2() + theme(axis.text.x = element_text(angle = 90, hjust=1, vjust=0.5),legend.position=legend_position) + ggtitle(plot_title) + scale_color_manual(values=box_colours,breaks=sample_groups,labels=box_labels) + scale_fill_manual(values=box_colours,breaks=sample_groups,labels=box_labels) + xlab(x_axis_label) + ylab(y_axis_label)
    return(ggp)
  }
  return(ggplot(data.frame()) + theme_SL2() + geom_blank() + ggtitle("There were too few genes to sensibly plot this."))
}

##----- IPA Upstream Regulator Boxplots Function -----##
make_IPA_upstream_regulator_boxplot <- function(gene_set,plot_title,box_transparency,box_line_thickness,box_colours,box_labels,x_axis_label,y_axis_label,legend_position)
{
  activating_genes_in_gene_set = unlist(lapply(gene_set$activated_gene_names, function(x) unlist(strsplit(as.character(x),","))))
  inactivating_genes_in_gene_set = unlist(lapply(gene_set$inhibited_gene_names, function(x) unlist(strsplit(as.character(x),","))))
  genes_in_gene_set = c(activating_genes_in_gene_set,inactivating_genes_in_gene_set)
  if(length(genes_in_gene_set) > 1) 
  {
    ne_matrix_scaled_transposed_genes_in_gene_set = ne_matrix_scaled_transposed[,genes_in_gene_set]
    ne_matrix_scaled_transposed_genes_in_gene_set$sample_groupings = sample_groupings
    ne_matrix_scaled_transposed_genes_in_gene_set_melted = melt(ne_matrix_scaled_transposed_genes_in_gene_set,id.vars = "sample_groupings")
    ggp = ggplot(ne_matrix_scaled_transposed_genes_in_gene_set_melted, aes(x=variable, y=value, fill=sample_groupings)) + geom_boxplot(position=position_dodge(0.75),outlier.shape = NA, alpha=box_transparency,size=box_line_thickness) + theme_SL2() + theme(axis.text.x = element_text(angle = 90, hjust=1, vjust=0.5),legend.position=legend_position) + ggtitle(plot_title) + scale_color_manual(values=box_colours,breaks=sample_groups,labels=box_labels) + scale_fill_manual(values=box_colours,breaks=sample_groups,labels=box_labels) + xlab(x_axis_label) + ylab(y_axis_label)
    return(ggp)
  }
  return(ggplot(data.frame()) + theme_SL2() + geom_blank() + ggtitle("There are too few genes to sensibly plot this."))
}

##----- IPA Upstream Regulators (Boxplots) -----##

plot_height = 250
plot_width = 1000
box_transparency = 0.75
box_line_thickness = 0.75
box_colours = default_sample_group_colours 	# note: changing this won't change the order the groups appear in the x axis. Merely what they are coloured as.
box_labels = default_sample_group_labels	# note: changing this won't change the order the groups appear in the x axis. Merely what they are named as.
x_axis_label = ""
y_axis_label = "expression (z-score)"
legend_position = "right"

top_10_upstream_regulators = get_top10_ura_function(TRUSST_all_gene_sets,TRUSST_enriched_gene_sets,"enriched")
for(upstream_regulator_index in 1:10)
{
  upstream_regulator = top_10_upstream_regulators[upstream_regulator_index,]
  plot_title = upstream_regulator[["gene_set"]]
  ggp = make_ora_boxplot(upstream_regulator,plot_title,box_transparency,box_line_thickness,box_colours,box_labels,x_axis_label,y_axis_label,legend_position)
  save_plot(ggp,plot_height,plot_width,paste("plots/upstream_regulator_analysis/TRUSST/enriched/no.",upstream_regulator_index,"_most_enriched_upstream_regulator.png",sep=""))
}

top_10_upstream_regulators = get_top10_ura_function(TRUSST_all_gene_sets,TRUSST_activated_gene_sets, "activated")
for(upstream_regulator_index in 1:10)
{
  upstream_regulator = top_10_upstream_regulators[upstream_regulator_index,]
  plot_title = upstream_regulator[["upstream_regulator"]]
  ggp = make_IPA_upstream_regulator_boxplot(upstream_regulator,plot_title,box_transparency,box_line_thickness,box_colours,box_labels,x_axis_label,y_axis_label,legend_position)
  save_plot(ggp,plot_height,plot_width,paste("plots/upstream_regulator_analysis/TRUSST/activated/no.",upstream_regulator_index,"_most_activated_upstream_regulator.png",sep=""))
}

top_10_upstream_regulators = get_top10_ura_function(TRUSST_all_gene_sets,TRUSST_activated_gene_sets, "inhibited")
for(upstream_regulator_index in 1:10)
{
  upstream_regulator = top_10_upstream_regulators[upstream_regulator_index,]
  plot_title = upstream_regulator[["upstream_regulator"]]
  ggp = make_IPA_upstream_regulator_boxplot(upstream_regulator,plot_title,box_transparency,box_line_thickness,box_colours,box_labels,x_axis_label,y_axis_label,legend_position)
  save_plot(ggp,plot_height,plot_width,paste("plots/upstream_regulator_analysis/TRUSST/inhibited/no.",upstream_regulator_index,"_most_inhibited_upstream_regulator.png",sep=""))
}


