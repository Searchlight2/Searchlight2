##---- network libraries ----##
library(GGally)
library(network)
library(sna)

##---- sets the working directory. If you move the SL2 folder please update this path ----##
setwd("/home/john/Downloads/TEMP/DESEQ2/results/all_genes/de_workflows/KO_RESCUE_vs_KO")

##---- de IPA UREG network files ----##
TRUSST_enriched_ura_nodes = read.table(file="data/statistical_analysis/upstream_regulator_analysis/TRUSST/network_data/enriched_uregs_nodes.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
TRUSST_enriched_ura_edges = read.table(file="data/statistical_analysis/upstream_regulator_analysis/TRUSST/network_data/enriched_uregs_edges.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
TRUSST_activated_ura_nodes = read.table(file="data/statistical_analysis/upstream_regulator_analysis/TRUSST/network_data/activated_uregs_nodes.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
TRUSST_activated_ura_edges = read.table(file="data/statistical_analysis/upstream_regulator_analysis/TRUSST/network_data/activated_uregs_edges.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)

##---- SL2 Theme ----##
theme_SL2 <- function () { 
    theme_bw() %+replace% 
        theme(
	    panel.grid = element_blank(),
            panel.background = element_blank(),
            panel.border = element_rect(colour = "black", fill=NA, size=1),
            plot.background = element_blank(), 
            legend.background = element_rect(fill="transparent", colour=NA),
            legend.key = element_rect(fill="transparent", colour=NA),
            plot.title = element_text(size=16, margin = margin(b = 5),hjust=0,vjust=0.5, family="Arial", face="bold"),
            title = element_text(size = 16, margin = margin(b = 5),hjust=0,vjust=0.5, family="Arial", face="bold"),
            axis.text.y = element_text(size = 14, margin = margin(r = 5),hjust=1,vjust=0.5, family="Arial", face="bold",colour="black"),
            axis.text.x = element_text(size = 14, margin = margin(t = 5),hjust=0.5,vjust=1, family="Arial", face="bold",colour="black"), 
            axis.title.y = element_text(size = 16, margin = margin(r = 10),angle = 90,hjust=0.5,vjust=0.5, family="Arial", face="bold"),
            axis.title.x = element_text(size = 16, margin = margin(t = 10),hjust=0.5,vjust=1, family="Arial", face="bold"),
            legend.text=element_text(size=14, family="Arial", face="bold"),
            legend.title=element_blank(), 
            legend.key.size=unit(2.5,"line"),
            plot.margin=unit(c(0.4,0.4,0.4,0.4), "cm")
        )
}

##---- Default Two Tone Network Node Colours  ----##
default_two_tone_network_node_colours = c("grey90","red")

##---- Default Four Tone Network Node Colours  ----##
default_four_tone_network_node_colours_high = c("lightpink","red")
default_four_tone_network_node_colours_low = c("lightskyblue1","blue")

##---- Default Network Edge Colour  ----##
default_network_edge_colour = "grey50"

##---- scale values from 0 to 1 function ----##
range_0_to_1_function <- function(x){(x-min(x))/(max(x)-min(x))}

##---- Save Plot Function -----##
save_plot <- function(ggp,plot_height,plot_width,plot_path)
{
  png(plot_path, height=plot_height, width=plot_width, pointsize=5)
  print(ggp)
  dev.off()

  # clears all devices - as a safety measure
  while (dev.cur()>1) dev.off()
}

##---- Hypergeometric Gene Set Network Plot Function ----##
make_ora_network_plot <- function(edges,nodes,node_colours,node_outer_max_size,node_inner_max_size,node_label_size,edge_colour,edge_transparency, edge_width)
{
  if (nrow(edges) > 0) {
  
    edges_source_target <- edges[c(1,2)]

    net = 0
    net = network(edges_source_target, directed = FALSE)
 
    # gets the node sizes
    x = data.frame(node = network.vertex.names(net))
    x = merge(x, nodes, by = "node", sort = FALSE)$node_size
    net %v% "node_size" = as.numeric(x)

    # scales log10p from 0 to 1
    nodes$log10_p = -log(nodes$enrichment_p_value,10)
    nodes = nodes[order(nodes$log10_p),]
    nodes$log10_p_scaled_0_to_1 = range_0_to_1_function(nodes$log10_p)

    # pass node colours to the network
    colour_ramp_function = colorRamp(node_colours)
    colours = colour_ramp_function(nodes$log10_p_scaled_0_to_1)
    nodes$node_colour = rgb(colours, maxColorValue=256)
    x = data.frame(node = network.vertex.names(net))
    x = merge(x, nodes, by = "node", sort = FALSE)$node_colour
    net %v% "node_colour" = as.character(x)

    ggp = ggnet2(net, alpha = 1, color = 'node_colour', size = 0,edge.color = edge_colour, edge.size = edges$overlap_ratio*edge_width, edge.alpha = edge_transparency) + xlab("") + ylab("") + theme_SL2() + theme(legend.position="none") + geom_point(aes(color = color), size=(get.vertex.attribute(net,"node_size")*node_outer_max_size)/max(get.vertex.attribute(net,"node_size")), alpha = 0.5) + geom_point(aes(color = color), size=(get.vertex.attribute(net,"node_size")*node_inner_max_size)/max(get.vertex.attribute(net,"node_size")), alpha = 1) + geom_text(aes(label = network.vertex.names(net)), color = "black", size=node_label_size)
    return(ggp)
  }
  return(ggplot(data.frame()) + theme_SL2() + geom_blank() + ggtitle("There were too few nodes to sensibly plot this."))
}

##---- IPA UREG Network Plot Function ----##
make_ura_network_plot <- function(edges,nodes,activated_node_colours,inhibited_node_colours,node_outer_max_size,node_inner_max_size,node_label_size,edge_colour,edge_transparency,edge_width)
{
  if (nrow(edges) > 0) {

    # starts the network
    net = 0
    edges_source_target <- edges[c(1,2)]
    net = network(edges_source_target, directed = FALSE)
    
    # scales the node colours from -1 to 1, diverging from 0
    nodes = nodes[order(-nodes$activation_zscore),]
    nodes$activation_zscore_scaled_0_to_1 = range_0_to_1_function(abs(nodes$activation_zscore))
    colour_ramp_up = colorRamp(activated_node_colours)
    nodes$colour_ramp_up = rgb(colour_ramp_up(nodes$activation_zscore_scaled_0_to_1),maxColorValue=256)
    colour_ramp_down = colorRamp(inhibited_node_colours)
    nodes$colour_ramp_down = rgb(colour_ramp_down(nodes$activation_zscore_scaled_0_to_1),maxColorValue=256)
    nodes$node_colour = c(subset(nodes,activation_zscore > 0)$colour_ramp_up,subset(nodes,activation_zscore < 0)$colour_ramp_down)
    x = data.frame(node = network.vertex.names(net))
    x = merge(x, nodes, by = "node", sort = FALSE)$node_colour
    net %v% "node_colour" = as.character(x)

    # pass the node sizes to the network
    x = data.frame(node = network.vertex.names(net))
    x = merge(x, nodes, by = "node", sort = FALSE)$node_size
    net %v% "node_size" = as.numeric(x)

    plot = ggnet2(net, alpha = 1, color = 'node_colour', size = 0,edge.color = edge_colour, edge.size = edges$overlap_ratio*edge_width, edge.alpha = edge_transparency) + xlab("") + ylab("") + theme_SL2() + theme(legend.position="none") + geom_point(aes(color = color), size=(get.vertex.attribute(net,"node_size")*node_outer_max_size)/max(get.vertex.attribute(net,"node_size")), alpha = 0.5) + geom_point(aes(color = color), size=(get.vertex.attribute(net,"node_size")*node_inner_max_size)/max(get.vertex.attribute(net,"node_size")), alpha = 1) + geom_text(aes(label = network.vertex.names(net)), color = "black", size=node_label_size)
    return(plot)
  }
  return(ggplot(data.frame()) + theme_SL2() + geom_blank() + ggtitle("There were too few nodes to sensibly plot this."))
}

##---- IPA UREG (Network Plots) ----##

plot_height = 1000
plot_width = 1500

node_colours = default_two_tone_network_node_colours
activated_node_colours = default_four_tone_network_node_colours_high
inhibited_node_colours = default_four_tone_network_node_colours_low
node_outer_max_size = 50
node_inner_max_size = 40
node_label_size = 3
edge_colour = default_network_edge_colour
edge_transparency = 0.5
edge_width = 4

ggp = make_ora_network_plot(TRUSST_enriched_ura_edges,TRUSST_enriched_ura_nodes,node_colours,node_outer_max_size,node_inner_max_size,node_label_size,edge_colour,edge_transparency,edge_width)
save_plot(ggp,plot_height,plot_width,"plots/upstream_regulator_analysis/TRUSST/enriched_gene_sets_network_plot.png")

ggp = make_ura_network_plot(TRUSST_activated_ura_edges,TRUSST_activated_ura_nodes,activated_node_colours,inhibited_node_colours,node_outer_max_size,node_inner_max_size,node_label_size,edge_colour,edge_transparency,edge_width)
save_plot(ggp,plot_height,plot_width,"plots/upstream_regulator_analysis/TRUSST/activated_and_inhibited_gene_sets_network_plot.png")


