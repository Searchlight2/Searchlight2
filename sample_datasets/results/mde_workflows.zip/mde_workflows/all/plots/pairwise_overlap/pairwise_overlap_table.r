##---- general libraries ----##
library(ggplot2)
library(reshape)

##---- table libraries ----##
library(grid)
library(gridExtra)
library(gtable)

##---- sets the working directory. If you move the SL2 folder please update this path ----##
setwd("/home/john/Downloads/TEMP/DESEQ2/results/all_genes/mde_workflows/all")

##---- pairwise overlap input files ----##
pairwise_overlap_summary = read.table(file="data/statistical_analysis/pairwise_overlap/overlap_statistics.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)

##---- SL2 Theme ----##
theme_SL2 <- function () { 
    theme_bw() %+replace% 
        theme(
	    panel.grid = element_blank(),
            panel.background = element_blank(),
            panel.border = element_rect(colour = "black", fill=NA, size=1),
            plot.background = element_blank(), 
            legend.background = element_rect(fill="transparent", colour=NA),
            legend.key = element_rect(fill="transparent", colour=NA),
            plot.title = element_text(size=16, margin = margin(b = 5),hjust=0,vjust=0.5, family="Arial", face="bold"),
            title = element_text(size = 16, margin = margin(b = 5),hjust=0,vjust=0.5, family="Arial", face="bold"),
            axis.text.y = element_text(size = 14, margin = margin(r = 5),hjust=1,vjust=0.5, family="Arial", face="bold",colour="black"),
            axis.text.x = element_text(size = 14, margin = margin(t = 5),hjust=0.5,vjust=1, family="Arial", face="bold",colour="black"), 
            axis.title.y = element_text(size = 16, margin = margin(r = 10),angle = 90,hjust=0.5,vjust=0.5, family="Arial", face="bold"),
            axis.title.x = element_text(size = 16, margin = margin(t = 10),hjust=0.5,vjust=1, family="Arial", face="bold"),
            legend.text=element_text(size=14, family="Arial", face="bold"),
            legend.title=element_blank(), 
            legend.key.size=unit(2.5,"line"),
            plot.margin=unit(c(0.4,0.4,0.4,0.4), "cm")
        )
}

##---- Save Table Function -----##
save_table <- function(gt,plot_height,plot_width,plot_path)
{
  png(plot_path, height=plot_height, width=plot_width, pointsize=5)
  grid.arrange(gt)
  dev.off()

  while (dev.cur()>1) dev.off()
}

##----- Pairwise Overlap Table Function  -----##
make_pairwise_overlap_table <- function(pairwise_overlap_summary,header_size,text_size,border_thickness)
{
  table_theme <- gridExtra::ttheme_minimal(core = list(fg_params=list(cex = text_size)),colhead = list(fg_params=list(cex = header_size)))
  colnames(pairwise_overlap_summary) = c("set 1 name","set 2 name", "background genes","set 1 total genes","set 2 total genes","set 1 unique gene","set 2 unique genes","overlapping genes","fold enrichment","p value")

  gt <- tableGrob(pairwise_overlap_summary, theme=table_theme, rows=NULL)
  gt <- gtable_add_grob(gt,grobs = rectGrob(gp = gpar(fill = NA, lwd = border_thickness)),t = 2, b = nrow(gt), l = 1, r = ncol(gt))
  gt <- gtable_add_grob(gt,grobs = rectGrob(gp = gpar(fill = NA, lwd = border_thickness)),t = 1, l = 1, r = ncol(gt))
  return(gt)
}




##----- Pairwise Overlap (Table) -----##

plot_height = 300
plot_width = 1800
header_size = 1.25
text_size = 1.25
border_thickness = 2

gt = make_pairwise_overlap_table(pairwise_overlap_summary,header_size,text_size,border_thickness)
png("plots/pairwise_overlap/pairwise_overlap_table.png", height=300, width=1800, pointsize=5)
grid.arrange(gt)
dev.off()

