###################################
##         Searchlight 2         ##
###################################



#############################
##      Mde workflow      ##
#############################



##-------------------------##
##       R libraries       ##
##-------------------------##



##---- general libraries ----##
library(ggplot2)
library(reshape)


##---- heatmap libraries ----##
library(amap)


##---- table libraries ----##
library(grid)
library(gridExtra)
library(gtable)



##-------------------------##
##     Core Parameters     ##
##-------------------------##



##---- Mde sample and group names ----##
samples = c("KO_R1","KO_R2","KO_R3","WT_R1","WT_R2","WT_R3","KO_RESCUE_R1","KO_RESCUE_R2","KO_RESCUE_R3")
sample_groups = c("KO","WT","KO_RESCUE")
sample_groupings = c("KO","KO","KO","WT","WT","WT","KO_RESCUE","KO_RESCUE","KO_RESCUE")
sample_groupings = factor(sample_groupings, levels = sample_groups)
samples_by_sample_group = list(c("KO_R1","KO_R2","KO_R3"),c("WT_R1","WT_R2","WT_R3"),c("KO_RESCUE_R1","KO_RESCUE_R2","KO_RESCUE_R3"))
comparisons = c("KO vs WT","KO_RESCUE vs KO")



##-------------------------##
##       Input Files       ##
##-------------------------##



##---- sets the working directory. If you move the SL2 folder please update this path ----##
setwd("/home/john/Downloads/TEMP/DESEQ2/results/all_genes/mde_workflows/all")


##---- Mde input files ----##
Mde_annotated = read.table(file="data/all_genes_annotated.csv", header=TRUE,row.names = 2, sep='\t', quote='',check.names = TRUE)
Mde_annotated_sig_any = read.table(file="data/genes_significant_in_any_des_annotated.csv", header=TRUE,row.names = 2, sep='\t', quote='',check.names = TRUE)
Mde_annotated_sig_all = read.table(file="data/genes_significant_in_all_des_annotated.csv", header=TRUE,row.names = 2, sep='\t', quote='',check.names = TRUE)


##---- pairwise overlap input files ----##
pairwise_overlap_summary = read.table(file="data/statistical_analysis/pairwise_overlap/overlap_statistics.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)


##---- differential expression signature input files ----##
signature_summary = read.table(file="data/statistical_analysis/differential_expression_signature/Signature_summary.csv", header=TRUE,row.names = 1, sep='\t', quote='',check.names = TRUE)



##-------------------------##
##       Parsed Data       ##
##-------------------------##



##---- Mde parse ne matrix ----##
ne_matrix = Mde_annotated[,samples]
ne_matrix_sig_any = Mde_annotated_sig_any[,samples]
ne_matrix_sig_all = Mde_annotated_sig_all[,samples]


##---- transpose and scale ne matrix ----##
ne_matrix_transposed = data.frame(t(ne_matrix))
colnames(ne_matrix_transposed) = rownames(ne_matrix)

ne_matrix_scaled = data.frame(t(scale(t(ne_matrix))))
rownames(ne_matrix_scaled) = rownames(ne_matrix)
ne_matrix_scaled[do.call(cbind, lapply(ne_matrix_scaled, is.nan))] <- 0
ne_matrix_scaled = ne_matrix_scaled[is.finite(rowSums(ne_matrix_scaled)), ]

ne_matrix_scaled_transposed = data.frame(t(ne_matrix_scaled))
colnames(ne_matrix_scaled_transposed) = rownames(ne_matrix_scaled)


##---- transpose and scale significant genes ne matrix ----##
ne_matrix_sig_any_scaled = data.frame(t(scale(t(ne_matrix_sig_any))))
rownames(ne_matrix_sig_any_scaled) = rownames(ne_matrix_sig_any)
ne_matrix_sig_any_scaled[do.call(cbind, lapply(ne_matrix_sig_any_scaled, is.nan))] <- 0
ne_matrix_sig_any_scaled = ne_matrix_sig_any_scaled[is.finite(rowSums(ne_matrix_sig_any_scaled)), ]

ne_matrix_sig_all_scaled = data.frame(t(scale(t(ne_matrix_sig_all))))
rownames(ne_matrix_sig_all_scaled) = rownames(ne_matrix_sig_all)
ne_matrix_sig_all_scaled[do.call(cbind, lapply(ne_matrix_sig_all_scaled, is.nan))] <- 0
ne_matrix_sig_all_scaled = ne_matrix_sig_all_scaled[is.finite(rowSums(ne_matrix_sig_all_scaled)), ]



##-------------------------##
##   Default Aesthetics    ##
##-------------------------##



##---- SL2 Theme ----##
theme_SL2 <- function () { 
    theme_bw() %+replace% 
        theme(
	    panel.grid = element_blank(),
            panel.background = element_blank(),
            panel.border = element_rect(colour = "black", fill=NA, size=1),
            plot.background = element_blank(), 
            legend.background = element_rect(fill="transparent", colour=NA),
            legend.key = element_rect(fill="transparent", colour=NA),
            plot.title = element_text(size=16, margin = margin(b = 5),hjust=0,vjust=0.5, family="Arial", face="bold"),
            title = element_text(size = 16, margin = margin(b = 5),hjust=0,vjust=0.5, family="Arial", face="bold"),
            axis.text.y = element_text(size = 14, margin = margin(r = 5),hjust=1,vjust=0.5, family="Arial", face="bold",colour="black"),
            axis.text.x = element_text(size = 14, margin = margin(t = 5),hjust=0.5,vjust=1, family="Arial", face="bold",colour="black"), 
            axis.title.y = element_text(size = 16, margin = margin(r = 10),angle = 90,hjust=0.5,vjust=0.5, family="Arial", face="bold"),
            axis.title.x = element_text(size = 16, margin = margin(t = 10),hjust=0.5,vjust=1, family="Arial", face="bold"),
            legend.text=element_text(size=14, family="Arial", face="bold"),
            legend.title=element_blank(), 
            legend.key.size=unit(2.5,"line"),
            plot.margin=unit(c(0.4,0.4,0.4,0.4), "cm")
        )
}


##----- Default GGplot Colours Function -----##
gg_color_hue <- function(n) {
  hues = seq(15, 375, length = n + 1)
  hcl(h = hues, l = 65, c = 100)[1:n]
}


##---- Default Sample and Sample Group Colours  ----##
number_of_sample_groups = length(sample_groups)
default_sample_group_colours = gg_color_hue(number_of_sample_groups)
default_samples_colours = c(default_sample_group_colours[1],default_sample_group_colours[1],default_sample_group_colours[1],default_sample_group_colours[2],default_sample_group_colours[2],default_sample_group_colours[2],default_sample_group_colours[3],default_sample_group_colours[3],default_sample_group_colours[3])


##---- Default Sample Labels  ----##
default_sample_labels = c("KO_R1","KO_R2","KO_R3","WT_R1","WT_R2","WT_R3","KO_RESCUE_R1","KO_RESCUE_R2","KO_RESCUE_R3") # note: changing this won't change the order the samples appear on the plots. Merely what they are labelled as. 


##---- Default Sample Group Labels  ----##
default_sample_group_labels = c("KO","WT","KO_RESCUE") # note: changing this won't change the order the groups appear on the plots. Merely what they are labelled as.


##---- Default Three Tone Heatmap Colours  ----##
default_three_tone_heatmap_colours = c("blue","pink","red")


##---- Default Two Tone Greyscale  ----##
default_two_tone_greyscale = c("grey75","grey50")


##---- Default Comaparison Labels  ----##
default_comparison_labels = c("KO vs WT","KO_RESCUE vs KO") # note: changing this won't change the order the comparisons appear on the plots. Merely what they are labelled as.


##---- Default Three Way Sig and Non-sig Colours  ----##
default_significant_both_colour = "red"
default_significant_a_colour = "dodgerblue3"
default_significant_b_colour = "forestgreen"
default_non_significant_colour = "black"


##---- Default Sig and Non-sig Colours  ----##
default_significant_colour = "red"
default_non_significant_colour = "black"



##-------------------------##
##     Helper Functions    ##
##-------------------------##



##---- Save Plot Function -----##
save_plot <- function(ggp,plot_height,plot_width,plot_path)
{
  png(plot_path, height=plot_height, width=plot_width, pointsize=5)
  print(ggp)
  dev.off()

  # clears all devices - as a safety measure
  while (dev.cur()>1) dev.off()
}


##----- Clustering Method -----##
cluster_matrix <- function(mx,cluster_x,cluster_y,distance_method,clustering_method,reorder_function)
{
  x.cluster = hclust(Dist(t(mx), method=distance_method), method=clustering_method)
  y.cluster = hclust(Dist(mx, method=distance_method), method=clustering_method)
  
  x.dd = as.dendrogram(x.cluster)
  y.dd = as.dendrogram(y.cluster)
  x.dd.reorder = reorder(x.dd,0,FUN=reorder_function)
  y.dd.reorder = reorder(y.dd,0,FUN=reorder_function)
  x.order = order.dendrogram(x.dd.reorder)
  y.order = order.dendrogram(y.dd.reorder)

  if(cluster_x == TRUE && cluster_y == TRUE) 
  {
      mx_clustered = mx[y.order,x.order]
  }
  
  if(cluster_x == TRUE && cluster_y == FALSE)
  {
      mx_clustered = mx[,x.order]
  }
  
  if(cluster_x == FALSE && cluster_y == TRUE)
  {
      mx_clustered = mx[y.order,]
  }
  if(cluster_x == FALSE && cluster_y == FALSE) 
  {
      mx_clustered = mx
  }
  return(mx_clustered)
}


##---- Save Table Function -----##
save_table <- function(gt,plot_height,plot_width,plot_path)
{
  png(plot_path, height=plot_height, width=plot_width, pointsize=5)
  grid.arrange(gt)
  dev.off()

  while (dev.cur()>1) dev.off()
}


##---- Top 10 Genes by Mean Expression Function ----##
get_top_10_genes_by_mean_expression <- function(index) {
  samples_in_sample_group = unlist(samples_by_sample_group[index])
  top_10_genes = row.names(head(ne_matrix[order(rowMeans(ne_matrix[,samples_in_sample_group]),decreasing=TRUE),],10))
  return(top_10_genes)
}


##---- Top 10 Gene Sets by Hypergeometric P-value Function ----##
get_top10_oras_by_p_value <- function(gene_sets,enriched_gene_sets,type) {

  if(type=="enrichment")
  {
    top_10_gene_sets = head(gene_sets[order(gene_sets$enrichment_p_value,decreasing=FALSE),],10)
    top_10_gene_sets = top_10_gene_sets[,c("gene_set","enrichment_p_value","overlapping_genes","log2_fold_enrichment","overlapping_gene_names")]
  }
  if(type=="underenrichment")
  {
    top_10_gene_sets = head(gene_sets[order(gene_sets$underenrichment_p_value,decreasing=FALSE),],10)
    top_10_gene_sets = top_10_gene_sets[,c("gene_set","underenrichment_p_value","overlapping_genes","log2_fold_enrichment","overlapping_gene_names")]
  }
  top_10_gene_sets$significant = top_10_gene_sets$gene_set %in% enriched_gene_sets$gene_set
  top_10_gene_sets$significant = as.character(top_10_gene_sets$significant)
  colnames(top_10_gene_sets) = c("gene_set","p","overlapping_genes","log2_fold_enrichment","overlapping_gene_names","significant")
  return(top_10_gene_sets)
}



##-------------------------##
##      Plot Functions     ##
##-------------------------##



##----- Distribution of Expression Values Function -----##
make_distribution_of_expression_values_plot <- function(plot_sample,plot_colour,transparency,line_thickness,x_axis_label,y_axis_label,legend_position) 
{
  ggp = ggplot(ne_matrix, aes(log(x=ne_matrix[[plot_sample]]+0.001,10))) + geom_density(colour=plot_colour,fill=plot_colour, alpha=transparency,size=line_thickness) + xlab(x_axis_label) + ylab(y_axis_label) + ggtitle(plot_sample) + theme_SL2() + theme(legend.position=legend_position) + scale_x_continuous(expand=c(0,0)) + scale_y_continuous(expand=c(0,0))
  return(ggp)
}


##----- PCA Contribution of Components Function -----##
make_PCA_contribution_of_components_plot <- function(x_axis_label,y_axis_label,dot_size,dot_transparency,dot_colour,line_type,line_colour,line_size)
{

prcomp_data = prcomp(as.matrix(sapply(ne_matrix_scaled_transposed, as.numeric)))
vars = apply(prcomp_data$x, 2, var)
prcomp_props = data.frame(round(vars / sum(vars),4) * 100)
prcomp_props$PC = row.names(prcomp_props)
colnames(prcomp_props) = c("prop","PC")
prcomp_props$PC = factor(prcomp_props$PC, levels = row.names(prcomp_props))
ggp = ggplot(data=prcomp_props,aes(x=PC,y=prop,group=1)) + geom_line(linetype=line_type,colour=line_colour,size=line_size) + geom_point(size=dot_size,alpha=dot_transparency,colour=dot_colour) + xlab(x_axis_label) + ylab(y_axis_label) + theme_SL2() + theme(legend.position="None", legend.title = element_blank())                                              

return(ggp)
}


##----- PCA Scatter Plot Function -----##
make_PCA_scatterplot <- function(plot_sample_groupings,component_x,component_y,x_axis_label,y_axis_label,plot_sample_group_colours,plot_sample_group_labels,plot_sample_labels,dot_size,dot_transparency,legend_position,sample_label_size,show_proportion_of_variance)
{

  prcomp_data = prcomp(as.matrix(sapply(ne_matrix_scaled_transposed, as.numeric)))
  prcomp_coordinates = data.frame(prcomp_data$x)
    
  if (show_proportion_of_variance == TRUE) 
  {
    vars = apply(prcomp_data$x, 2, var)
    prop_x = round(vars[component_x] / sum(vars),4) * 100
    prop_y = round(vars[component_y] / sum(vars),4) * 100
    
    x_axis_label = paste(x_axis_label, " (",prop_x,"%)",sep="")
    y_axis_label = paste(y_axis_label, " (",prop_y,"%)",sep="")
  }
  
  ggp = ggplot(data=prcomp_coordinates, aes(x=prcomp_coordinates[,component_x], y=prcomp_coordinates[,component_y], colour=plot_sample_groupings, group=plot_sample_groupings,fill=plot_sample_groupings)) + geom_point(size=dot_size,alpha=dot_transparency) + scale_color_manual(values=plot_sample_group_colours,labels=plot_sample_group_labels, breaks=sample_groups) + scale_fill_manual(values=plot_sample_group_colours,labels=plot_sample_group_labels, breaks=sample_groups) + xlab(x_axis_label) + ylab(y_axis_label) + theme_SL2() + theme(legend.position=legend_position, legend.title = element_blank(), legend.spacing.x = unit(0.25, 'cm')) + geom_text(data=prcomp_coordinates,aes(label=plot_sample_labels),hjust=0.5, vjust=-1, size=sample_label_size, show.legend = FALSE) + xlim(c(min(prcomp_coordinates[,component_x])*1.25,max(prcomp_coordinates[,component_x])*1.25)) + ylim(c(min(prcomp_coordinates[,component_y])*1.25,max(prcomp_coordinates[,component_y])*1.25))                                                 
  return(ggp) 
}


##----- Correlation Analysis Heatmap Function  -----##
make_correlation_analysis_heatmap <- function(colours,sample_names,cluster_x,cluster_y,distance_method,clustering_method,reorder_function)
{
  ne_matrix_scaled_correlated = cor(ne_matrix_scaled,method="spearman")
  row.names(ne_matrix_scaled_correlated) = sample_names
  colnames(ne_matrix_scaled_correlated) = sample_names
  
  ne_matrix_scaled_correlated_clustered = cluster_matrix(ne_matrix_scaled_correlated,cluster_x,cluster_y,distance_method,clustering_method,reorder_function)
  ne_matrix_scaled_correlated_clustered_melted <- melt(ne_matrix_scaled_correlated_clustered)
  ne_matrix_scaled_correlated_clustered_melted$X1 = factor(ne_matrix_scaled_correlated_clustered_melted$X1, levels=colnames(ne_matrix_scaled_correlated_clustered))
  ne_matrix_scaled_correlated_clustered_melted$X2 = factor(ne_matrix_scaled_correlated_clustered_melted$X2, levels=row.names(ne_matrix_scaled_correlated_clustered))

  ggp = ggplot(ne_matrix_scaled_correlated_clustered_melted, aes(x = X1, y = X2, fill = value)) + geom_tile() + scale_fill_gradientn(limits=c(-1, 1),colours = colorRampPalette(colours)(100)) + ylab('') + xlab('') + theme_SL2() + theme(legend.position="right", legend.title = element_blank(), legend.spacing.x = unit(0.25, 'cm'),axis.text.x = element_text(angle = 90, hjust = 1), axis.ticks=element_blank()) + scale_x_discrete(expand=c(0,0)) + scale_y_discrete(expand=c(0,0))
  return(ggp)
}


##----- Most Expressed Genes Table Function  -----##
make_most_expressed_genes_table <- function(top_10_genes,header_size,text_size,border_thickness)
{
  ne_matrix_top_10 = ne_matrix[top_10_genes,]
  mean_matrix_top_10 = ne_matrix_top_10[,0]
  mean_matrix_top_10$Gene = rownames(mean_matrix_top_10)
  for (index in 1:length(sample_groups))
  { 
    mean_matrix_top_10[[sample_groups[index]]] = round(rowMeans(ne_matrix_top_10[,unlist(samples_by_sample_group[index])]),2)
  }

  table_theme <- gridExtra::ttheme_minimal(core = list(fg_params=list(cex = text_size)),colhead = list(fg_params=list(cex = header_size)))

  gt <- tableGrob(mean_matrix_top_10, theme=table_theme, rows=NULL)
  gt <- gtable_add_grob(gt,grobs = rectGrob(gp = gpar(fill = NA, lwd = border_thickness)),t = 2, b = nrow(gt), l = 1, r = ncol(gt))
  gt <- gtable_add_grob(gt,grobs = rectGrob(gp = gpar(fill = NA, lwd = border_thickness)),t = 1, l = 1, r = ncol(gt))
  gt <- gtable_add_grob(gt,grobs = rectGrob(gp = gpar(fill = NA, lwd = border_thickness)),t = 1, b = nrow(gt), l = 1, r = 1)
}


##----- Gene Expression Violin Plot Function  -----##
make_gene_expression_violin_plot <- function(matrix,gene,violin_transparency,violin_width,violin_line_thickness,violin_colours,violin_labels,trim_violin,jitter_dot_size,jitter_dot_colour,jitter_dot_width,summary_colour,summary_size,x_axis_label,y_axis_label,legend_position)
{
  ggp = ggplot(matrix, aes(x=sample_groupings, y=matrix[[gene]], color=sample_groupings, group=sample_groupings, fill=sample_groupings)) + geom_violin(trim=trim_violin, scale="width", width=violin_width, alpha = violin_transparency, size=violin_line_thickness) + geom_jitter(size=jitter_dot_size, colour=jitter_dot_colour, width=jitter_dot_width, height=0, show.legend = FALSE) + stat_summary(position=position_dodge(0.75), colour = summary_colour, size = summary_size, geom="pointrange", show.legend = FALSE) + scale_color_manual(values=violin_colours,breaks=sample_groups,labels=violin_labels,limits=sample_groups) + scale_fill_manual(values=violin_colours,breaks=sample_groups,labels=violin_labels,limits=sample_groups) + scale_x_discrete(breaks=sample_groups,labels=violin_labels,limits=sample_groups) + ylim(0, max(matrix[[gene]] * 1.25)) + xlab(x_axis_label) + ylab(y_axis_label) + ggtitle(gene) + theme_SL2() + theme(legend.position=legend_position, axis.text.x = element_text(angle = 45, hjust = 1))
  return(ggp)
}


##----- Number of Significant Genes Barchart Function -----##
make_number_of_significant_genes_barchart <- function(x_axis_label,y_axis_label,comparison_labels,direction_labels,bar_colours,legend_position,data_label_size,bar_outline_size) 
{

  # gets the names of the columns that indicate significance
  sig_genes_rownames = data.frame(matrix(ncol=length(comparisons), nrow=0), check.names=TRUE)
  colnames(sig_genes_rownames) = paste(comparisons,"_sig",sep="")
  sig_genes_rownames = colnames(data.frame(sig_genes_rownames, check.names=TRUE))
  
  # gets the names of the columns that indicate fold change
  fold_change_rownames = data.frame(matrix(ncol=length(comparisons), nrow=0), check.names=TRUE)
  colnames(fold_change_rownames) = paste(comparisons,"_log2fold",sep="")
  fold_change_rownames = colnames(data.frame(fold_change_rownames, check.names=TRUE))
  
  # gets the sig counts
  upregulated=c()
  downregulated=c() 
  for(index in 1:length(comparisons))
  {
  upregulated[index] = nrow(subset(Mde_annotated,Mde_annotated[[sig_genes_rownames[index]]] == "True" & Mde_annotated[[fold_change_rownames[index]]] > 0))
  downregulated[index] = nrow(subset(Mde_annotated,Mde_annotated[[sig_genes_rownames[index]]] == "True" & Mde_annotated[[fold_change_rownames[index]]] < 0))
  }
  
  dat <- data.frame(
    comparison = factor(default_comparison_labels, levels=default_comparison_labels),
    upregulated = upregulated,
    downregulated = downregulated
  )

  dat.m <- melt(dat, id.vars = "comparison")
  ggp = ggplot(data=dat.m , aes(x=comparison, y=value, fill=variable)) + geom_bar(colour="black", stat="identity", position = "dodge", size=bar_outline_size) + xlab(x_axis_label) + ylab(y_axis_label) + theme_SL2() + geom_text(aes(label=value), position=position_dodge(width=0.9), size=data_label_size, show.legend = FALSE, vjust=2) + scale_color_manual(values=bar_colours,labels=direction_labels) + scale_fill_manual(values=bar_colours,labels=direction_labels) + scale_x_discrete(labels=comparison_labels) + theme(legend.position=legend_position, legend.spacing.x = unit(0.25, 'cm'), axis.text.x = element_text(angle = 45, hjust = 1)) + scale_y_continuous(expand=c(0,0), limits=c(0,max(dat.m$value*1.1)))
  return(ggp)
}


##----- Significant Genes Heatmap Function  -----##
make_significant_genes_heatmap <- function(matrix_scaled,colours,sample_names,cluster_x,cluster_y,distance_method,clustering_method,reorder_function)
{

  if(nrow(matrix_scaled) >= 2) 
  {
    matrix_scaled_renamed = as.matrix(matrix_scaled)
    colnames(matrix_scaled_renamed) = sample_names
  
    matrix_scaled_renamed_clustered = cluster_matrix(matrix_scaled_renamed,cluster_x,cluster_y,distance_method,clustering_method,reorder_function)
    matrix_scaled_renamed_clustered_melted <- melt(matrix_scaled_renamed_clustered)
    matrix_scaled_renamed_clustered_melted$X1 = factor(matrix_scaled_renamed_clustered_melted$X1, levels=row.names(matrix_scaled_renamed_clustered))
    matrix_scaled_renamed_clustered_melted$X2 = factor(matrix_scaled_renamed_clustered_melted$X2, levels=colnames(matrix_scaled_renamed_clustered))

    hm.palette <- colorRampPalette(colours)
    ggp = ggplot(matrix_scaled_renamed_clustered_melted, aes(x = X2, y = X1, fill = value)) + geom_tile() + scale_fill_gradientn(colours = hm.palette(100)) + ylab('') + xlab('') + theme_SL2() + theme(legend.position="right", legend.title = element_blank(), legend.spacing.x = unit(0.25, 'cm'),axis.text.x = element_text(angle = 90, hjust = 1), axis.ticks=element_blank()) + scale_x_discrete(expand=c(0,0)) + scale_y_discrete(expand=c(0,0))
    return(ggp)
  }
  else
  {
    return(ggplot(data.frame()) + theme_SL2() + geom_blank() + ggtitle("There were too few genes to sensibly plot this."))
  }
}


##----- Pairwise Overlap Table Function  -----##
make_pairwise_overlap_table <- function(pairwise_overlap_summary,header_size,text_size,border_thickness)
{
  table_theme <- gridExtra::ttheme_minimal(core = list(fg_params=list(cex = text_size)),colhead = list(fg_params=list(cex = header_size)))
  colnames(pairwise_overlap_summary) = c("set 1 name","set 2 name", "background genes","set 1 total genes","set 2 total genes","set 1 unique gene","set 2 unique genes","overlapping genes","fold enrichment","p value")

  gt <- tableGrob(pairwise_overlap_summary, theme=table_theme, rows=NULL)
  gt <- gtable_add_grob(gt,grobs = rectGrob(gp = gpar(fill = NA, lwd = border_thickness)),t = 2, b = nrow(gt), l = 1, r = ncol(gt))
  gt <- gtable_add_grob(gt,grobs = rectGrob(gp = gpar(fill = NA, lwd = border_thickness)),t = 1, l = 1, r = ncol(gt))
  return(gt)
}





##----- Fold vs Fold Scatterplot Function -----##
make_fold_vs_fold_scatterplot <- function(comparison1,comparison2,colours,dot_size,dot_transparency,significant_name,non_significant_name,x_axis_label,y_axis_label,legend_position,data_label_size) 
{

  # gets the names of the columns that indicate significance
  sig_genes_rownames = data.frame(matrix(ncol=2, nrow=0), check.names=TRUE)
  colnames(sig_genes_rownames) = paste(c(comparison1,comparison2),"_sig",sep="")
  sig_genes_rownames = colnames(data.frame(sig_genes_rownames, check.names=TRUE))
  
  # gets the names of the columns that indicate fold change
  fold_change_rownames = data.frame(matrix(ncol=2, nrow=0), check.names=TRUE)
  colnames(fold_change_rownames) = paste(c(comparison1,comparison2),"_log2fold",sep="")
  fold_change_rownames = colnames(data.frame(fold_change_rownames, check.names=TRUE))
  
  # gets the sig flags
  sig_flags = character(nrow(Mde_annotated))
  
  for(index in 1:nrow(Mde_annotated))
  {
    if(Mde_annotated[[sig_genes_rownames[1]]][index] == "True" & Mde_annotated[[sig_genes_rownames[2]]][index] == "True") {sig_flags[index] = "sig both"}
    else if(Mde_annotated[[sig_genes_rownames[1]]][index] == "True" & Mde_annotated[[sig_genes_rownames[2]]][index] == "False") {sig_flags[index] = paste("sig ",comparison1, " only",sep="")}
    else if(Mde_annotated[[sig_genes_rownames[1]]][index] == "False" & Mde_annotated[[sig_genes_rownames[2]]][index] == "True") {sig_flags[index] = paste("sig ",comparison2, " only",sep="")}
    else {sig_flags[index] = "not sig"}
  }
  breaks = c("sig both",paste("sig ",comparison1, " only",sep=""),paste("sig ",comparison2, " only",sep=""),"not sig")
  sig_flags = factor(sig_flags, levels = breaks)
  
  # gets the correlation
  correlation <- cor.test(x=Mde_annotated[[fold_change_rownames[1]]], y=Mde_annotated[[fold_change_rownames[2]]], method = 'spearman')
  rr <- correlation$estimate
  formated_rr <- format(rr,digits = 2)
  title <- paste0("Spearman correlation coefficient = ",as.character(formated_rr))

  ggp = ggplot(data=Mde_annotated, aes(x=Mde_annotated[[fold_change_rownames[1]]], y=Mde_annotated[[fold_change_rownames[2]]], group=sig_flags,colour=sig_flags,fill=sig_flags)) + geom_point(size=dot_size,alpha=dot_transparency) + ggtitle(title) + xlab(x_axis_label) + ylab(y_axis_label) + theme_SL2() + theme(legend.position=legend_position, legend.title = element_blank()) + scale_color_manual(values=colours,breaks=breaks,labels=breaks) + scale_fill_manual(values=colours,breaks=breaks,labels=breaks) + geom_text(data=Mde_annotated,aes(label=rownames(Mde_annotated)),hjust=-0.1, vjust=-0.1, size=data_label_size, show.legend = FALSE)
  
  return(ggp)
}


##----- Meta-Gene Violin Plot Function  -----##
make_meta_gene_violin_plot <- function(matrix,signature_name,violin_transparency,violin_width,violin_line_thickness,violin_colours,violin_labels,trim_violin,jitter_dot_size,jitter_dot_colour,jitter_dot_width,summary_colour,summary_size,x_axis_label,y_axis_label,legend_position)
{
  ggp = ggplot(matrix, aes(x=sample_groupings, y=matrix[[signature_name]], color=sample_groupings, group=sample_groupings, fill=sample_groupings)) + geom_violin(trim=trim_violin, scale="width", width=violin_width, alpha = violin_transparency, size=violin_line_thickness) + geom_jitter(size=jitter_dot_size, colour=jitter_dot_colour, width=jitter_dot_width, height=0, show.legend = FALSE) + stat_summary(position=position_dodge(0.75), colour = summary_colour, size = summary_size, geom="pointrange", show.legend = FALSE) + scale_color_manual(values=violin_colours,breaks=sample_groups,labels=violin_labels,limits=sample_groups) + scale_fill_manual(values=violin_colours,breaks=sample_groups,labels=violin_labels,limits=sample_groups) + scale_x_discrete(breaks=sample_groups,labels=violin_labels,limits=sample_groups) + ylim(min(matrix[[signature_name]] * 1.25), max(matrix[[signature_name]] * 1.25)) + xlab(x_axis_label) + ylab(y_axis_label) + theme_SL2() + theme(legend.position=legend_position,axis.text.x = element_text(angle = 45, hjust = 1))
  return(ggp)
}


##----- Hypergeometric Gene Sets Bar Chart Function -----##
make_oras_bar_chart <- function(top_10_gene_sets,x_axis_label,y_axis_label,non_significant_colour,significant_colour,bar_outline_size,bar_transparency,legend_position,significant_name,non_significant_name,data_label_size)
{ 
  top_10_gene_sets <- top_10_gene_sets[seq(dim(top_10_gene_sets)[1],1),]
  n_sig = nrow(subset(top_10_gene_sets,significant == "TRUE"))
  n_non_sig = nrow(subset(top_10_gene_sets,significant == "FALSE"))
  

  if (n_sig+n_non_sig == 0)
  {
    ggp = ggplot(data.frame()) + theme_SL2() + geom_blank() + ggtitle("There were too few gene sets sensibly plot this.")
  }
  else if (n_sig == 0)
  {
      ggp = ggplot(data=top_10_gene_sets , aes(x=gene_set, y=-log10(p), fill=significant,group=significant)) + geom_bar(colour="black",stat="identity", position = "dodge", alpha = bar_transparency) + coord_flip() + scale_x_discrete(limits = top_10_gene_sets$gene_set) + ylab(x_axis_label)  + xlab(y_axis_label) + scale_fill_manual(values=c(non_significant_colour),breaks=c("FALSE"),labels=c(non_significant_name)) + theme_SL2() + theme(axis.text.y = element_text(hjust=1),legend.position=legend_position, legend.spacing.x = unit(0.15, 'cm')) + scale_y_continuous(expand=c(0,0), limits=c(0,max(-log10(top_10_gene_sets$p)*1.25))) + geom_text(aes(label=overlapping_genes), position=position_dodge(width=0.9), size=data_label_size, show.legend = FALSE, hjust=-0.5)
  }
  else if (n_non_sig == 0)
  {
      ggp = ggplot(data=top_10_gene_sets , aes(x=gene_set, y=-log10(p), fill=significant,group=significant)) + geom_bar(colour="black",stat="identity", position = "dodge", alpha = bar_transparency) + coord_flip() + scale_x_discrete(limits = top_10_gene_sets$gene_set) + ylab(x_axis_label)  + xlab(y_axis_label) + scale_fill_manual(values=c(significant_colour),breaks=c("TRUE"),labels=c(significant_name)) + theme_SL2() + theme(axis.text.y = element_text(hjust=1),legend.position=legend_position, legend.spacing.x = unit(0.15, 'cm')) + scale_y_continuous(expand=c(0,0), limits=c(0,max(-log10(top_10_gene_sets$p)*1.25))) + geom_text(aes(label=overlapping_genes), position=position_dodge(width=0.9), size=data_label_size, show.legend = FALSE, hjust=-0.5)
  }
  else if (n_sig != 10 && n_non_sig != 0 && n_sig != 0 && n_non_sig != 10)
  {
      ggp = ggplot(data=top_10_gene_sets , aes(x=gene_set, y=-log10(p), fill=significant,group=significant)) + geom_bar(colour="black",stat="identity", position = "dodge", alpha = bar_transparency) + coord_flip() + scale_x_discrete(limits = top_10_gene_sets$gene_set) + ylab(x_axis_label)  + xlab(y_axis_label) + scale_fill_manual(values=c(non_significant_colour,significant_colour),breaks=c("TRUE","FALSE"),labels=c(significant_name, non_significant_name)) + theme_SL2() + theme(axis.text.y = element_text(hjust=1),legend.position=legend_position, legend.spacing.x = unit(0.15, 'cm')) + scale_y_continuous(expand=c(0,0), limits=c(0,max(-log10(top_10_gene_sets$p)*1.25))) + geom_text(aes(label=overlapping_genes), position=position_dodge(width=0.9), size=data_label_size, show.legend = FALSE, hjust=-0.5)
  }
  return(ggp)
}



##-------------------------##
##          Plots          ##
##-------------------------##



##----- Distribution of Expression Values -----##

plot_height = 250
plot_width = 250
transparency = 0.5
line_thickness = 1
x_axis_label = "expression (log10)"
y_axis_label = "density"
legend_position = "none"

for(plot_sample_index in 1:length(samples))
{
  plot_sample = samples[plot_sample_index]
  plot_colour = default_samples_colours[plot_sample_index]
  ggp = make_distribution_of_expression_values_plot(plot_sample,plot_colour,transparency,line_thickness,x_axis_label,y_axis_label,legend_position)
  save_plot(ggp,plot_height,plot_width,paste("plots/distribution_of_expression_values/",plot_sample,"_distribution_of_expression_values.png",sep=""))
}


##----- PCA (Contribution of Components) -----##

plot_height = 300
plot_width = 400
x_axis_label = "component"
y_axis_label = "proportion of variance (%)"
dot_size = 4
dot_transparency = 1
dot_colour = "red"
line_type = "solid"
line_colour = "black"
line_size = 1

ggp = make_PCA_contribution_of_components_plot(x_axis_label,y_axis_label,dot_size,dot_transparency,dot_colour,line_type,line_colour,line_size)
save_plot(ggp,plot_height,plot_width,"plots/PCA/PCA_contribution_of_components.png")


##----- PCA (Scatter Plots) -----##

plot_height = 400
plot_width = 400
plot_sample_group_colours = default_sample_group_colours
plot_sample_group_labels = default_sample_group_labels
plot_sample_labels = default_sample_labels
plot_sample_groupings = sample_groupings
dot_size = 4
dot_transparency = 1
legend_position = "bottom"
sample_label_size = 4.5
show_proportion_of_variance = TRUE

component_x = 1
component_y = 2
x_axis_label = "PC1"
y_axis_label = "PC2"
ggp = make_PCA_scatterplot(plot_sample_groupings,component_x,component_y,x_axis_label,y_axis_label,plot_sample_group_colours,plot_sample_group_labels,plot_sample_labels,dot_size,dot_transparency,legend_position,sample_label_size,show_proportion_of_variance)
save_plot(ggp,plot_height,plot_width,"plots/PCA/PCA_1_vs_PCA_2_scatter_plot_labelled.png")

sample_label_size = 0 
ggp = make_PCA_scatterplot(plot_sample_groupings,component_x,component_y,x_axis_label,y_axis_label,plot_sample_group_colours,plot_sample_group_labels,plot_sample_labels,dot_size,dot_transparency,legend_position,sample_label_size,show_proportion_of_variance)
save_plot(ggp,plot_height,plot_width,"plots/PCA/PCA_1_vs_PCA_2_scatter_plot_unlabelled.png")

component_x = 3
component_y = 4
x_axis_label = "PC3"
y_axis_label = "PC4"
sample_label_size = 4.5
ggp = make_PCA_scatterplot(plot_sample_groupings,component_x,component_y,x_axis_label,y_axis_label,plot_sample_group_colours,plot_sample_group_labels,plot_sample_labels,dot_size,dot_transparency,legend_position,sample_label_size,show_proportion_of_variance)
save_plot(ggp,plot_height,plot_width,"plots/PCA/PCA_3_vs_PCA_4_scatter_plot_labelled.png")
 
sample_label_size = 0
ggp = make_PCA_scatterplot(plot_sample_groupings,component_x,component_y,x_axis_label,y_axis_label,plot_sample_group_colours,plot_sample_group_labels,plot_sample_labels,dot_size,dot_transparency,legend_position,sample_label_size,show_proportion_of_variance)
save_plot(ggp,plot_height,plot_width,"plots/PCA/PCA_3_vs_PCA_4_scatter_plot_unlabelled.png")


##----- Correlation Analysis Heatmap -----##

plot_height = 600
plot_width = 750
colours = default_three_tone_heatmap_colours
sample_names = default_sample_labels
distance_method = "spearman"
clustering_method = "average"
reorder_function = "average"
cluster_x = FALSE
cluster_y = FALSE

ggp = make_correlation_analysis_heatmap(colours,sample_names,cluster_x,cluster_y,distance_method,clustering_method,reorder_function)
save_plot(ggp,plot_height,plot_width,"plots/correlation_analysis/correlation_analysis_heatmap.png")

cluster_x = TRUE
cluster_y = TRUE
ggp = make_correlation_analysis_heatmap(colours,sample_names,cluster_x,cluster_y,distance_method,clustering_method,reorder_function)
save_plot(ggp,plot_height,plot_width,"plots/correlation_analysis/correlation_analysis_heatmap_clustered.png")


##----- Most Expressed Genes (Tables) -----##

plot_height = 300
plot_width = 750
header_size = 1.25
text_size = 1.25
border_thickness = 2

for(sample_group_index in 1:length(sample_groups))
{
  sample_group = sample_groups[sample_group_index]
  top_10_genes = get_top_10_genes_by_mean_expression(sample_group_index)
  gt = make_most_expressed_genes_table(top_10_genes,header_size,text_size,border_thickness)
  save_table(gt,plot_height,plot_width,paste("plots/most_expressed_genes/",sample_group,"_most_expressed_genes_table.png",sep=""))
}


##----- Most Expressed Genes (Violin Plots) -----##

plot_height = 350
plot_width = 350
violin_transparency = 0.5
violin_width = 0.75
violin_line_thickness = 1
violin_colours = default_sample_group_colours 	# note: changing this won't change the order the groups appear in the x axis. Merely what they are coloured as.
violin_labels = default_sample_group_labels	# note: changing this won't change the order the groups appear in the x axis. Merely what they are named as.
trim_violin = FALSE
jitter_dot_size = 2
jitter_dot_colour = "black"
jitter_dot_width = 0.2
summary_colour = "red"
summary_size = 0.25
x_axis_label = ""
y_axis_label = "expression"
legend_position = "none"

for(sample_group_index in 1:length(sample_groups))
{
  sample_group = sample_groups[sample_group_index]
  top_10_genes = get_top_10_genes_by_mean_expression(sample_group_index)
  
  for (gene_index in 1:10)
  {
    gene = top_10_genes[gene_index]
    ggp = make_gene_expression_violin_plot(ne_matrix_transposed,gene,violin_transparency,violin_width,violin_line_thickness,violin_colours,violin_labels,trim_violin,jitter_dot_size,jitter_dot_colour,jitter_dot_width,summary_colour,summary_size,x_axis_label,y_axis_label,legend_position)
    save_plot(ggp,plot_height,plot_width,paste("plots/most_expressed_genes/",sample_group,"_no.",gene_index,"_most_expressed_gene.png",sep=""))
  }
}


##----- Number of Significant Genes Barchart -----##

plot_height = 500
plot_width = 750
x_axis_label = ""
y_axis_label = "number of significant genes"
comparison_labels = default_comparison_labels # note: changing this won't change the order the comparisons appear in the x axis. Merely what they are labelled as.
direction_labels = c("up","down") # note: changing this won't change the order the bars appear in the x axis. Merely what they are labelled as.
bar_colours = default_two_tone_greyscale # note: changing this won't change the order the bars appear in the x axis. Merely what they are coloured as.
legend_position = "bottom"
data_label_size = 5
bar_outline_size = 1

ggp = make_number_of_significant_genes_barchart(x_axis_label,y_axis_label,comparison_labels,direction_labels,bar_colours,legend_position,data_label_size,bar_outline_size)
save_plot(ggp,plot_height,plot_width,"plots/number_of_significant_genes/number_of_significant_genes_barchart.png")


##----- Significant Genes Heatmap  -----##

plot_height = 750
plot_width = 500
colours = default_three_tone_heatmap_colours
sample_names = default_sample_labels
distance_method = "spearman"
clustering_method = "average"
reorder_function = "average"

cluster_x = FALSE
cluster_y = TRUE

ggp = make_significant_genes_heatmap(ne_matrix_sig_any_scaled,colours,sample_names,cluster_x,cluster_y,distance_method,clustering_method,reorder_function)
save_plot(ggp,plot_height,plot_width,"plots/significant_genes_heatmaps/genes_significant_in_any_des_heatmap.png")

cluster_x = TRUE
cluster_y = TRUE

ggp = make_significant_genes_heatmap(ne_matrix_sig_any_scaled,colours,sample_names,cluster_x,cluster_y,distance_method,clustering_method,reorder_function)
save_plot(ggp,plot_height,plot_width,"plots/significant_genes_heatmaps/genes_significant_in_any_des_heatmap_column_clustered.png")

cluster_x = FALSE
cluster_y = TRUE

ggp = make_significant_genes_heatmap(ne_matrix_sig_all_scaled,colours,sample_names,cluster_x,cluster_y,distance_method,clustering_method,reorder_function)
save_plot(ggp,plot_height,plot_width,"plots/significant_genes_heatmaps/genes_significant_in_all_des_heatmap.png")

cluster_x = TRUE
cluster_y = TRUE

ggp = make_significant_genes_heatmap(ne_matrix_sig_all_scaled,colours,sample_names,cluster_x,cluster_y,distance_method,clustering_method,reorder_function)
save_plot(ggp,plot_height,plot_width,"plots/significant_genes_heatmaps/genes_significant_in_all_des_heatmap_column_clustered.png")


##----- Pairwise Overlap (Table) -----##

plot_height = 300
plot_width = 1800
header_size = 1.25
text_size = 1.25
border_thickness = 2

gt = make_pairwise_overlap_table(pairwise_overlap_summary,header_size,text_size,border_thickness)
png("plots/pairwise_overlap/pairwise_overlap_table.png", height=300, width=1800, pointsize=5)
grid.arrange(gt)
dev.off()


##----- Fold vs Fold Scatterplot -----##

colours = c(default_significant_both_colour,default_significant_a_colour,default_significant_b_colour,default_non_significant_colour)
dot_size = 1.5
plot_height = 600
plot_width = 600
dot_transparency = 1
legend_position = "bottom"
data_label_size = 4.5

for(index1 in 1:length(comparisons))
{  
  for(index2 in index1:length(comparisons))
  {
    if(index1 != index2) 
    {
      comparison1 = comparisons[index1]
      comparison2 = comparisons[index2]
      data_label_size = 4.5
      x_axis_label = paste(comparison1," log2fold",sep="")
      y_axis_label = paste(comparison2," log2fold",sep="")
      ggp = make_fold_vs_fold_scatterplot(comparison1,comparison2,colours,dot_size,dot_transparency,significant_name,non_significant_name,x_axis_label,y_axis_label,legend_position,data_label_size)
      save_plot(ggp,plot_height,plot_width,paste("plots/fold_vs_fold_scatterplots/",gsub(" vs ", "_vs_", comparison1),"_VS_",gsub(" vs ", "_vs_", comparison2),"_labelled.png",sep=""))
      
      data_label_size = 0
      ggp = make_fold_vs_fold_scatterplot(comparison1,comparison2,colours,dot_size,dot_transparency,significant_name,non_significant_name,x_axis_label,y_axis_label,legend_position,data_label_size)
      save_plot(ggp,plot_height,plot_width,paste("plots/fold_vs_fold_scatterplots/",gsub(" vs ", "_vs_", comparison1),"_VS_",gsub(" vs ", "_vs_", comparison2),"_unlabelled.png",sep=""))
    }
  }
}


##----- Differential Expression Signature Metagene Boxplots  -----##

plot_height = 350
plot_width = 400
violin_transparency = 0.5
violin_width = 0.75
violin_line_thickness = 1
violin_colours = default_sample_group_colours 	# note: changing this won't change the order the groups appear in the x axis. Merely what they are coloured as.
violin_labels = default_sample_group_labels	# note: changing this won't change the order the groups appear in the x axis. Merely what they are named as.
trim_violin = FALSE
jitter_dot_size = 2
jitter_dot_colour = "black"
jitter_dot_width = 0.2
summary_colour = "red"
summary_size = 0.25
x_axis_label = "sample group"
y_axis_label = "meta-gene expression\n(mean z-score)"
legend_position = "none"

for (signature_number in 1:nrow(signature_summary))
{
signature_name = paste("signature_",signature_number,sep="")
signature_metagene = data.frame(t(signature_summary[,samples]))
ggp = make_meta_gene_violin_plot(signature_metagene,signature_name,violin_transparency,violin_width,violin_line_thickness,violin_colours,violin_labels,trim_violin,jitter_dot_size,jitter_dot_colour,jitter_dot_width,summary_colour,summary_size,x_axis_label,y_axis_label,legend_position)
save_plot(ggp,plot_height,plot_width,paste("plots/differential_expression_signature/metagene_violin_plots/signature_",signature_number,"_violin.png",sep=""))
}


##----- Differential Expression Signatures Heatmaps  -----##

plot_height = 750
plot_width = 500
colours = default_three_tone_heatmap_colours
sample_names = default_sample_labels
distance_method = "spearman"
clustering_method = "average"
reorder_function = "average"
cluster_x = FALSE
cluster_y = TRUE

for (signature in 1:nrow(signature_summary))
{
signature_genes = read.table(file=paste("data/statistical_analysis/differential_expression_signature/gene_symbols/signature_",signature,"_symbols.txt",sep=""), header=FALSE,row.names = 1, sep='\t', quote='',check.names = TRUE)
signature_ne_matrix = Mde_annotated[row.names(signature_genes),samples]
signature_ne_matrix_scaled = data.frame(t(scale(t(signature_ne_matrix))))
rownames(signature_ne_matrix_scaled) = rownames(signature_ne_matrix)
signature_ne_matrix_scaled = na.omit(signature_ne_matrix_scaled)
signature_ne_matrix_scaled = signature_ne_matrix_scaled[is.finite(rowSums(signature_ne_matrix_scaled)), ]

ggp = make_significant_genes_heatmap(signature_ne_matrix_scaled,colours,sample_names,cluster_x,cluster_y,distance_method,clustering_method,reorder_function)
save_plot(ggp,plot_height,plot_width,paste("plots/differential_expression_signature/signature_heatmaps/signature_",signature,"_heatmap.png",sep=""))
}


##----- Differential Expression Signatures Hypergeometric Enriched Gene Sets (Bar Charts) -----##

plot_height = 350
plot_width = 1000
x_axis_label = "-log10 p-value"
y_axis_label = ""
non_significant_colour = default_non_significant_colour
significant_colour = default_significant_colour
bar_outline_size = 1
bar_transparency = 0.75
legend_position = "bottom"
significant_name = "significant"
non_significant_name = "non-significant"
data_label_size = 5

all_gene_sets = read.table(file="data/statistical_analysis/differential_expression_signature/over_representation_analysis/GO_BP/signature_1/all_gene_sets_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
enriched_gene_sets = read.table(file="data/statistical_analysis/differential_expression_signature/over_representation_analysis/GO_BP/signature_1/enriched_gene_sets_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)

top_10_gene_sets = get_top10_oras_by_p_value(all_gene_sets,enriched_gene_sets,"enrichment")
ggp = make_oras_bar_chart(top_10_gene_sets,x_axis_label,y_axis_label,non_significant_colour,significant_colour,bar_outline_size,bar_transparency,legend_position,significant_name,non_significant_name,data_label_size)
save_plot(ggp,plot_height,plot_width,"plots/differential_expression_signature/signature_ora_enrichment/GO_BP/signature_1_enriched_gene_sets_barchart.png")

all_gene_sets = read.table(file="data/statistical_analysis/differential_expression_signature/over_representation_analysis/GO_BP/signature_2/all_gene_sets_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
enriched_gene_sets = read.table(file="data/statistical_analysis/differential_expression_signature/over_representation_analysis/GO_BP/signature_2/enriched_gene_sets_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)

top_10_gene_sets = get_top10_oras_by_p_value(all_gene_sets,enriched_gene_sets,"enrichment")
ggp = make_oras_bar_chart(top_10_gene_sets,x_axis_label,y_axis_label,non_significant_colour,significant_colour,bar_outline_size,bar_transparency,legend_position,significant_name,non_significant_name,data_label_size)
save_plot(ggp,plot_height,plot_width,"plots/differential_expression_signature/signature_ora_enrichment/GO_BP/signature_2_enriched_gene_sets_barchart.png")

all_gene_sets = read.table(file="data/statistical_analysis/differential_expression_signature/over_representation_analysis/GO_BP/signature_3/all_gene_sets_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
enriched_gene_sets = read.table(file="data/statistical_analysis/differential_expression_signature/over_representation_analysis/GO_BP/signature_3/enriched_gene_sets_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)

top_10_gene_sets = get_top10_oras_by_p_value(all_gene_sets,enriched_gene_sets,"enrichment")
ggp = make_oras_bar_chart(top_10_gene_sets,x_axis_label,y_axis_label,non_significant_colour,significant_colour,bar_outline_size,bar_transparency,legend_position,significant_name,non_significant_name,data_label_size)
save_plot(ggp,plot_height,plot_width,"plots/differential_expression_signature/signature_ora_enrichment/GO_BP/signature_3_enriched_gene_sets_barchart.png")

all_gene_sets = read.table(file="data/statistical_analysis/differential_expression_signature/over_representation_analysis/GO_BP/signature_4/all_gene_sets_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
enriched_gene_sets = read.table(file="data/statistical_analysis/differential_expression_signature/over_representation_analysis/GO_BP/signature_4/enriched_gene_sets_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)

top_10_gene_sets = get_top10_oras_by_p_value(all_gene_sets,enriched_gene_sets,"enrichment")
ggp = make_oras_bar_chart(top_10_gene_sets,x_axis_label,y_axis_label,non_significant_colour,significant_colour,bar_outline_size,bar_transparency,legend_position,significant_name,non_significant_name,data_label_size)
save_plot(ggp,plot_height,plot_width,"plots/differential_expression_signature/signature_ora_enrichment/GO_BP/signature_4_enriched_gene_sets_barchart.png")

all_gene_sets = read.table(file="data/statistical_analysis/differential_expression_signature/over_representation_analysis/GO_BP/signature_5/all_gene_sets_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
enriched_gene_sets = read.table(file="data/statistical_analysis/differential_expression_signature/over_representation_analysis/GO_BP/signature_5/enriched_gene_sets_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)

top_10_gene_sets = get_top10_oras_by_p_value(all_gene_sets,enriched_gene_sets,"enrichment")
ggp = make_oras_bar_chart(top_10_gene_sets,x_axis_label,y_axis_label,non_significant_colour,significant_colour,bar_outline_size,bar_transparency,legend_position,significant_name,non_significant_name,data_label_size)
save_plot(ggp,plot_height,plot_width,"plots/differential_expression_signature/signature_ora_enrichment/GO_BP/signature_5_enriched_gene_sets_barchart.png")

all_gene_sets = read.table(file="data/statistical_analysis/differential_expression_signature/over_representation_analysis/GO_BP/signature_6/all_gene_sets_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
enriched_gene_sets = read.table(file="data/statistical_analysis/differential_expression_signature/over_representation_analysis/GO_BP/signature_6/enriched_gene_sets_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)

top_10_gene_sets = get_top10_oras_by_p_value(all_gene_sets,enriched_gene_sets,"enrichment")
ggp = make_oras_bar_chart(top_10_gene_sets,x_axis_label,y_axis_label,non_significant_colour,significant_colour,bar_outline_size,bar_transparency,legend_position,significant_name,non_significant_name,data_label_size)
save_plot(ggp,plot_height,plot_width,"plots/differential_expression_signature/signature_ora_enrichment/GO_BP/signature_6_enriched_gene_sets_barchart.png")

all_gene_sets = read.table(file="data/statistical_analysis/differential_expression_signature/over_representation_analysis/GO_BP/signature_7/all_gene_sets_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)
enriched_gene_sets = read.table(file="data/statistical_analysis/differential_expression_signature/over_representation_analysis/GO_BP/signature_7/enriched_gene_sets_results.csv", header=TRUE, sep='\t', quote='',check.names = TRUE)

top_10_gene_sets = get_top10_oras_by_p_value(all_gene_sets,enriched_gene_sets,"enrichment")
ggp = make_oras_bar_chart(top_10_gene_sets,x_axis_label,y_axis_label,non_significant_colour,significant_colour,bar_outline_size,bar_transparency,legend_position,significant_name,non_significant_name,data_label_size)
save_plot(ggp,plot_height,plot_width,"plots/differential_expression_signature/signature_ora_enrichment/GO_BP/signature_7_enriched_gene_sets_barchart.png")





##---- image and session info ----##
save.image("/home/john/Downloads/TEMP/DESEQ2/results/all_genes/mde_workflows/all/plots/workflow.rdata")
write.table(capture.output(sessionInfo()), file="/home/john/Downloads/TEMP/DESEQ2/results/all_genes/mde_workflows/all/plots/workflow_session_info.txt")
