##---- general libraries ----##
library(ggplot2)
library(reshape)

##---- Mde sample and group names ----##
samples = c("KO_R1","KO_R2","KO_R3","WT_R1","WT_R2","WT_R3","KO_RESCUE_R1","KO_RESCUE_R2","KO_RESCUE_R3")
sample_groups = c("KO","WT","KO_RESCUE")
sample_groupings = c("KO","KO","KO","WT","WT","WT","KO_RESCUE","KO_RESCUE","KO_RESCUE")
sample_groupings = factor(sample_groupings, levels = sample_groups)
samples_by_sample_group = list(c("KO_R1","KO_R2","KO_R3"),c("WT_R1","WT_R2","WT_R3"),c("KO_RESCUE_R1","KO_RESCUE_R2","KO_RESCUE_R3"))
comparisons = c("KO vs WT","KO_RESCUE vs KO")

##---- sets the working directory. If you move the SL2 folder please update this path ----##
setwd("/home/john/Downloads/TEMP/DESEQ2/results/all_genes/mde_workflows/all")

##---- differential expression signature input files ----##
signature_summary = read.table(file="data/statistical_analysis/differential_expression_signature/Signature_summary.csv", header=TRUE,row.names = 1, sep='\t', quote='',check.names = TRUE)

##---- SL2 Theme ----##
theme_SL2 <- function () { 
    theme_bw() %+replace% 
        theme(
	    panel.grid = element_blank(),
            panel.background = element_blank(),
            panel.border = element_rect(colour = "black", fill=NA, size=1),
            plot.background = element_blank(), 
            legend.background = element_rect(fill="transparent", colour=NA),
            legend.key = element_rect(fill="transparent", colour=NA),
            plot.title = element_text(size=16, margin = margin(b = 5),hjust=0,vjust=0.5, family="Arial", face="bold"),
            title = element_text(size = 16, margin = margin(b = 5),hjust=0,vjust=0.5, family="Arial", face="bold"),
            axis.text.y = element_text(size = 14, margin = margin(r = 5),hjust=1,vjust=0.5, family="Arial", face="bold",colour="black"),
            axis.text.x = element_text(size = 14, margin = margin(t = 5),hjust=0.5,vjust=1, family="Arial", face="bold",colour="black"), 
            axis.title.y = element_text(size = 16, margin = margin(r = 10),angle = 90,hjust=0.5,vjust=0.5, family="Arial", face="bold"),
            axis.title.x = element_text(size = 16, margin = margin(t = 10),hjust=0.5,vjust=1, family="Arial", face="bold"),
            legend.text=element_text(size=14, family="Arial", face="bold"),
            legend.title=element_blank(), 
            legend.key.size=unit(2.5,"line"),
            plot.margin=unit(c(0.4,0.4,0.4,0.4), "cm")
        )
}

##----- Default GGplot Colours Function -----##
gg_color_hue <- function(n) {
  hues = seq(15, 375, length = n + 1)
  hcl(h = hues, l = 65, c = 100)[1:n]
}

##---- Default Sample and Sample Group Colours  ----##
number_of_sample_groups = length(sample_groups)
default_sample_group_colours = gg_color_hue(number_of_sample_groups)
default_samples_colours = c(default_sample_group_colours[1],default_sample_group_colours[1],default_sample_group_colours[1],default_sample_group_colours[2],default_sample_group_colours[2],default_sample_group_colours[2],default_sample_group_colours[3],default_sample_group_colours[3],default_sample_group_colours[3])

##---- Default Sample Group Labels  ----##
default_sample_group_labels = c("KO","WT","KO_RESCUE") # note: changing this won't change the order the groups appear on the plots. Merely what they are labelled as.

##---- Save Plot Function -----##
save_plot <- function(ggp,plot_height,plot_width,plot_path)
{
  png(plot_path, height=plot_height, width=plot_width, pointsize=5)
  print(ggp)
  dev.off()

  # clears all devices - as a safety measure
  while (dev.cur()>1) dev.off()
}

##----- Meta-Gene Violin Plot Function  -----##
make_meta_gene_violin_plot <- function(matrix,signature_name,violin_transparency,violin_width,violin_line_thickness,violin_colours,violin_labels,trim_violin,jitter_dot_size,jitter_dot_colour,jitter_dot_width,summary_colour,summary_size,x_axis_label,y_axis_label,legend_position)
{
  ggp = ggplot(matrix, aes(x=sample_groupings, y=matrix[[signature_name]], color=sample_groupings, group=sample_groupings, fill=sample_groupings)) + geom_violin(trim=trim_violin, scale="width", width=violin_width, alpha = violin_transparency, size=violin_line_thickness) + geom_jitter(size=jitter_dot_size, colour=jitter_dot_colour, width=jitter_dot_width, height=0, show.legend = FALSE) + stat_summary(position=position_dodge(0.75), colour = summary_colour, size = summary_size, geom="pointrange", show.legend = FALSE) + scale_color_manual(values=violin_colours,breaks=sample_groups,labels=violin_labels,limits=sample_groups) + scale_fill_manual(values=violin_colours,breaks=sample_groups,labels=violin_labels,limits=sample_groups) + scale_x_discrete(breaks=sample_groups,labels=violin_labels,limits=sample_groups) + ylim(min(matrix[[signature_name]] * 1.25), max(matrix[[signature_name]] * 1.25)) + xlab(x_axis_label) + ylab(y_axis_label) + theme_SL2() + theme(legend.position=legend_position,axis.text.x = element_text(angle = 45, hjust = 1))
  return(ggp)
}

##----- Differential Expression Signature Metagene Boxplots  -----##

plot_height = 350
plot_width = 400
violin_transparency = 0.5
violin_width = 0.75
violin_line_thickness = 1
violin_colours = default_sample_group_colours 	# note: changing this won't change the order the groups appear in the x axis. Merely what they are coloured as.
violin_labels = default_sample_group_labels	# note: changing this won't change the order the groups appear in the x axis. Merely what they are named as.
trim_violin = FALSE
jitter_dot_size = 2
jitter_dot_colour = "black"
jitter_dot_width = 0.2
summary_colour = "red"
summary_size = 0.25
x_axis_label = "sample group"
y_axis_label = "meta-gene expression\n(mean z-score)"
legend_position = "none"

for (signature_number in 1:nrow(signature_summary))
{
signature_name = paste("signature_",signature_number,sep="")
signature_metagene = data.frame(t(signature_summary[,samples]))
ggp = make_meta_gene_violin_plot(signature_metagene,signature_name,violin_transparency,violin_width,violin_line_thickness,violin_colours,violin_labels,trim_violin,jitter_dot_size,jitter_dot_colour,jitter_dot_width,summary_colour,summary_size,x_axis_label,y_axis_label,legend_position)
save_plot(ggp,plot_height,plot_width,paste("plots/differential_expression_signature/metagene_violin_plots/signature_",signature_number,"_violin.png",sep=""))
}

