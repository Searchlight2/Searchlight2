##---- general libraries ----##
library(ggplot2)
library(reshape)

##---- heatmap libraries ----##
library(amap)

##---- Mde sample and group names ----##
samples = c("KO_R1","KO_R2","KO_R3","WT_R1","WT_R2","WT_R3","KO_RESCUE_R1","KO_RESCUE_R2","KO_RESCUE_R3")
sample_groups = c("KO","WT","KO_RESCUE")
sample_groupings = c("KO","KO","KO","WT","WT","WT","KO_RESCUE","KO_RESCUE","KO_RESCUE")
sample_groupings = factor(sample_groupings, levels = sample_groups)
samples_by_sample_group = list(c("KO_R1","KO_R2","KO_R3"),c("WT_R1","WT_R2","WT_R3"),c("KO_RESCUE_R1","KO_RESCUE_R2","KO_RESCUE_R3"))
comparisons = c("KO vs WT","KO_RESCUE vs KO")

##---- sets the working directory. If you move the SL2 folder please update this path ----##
setwd("/home/john/Downloads/TEMP/DESEQ2/results/all_genes/mde_workflows/all")

##---- Mde input files ----##
Mde_annotated = read.table(file="data/all_genes_annotated.csv", header=TRUE,row.names = 2, sep='\t', quote='',check.names = TRUE)
Mde_annotated_sig_any = read.table(file="data/genes_significant_in_any_des_annotated.csv", header=TRUE,row.names = 2, sep='\t', quote='',check.names = TRUE)
Mde_annotated_sig_all = read.table(file="data/genes_significant_in_all_des_annotated.csv", header=TRUE,row.names = 2, sep='\t', quote='',check.names = TRUE)

##---- Mde parse ne matrix ----##
ne_matrix = Mde_annotated[,samples]
ne_matrix_sig_any = Mde_annotated_sig_any[,samples]
ne_matrix_sig_all = Mde_annotated_sig_all[,samples]

##---- transpose and scale significant genes ne matrix ----##
ne_matrix_sig_any_scaled = data.frame(t(scale(t(ne_matrix_sig_any))))
rownames(ne_matrix_sig_any_scaled) = rownames(ne_matrix_sig_any)
ne_matrix_sig_any_scaled[do.call(cbind, lapply(ne_matrix_sig_any_scaled, is.nan))] <- 0
ne_matrix_sig_any_scaled = ne_matrix_sig_any_scaled[is.finite(rowSums(ne_matrix_sig_any_scaled)), ]

ne_matrix_sig_all_scaled = data.frame(t(scale(t(ne_matrix_sig_all))))
rownames(ne_matrix_sig_all_scaled) = rownames(ne_matrix_sig_all)
ne_matrix_sig_all_scaled[do.call(cbind, lapply(ne_matrix_sig_all_scaled, is.nan))] <- 0
ne_matrix_sig_all_scaled = ne_matrix_sig_all_scaled[is.finite(rowSums(ne_matrix_sig_all_scaled)), ]

##---- SL2 Theme ----##
theme_SL2 <- function () { 
    theme_bw() %+replace% 
        theme(
	    panel.grid = element_blank(),
            panel.background = element_blank(),
            panel.border = element_rect(colour = "black", fill=NA, size=1),
            plot.background = element_blank(), 
            legend.background = element_rect(fill="transparent", colour=NA),
            legend.key = element_rect(fill="transparent", colour=NA),
            plot.title = element_text(size=16, margin = margin(b = 5),hjust=0,vjust=0.5, family="Arial", face="bold"),
            title = element_text(size = 16, margin = margin(b = 5),hjust=0,vjust=0.5, family="Arial", face="bold"),
            axis.text.y = element_text(size = 14, margin = margin(r = 5),hjust=1,vjust=0.5, family="Arial", face="bold",colour="black"),
            axis.text.x = element_text(size = 14, margin = margin(t = 5),hjust=0.5,vjust=1, family="Arial", face="bold",colour="black"), 
            axis.title.y = element_text(size = 16, margin = margin(r = 10),angle = 90,hjust=0.5,vjust=0.5, family="Arial", face="bold"),
            axis.title.x = element_text(size = 16, margin = margin(t = 10),hjust=0.5,vjust=1, family="Arial", face="bold"),
            legend.text=element_text(size=14, family="Arial", face="bold"),
            legend.title=element_blank(), 
            legend.key.size=unit(2.5,"line"),
            plot.margin=unit(c(0.4,0.4,0.4,0.4), "cm")
        )
}

##---- Default Three Tone Heatmap Colours  ----##
default_three_tone_heatmap_colours = c("blue","pink","red")

##---- Default Sample Labels  ----##
default_sample_labels = c("KO_R1","KO_R2","KO_R3","WT_R1","WT_R2","WT_R3","KO_RESCUE_R1","KO_RESCUE_R2","KO_RESCUE_R3") # note: changing this won't change the order the samples appear on the plots. Merely what they are labelled as. 

##---- Save Plot Function -----##
save_plot <- function(ggp,plot_height,plot_width,plot_path)
{
  png(plot_path, height=plot_height, width=plot_width, pointsize=5)
  print(ggp)
  dev.off()

  # clears all devices - as a safety measure
  while (dev.cur()>1) dev.off()
}

##----- Clustering Method -----##
cluster_matrix <- function(mx,cluster_x,cluster_y,distance_method,clustering_method,reorder_function)
{
  x.cluster = hclust(Dist(t(mx), method=distance_method), method=clustering_method)
  y.cluster = hclust(Dist(mx, method=distance_method), method=clustering_method)
  
  x.dd = as.dendrogram(x.cluster)
  y.dd = as.dendrogram(y.cluster)
  x.dd.reorder = reorder(x.dd,0,FUN=reorder_function)
  y.dd.reorder = reorder(y.dd,0,FUN=reorder_function)
  x.order = order.dendrogram(x.dd.reorder)
  y.order = order.dendrogram(y.dd.reorder)

  if(cluster_x == TRUE && cluster_y == TRUE) 
  {
      mx_clustered = mx[y.order,x.order]
  }
  
  if(cluster_x == TRUE && cluster_y == FALSE)
  {
      mx_clustered = mx[,x.order]
  }
  
  if(cluster_x == FALSE && cluster_y == TRUE)
  {
      mx_clustered = mx[y.order,]
  }
  if(cluster_x == FALSE && cluster_y == FALSE) 
  {
      mx_clustered = mx
  }
  return(mx_clustered)
}

##----- Significant Genes Heatmap Function  -----##
make_significant_genes_heatmap <- function(matrix_scaled,colours,sample_names,cluster_x,cluster_y,distance_method,clustering_method,reorder_function)
{

  if(nrow(matrix_scaled) >= 2) 
  {
    matrix_scaled_renamed = as.matrix(matrix_scaled)
    colnames(matrix_scaled_renamed) = sample_names
  
    matrix_scaled_renamed_clustered = cluster_matrix(matrix_scaled_renamed,cluster_x,cluster_y,distance_method,clustering_method,reorder_function)
    matrix_scaled_renamed_clustered_melted <- melt(matrix_scaled_renamed_clustered)
    matrix_scaled_renamed_clustered_melted$X1 = factor(matrix_scaled_renamed_clustered_melted$X1, levels=row.names(matrix_scaled_renamed_clustered))
    matrix_scaled_renamed_clustered_melted$X2 = factor(matrix_scaled_renamed_clustered_melted$X2, levels=colnames(matrix_scaled_renamed_clustered))

    hm.palette <- colorRampPalette(colours)
    ggp = ggplot(matrix_scaled_renamed_clustered_melted, aes(x = X2, y = X1, fill = value)) + geom_tile() + scale_fill_gradientn(colours = hm.palette(100)) + ylab('') + xlab('') + theme_SL2() + theme(legend.position="right", legend.title = element_blank(), legend.spacing.x = unit(0.25, 'cm'),axis.text.x = element_text(angle = 90, hjust = 1), axis.ticks=element_blank()) + scale_x_discrete(expand=c(0,0)) + scale_y_discrete(expand=c(0,0))
    return(ggp)
  }
  else
  {
    return(ggplot(data.frame()) + theme_SL2() + geom_blank() + ggtitle("There were too few genes to sensibly plot this."))
  }
}

##----- Significant Genes Heatmap  -----##

plot_height = 750
plot_width = 500
colours = default_three_tone_heatmap_colours
sample_names = default_sample_labels
distance_method = "spearman"
clustering_method = "average"
reorder_function = "average"

cluster_x = FALSE
cluster_y = TRUE

ggp = make_significant_genes_heatmap(ne_matrix_sig_any_scaled,colours,sample_names,cluster_x,cluster_y,distance_method,clustering_method,reorder_function)
save_plot(ggp,plot_height,plot_width,"plots/significant_genes_heatmaps/genes_significant_in_any_des_heatmap.png")

cluster_x = TRUE
cluster_y = TRUE

ggp = make_significant_genes_heatmap(ne_matrix_sig_any_scaled,colours,sample_names,cluster_x,cluster_y,distance_method,clustering_method,reorder_function)
save_plot(ggp,plot_height,plot_width,"plots/significant_genes_heatmaps/genes_significant_in_any_des_heatmap_column_clustered.png")

cluster_x = FALSE
cluster_y = TRUE

ggp = make_significant_genes_heatmap(ne_matrix_sig_all_scaled,colours,sample_names,cluster_x,cluster_y,distance_method,clustering_method,reorder_function)
save_plot(ggp,plot_height,plot_width,"plots/significant_genes_heatmaps/genes_significant_in_all_des_heatmap.png")

cluster_x = TRUE
cluster_y = TRUE

ggp = make_significant_genes_heatmap(ne_matrix_sig_all_scaled,colours,sample_names,cluster_x,cluster_y,distance_method,clustering_method,reorder_function)
save_plot(ggp,plot_height,plot_width,"plots/significant_genes_heatmaps/genes_significant_in_all_des_heatmap_column_clustered.png")

