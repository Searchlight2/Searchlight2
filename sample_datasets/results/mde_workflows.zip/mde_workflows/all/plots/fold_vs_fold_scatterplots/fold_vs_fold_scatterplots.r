##---- general libraries ----##
library(ggplot2)
library(reshape)

##---- Mde sample and group names ----##
samples = c("KO_R1","KO_R2","KO_R3","WT_R1","WT_R2","WT_R3","KO_RESCUE_R1","KO_RESCUE_R2","KO_RESCUE_R3")
sample_groups = c("KO","WT","KO_RESCUE")
sample_groupings = c("KO","KO","KO","WT","WT","WT","KO_RESCUE","KO_RESCUE","KO_RESCUE")
sample_groupings = factor(sample_groupings, levels = sample_groups)
samples_by_sample_group = list(c("KO_R1","KO_R2","KO_R3"),c("WT_R1","WT_R2","WT_R3"),c("KO_RESCUE_R1","KO_RESCUE_R2","KO_RESCUE_R3"))
comparisons = c("KO vs WT","KO_RESCUE vs KO")

##---- sets the working directory. If you move the SL2 folder please update this path ----##
setwd("/home/john/Downloads/TEMP/DESEQ2/results/all_genes/mde_workflows/all")

##---- Mde input files ----##
Mde_annotated = read.table(file="data/all_genes_annotated.csv", header=TRUE,row.names = 2, sep='\t', quote='',check.names = TRUE)
Mde_annotated_sig_any = read.table(file="data/genes_significant_in_any_des_annotated.csv", header=TRUE,row.names = 2, sep='\t', quote='',check.names = TRUE)
Mde_annotated_sig_all = read.table(file="data/genes_significant_in_all_des_annotated.csv", header=TRUE,row.names = 2, sep='\t', quote='',check.names = TRUE)

##---- SL2 Theme ----##
theme_SL2 <- function () { 
    theme_bw() %+replace% 
        theme(
	    panel.grid = element_blank(),
            panel.background = element_blank(),
            panel.border = element_rect(colour = "black", fill=NA, size=1),
            plot.background = element_blank(), 
            legend.background = element_rect(fill="transparent", colour=NA),
            legend.key = element_rect(fill="transparent", colour=NA),
            plot.title = element_text(size=16, margin = margin(b = 5),hjust=0,vjust=0.5, family="Arial", face="bold"),
            title = element_text(size = 16, margin = margin(b = 5),hjust=0,vjust=0.5, family="Arial", face="bold"),
            axis.text.y = element_text(size = 14, margin = margin(r = 5),hjust=1,vjust=0.5, family="Arial", face="bold",colour="black"),
            axis.text.x = element_text(size = 14, margin = margin(t = 5),hjust=0.5,vjust=1, family="Arial", face="bold",colour="black"), 
            axis.title.y = element_text(size = 16, margin = margin(r = 10),angle = 90,hjust=0.5,vjust=0.5, family="Arial", face="bold"),
            axis.title.x = element_text(size = 16, margin = margin(t = 10),hjust=0.5,vjust=1, family="Arial", face="bold"),
            legend.text=element_text(size=14, family="Arial", face="bold"),
            legend.title=element_blank(), 
            legend.key.size=unit(2.5,"line"),
            plot.margin=unit(c(0.4,0.4,0.4,0.4), "cm")
        )
}

##---- Default Three Way Sig and Non-sig Colours  ----##
default_significant_both_colour = "red"
default_significant_a_colour = "dodgerblue3"
default_significant_b_colour = "forestgreen"
default_non_significant_colour = "black"

##---- Save Plot Function -----##
save_plot <- function(ggp,plot_height,plot_width,plot_path)
{
  png(plot_path, height=plot_height, width=plot_width, pointsize=5)
  print(ggp)
  dev.off()

  # clears all devices - as a safety measure
  while (dev.cur()>1) dev.off()
}

##----- Fold vs Fold Scatterplot Function -----##
make_fold_vs_fold_scatterplot <- function(comparison1,comparison2,colours,dot_size,dot_transparency,significant_name,non_significant_name,x_axis_label,y_axis_label,legend_position,data_label_size) 
{

  # gets the names of the columns that indicate significance
  sig_genes_rownames = data.frame(matrix(ncol=2, nrow=0), check.names=TRUE)
  colnames(sig_genes_rownames) = paste(c(comparison1,comparison2),"_sig",sep="")
  sig_genes_rownames = colnames(data.frame(sig_genes_rownames, check.names=TRUE))
  
  # gets the names of the columns that indicate fold change
  fold_change_rownames = data.frame(matrix(ncol=2, nrow=0), check.names=TRUE)
  colnames(fold_change_rownames) = paste(c(comparison1,comparison2),"_log2fold",sep="")
  fold_change_rownames = colnames(data.frame(fold_change_rownames, check.names=TRUE))
  
  # gets the sig flags
  sig_flags = character(nrow(Mde_annotated))
  
  for(index in 1:nrow(Mde_annotated))
  {
    if(Mde_annotated[[sig_genes_rownames[1]]][index] == "True" & Mde_annotated[[sig_genes_rownames[2]]][index] == "True") {sig_flags[index] = "sig both"}
    else if(Mde_annotated[[sig_genes_rownames[1]]][index] == "True" & Mde_annotated[[sig_genes_rownames[2]]][index] == "False") {sig_flags[index] = paste("sig ",comparison1, " only",sep="")}
    else if(Mde_annotated[[sig_genes_rownames[1]]][index] == "False" & Mde_annotated[[sig_genes_rownames[2]]][index] == "True") {sig_flags[index] = paste("sig ",comparison2, " only",sep="")}
    else {sig_flags[index] = "not sig"}
  }
  breaks = c("sig both",paste("sig ",comparison1, " only",sep=""),paste("sig ",comparison2, " only",sep=""),"not sig")
  sig_flags = factor(sig_flags, levels = breaks)
  
  # gets the correlation
  correlation <- cor.test(x=Mde_annotated[[fold_change_rownames[1]]], y=Mde_annotated[[fold_change_rownames[2]]], method = 'spearman')
  rr <- correlation$estimate
  formated_rr <- format(rr,digits = 2)
  title <- paste0("Spearman correlation coefficient = ",as.character(formated_rr))

  ggp = ggplot(data=Mde_annotated, aes(x=Mde_annotated[[fold_change_rownames[1]]], y=Mde_annotated[[fold_change_rownames[2]]], group=sig_flags,colour=sig_flags,fill=sig_flags)) + geom_point(size=dot_size,alpha=dot_transparency) + ggtitle(title) + xlab(x_axis_label) + ylab(y_axis_label) + theme_SL2() + theme(legend.position=legend_position, legend.title = element_blank()) + scale_color_manual(values=colours,breaks=breaks,labels=breaks) + scale_fill_manual(values=colours,breaks=breaks,labels=breaks) + geom_text(data=Mde_annotated,aes(label=rownames(Mde_annotated)),hjust=-0.1, vjust=-0.1, size=data_label_size, show.legend = FALSE)
  
  return(ggp)
}

##----- Fold vs Fold Scatterplot -----##

colours = c(default_significant_both_colour,default_significant_a_colour,default_significant_b_colour,default_non_significant_colour)
dot_size = 1.5
plot_height = 600
plot_width = 600
dot_transparency = 1
legend_position = "bottom"
data_label_size = 4.5

for(index1 in 1:length(comparisons))
{  
  for(index2 in index1:length(comparisons))
  {
    if(index1 != index2) 
    {
      comparison1 = comparisons[index1]
      comparison2 = comparisons[index2]
      data_label_size = 4.5
      x_axis_label = paste(comparison1," log2fold",sep="")
      y_axis_label = paste(comparison2," log2fold",sep="")
      ggp = make_fold_vs_fold_scatterplot(comparison1,comparison2,colours,dot_size,dot_transparency,significant_name,non_significant_name,x_axis_label,y_axis_label,legend_position,data_label_size)
      save_plot(ggp,plot_height,plot_width,paste("plots/fold_vs_fold_scatterplots/",gsub(" vs ", "_vs_", comparison1),"_VS_",gsub(" vs ", "_vs_", comparison2),"_labelled.png",sep=""))
      
      data_label_size = 0
      ggp = make_fold_vs_fold_scatterplot(comparison1,comparison2,colours,dot_size,dot_transparency,significant_name,non_significant_name,x_axis_label,y_axis_label,legend_position,data_label_size)
      save_plot(ggp,plot_height,plot_width,paste("plots/fold_vs_fold_scatterplots/",gsub(" vs ", "_vs_", comparison1),"_VS_",gsub(" vs ", "_vs_", comparison2),"_unlabelled.png",sep=""))
    }
  }
}

