##---- general libraries ----##
library(ggplot2)
library(reshape)

##---- Mde sample and group names ----##
samples = c("KO_R1","KO_R2","KO_R3","WT_R1","WT_R2","WT_R3","KO_RESCUE_R1","KO_RESCUE_R2","KO_RESCUE_R3")
sample_groups = c("KO","WT","KO_RESCUE")
sample_groupings = c("KO","KO","KO","WT","WT","WT","KO_RESCUE","KO_RESCUE","KO_RESCUE")
sample_groupings = factor(sample_groupings, levels = sample_groups)
samples_by_sample_group = list(c("KO_R1","KO_R2","KO_R3"),c("WT_R1","WT_R2","WT_R3"),c("KO_RESCUE_R1","KO_RESCUE_R2","KO_RESCUE_R3"))
comparisons = c("KO vs WT","KO_RESCUE vs KO")

##---- sets the working directory. If you move the SL2 folder please update this path ----##
setwd("/home/john/Downloads/TEMP/DESEQ2/results/all_genes/mde_workflows/all")

##---- Mde input files ----##
Mde_annotated = read.table(file="data/all_genes_annotated.csv", header=TRUE,row.names = 2, sep='\t', quote='',check.names = TRUE)
Mde_annotated_sig_any = read.table(file="data/genes_significant_in_any_des_annotated.csv", header=TRUE,row.names = 2, sep='\t', quote='',check.names = TRUE)
Mde_annotated_sig_all = read.table(file="data/genes_significant_in_all_des_annotated.csv", header=TRUE,row.names = 2, sep='\t', quote='',check.names = TRUE)

##---- SL2 Theme ----##
theme_SL2 <- function () { 
    theme_bw() %+replace% 
        theme(
	    panel.grid = element_blank(),
            panel.background = element_blank(),
            panel.border = element_rect(colour = "black", fill=NA, size=1),
            plot.background = element_blank(), 
            legend.background = element_rect(fill="transparent", colour=NA),
            legend.key = element_rect(fill="transparent", colour=NA),
            plot.title = element_text(size=16, margin = margin(b = 5),hjust=0,vjust=0.5, family="Arial", face="bold"),
            title = element_text(size = 16, margin = margin(b = 5),hjust=0,vjust=0.5, family="Arial", face="bold"),
            axis.text.y = element_text(size = 14, margin = margin(r = 5),hjust=1,vjust=0.5, family="Arial", face="bold",colour="black"),
            axis.text.x = element_text(size = 14, margin = margin(t = 5),hjust=0.5,vjust=1, family="Arial", face="bold",colour="black"), 
            axis.title.y = element_text(size = 16, margin = margin(r = 10),angle = 90,hjust=0.5,vjust=0.5, family="Arial", face="bold"),
            axis.title.x = element_text(size = 16, margin = margin(t = 10),hjust=0.5,vjust=1, family="Arial", face="bold"),
            legend.text=element_text(size=14, family="Arial", face="bold"),
            legend.title=element_blank(), 
            legend.key.size=unit(2.5,"line"),
            plot.margin=unit(c(0.4,0.4,0.4,0.4), "cm")
        )
}

##---- Default Two Tone Greyscale  ----##
default_two_tone_greyscale = c("grey75","grey50")

##---- Default Comaparison Labels  ----##
default_comparison_labels = c("KO vs WT","KO_RESCUE vs KO") # note: changing this won't change the order the comparisons appear on the plots. Merely what they are labelled as.

##---- Save Plot Function -----##
save_plot <- function(ggp,plot_height,plot_width,plot_path)
{
  png(plot_path, height=plot_height, width=plot_width, pointsize=5)
  print(ggp)
  dev.off()

  # clears all devices - as a safety measure
  while (dev.cur()>1) dev.off()
}

##----- Number of Significant Genes Barchart Function -----##
make_number_of_significant_genes_barchart <- function(x_axis_label,y_axis_label,comparison_labels,direction_labels,bar_colours,legend_position,data_label_size,bar_outline_size) 
{

  # gets the names of the columns that indicate significance
  sig_genes_rownames = data.frame(matrix(ncol=length(comparisons), nrow=0), check.names=TRUE)
  colnames(sig_genes_rownames) = paste(comparisons,"_sig",sep="")
  sig_genes_rownames = colnames(data.frame(sig_genes_rownames, check.names=TRUE))
  
  # gets the names of the columns that indicate fold change
  fold_change_rownames = data.frame(matrix(ncol=length(comparisons), nrow=0), check.names=TRUE)
  colnames(fold_change_rownames) = paste(comparisons,"_log2fold",sep="")
  fold_change_rownames = colnames(data.frame(fold_change_rownames, check.names=TRUE))
  
  # gets the sig counts
  upregulated=c()
  downregulated=c() 
  for(index in 1:length(comparisons))
  {
  upregulated[index] = nrow(subset(Mde_annotated,Mde_annotated[[sig_genes_rownames[index]]] == "True" & Mde_annotated[[fold_change_rownames[index]]] > 0))
  downregulated[index] = nrow(subset(Mde_annotated,Mde_annotated[[sig_genes_rownames[index]]] == "True" & Mde_annotated[[fold_change_rownames[index]]] < 0))
  }
  
  dat <- data.frame(
    comparison = factor(default_comparison_labels, levels=default_comparison_labels),
    upregulated = upregulated,
    downregulated = downregulated
  )

  dat.m <- melt(dat, id.vars = "comparison")
  ggp = ggplot(data=dat.m , aes(x=comparison, y=value, fill=variable)) + geom_bar(colour="black", stat="identity", position = "dodge", size=bar_outline_size) + xlab(x_axis_label) + ylab(y_axis_label) + theme_SL2() + geom_text(aes(label=value), position=position_dodge(width=0.9), size=data_label_size, show.legend = FALSE, vjust=2) + scale_color_manual(values=bar_colours,labels=direction_labels) + scale_fill_manual(values=bar_colours,labels=direction_labels) + scale_x_discrete(labels=comparison_labels) + theme(legend.position=legend_position, legend.spacing.x = unit(0.25, 'cm'), axis.text.x = element_text(angle = 45, hjust = 1)) + scale_y_continuous(expand=c(0,0), limits=c(0,max(dat.m$value*1.1)))
  return(ggp)
}

##----- Number of Significant Genes Barchart -----##

plot_height = 500
plot_width = 750
x_axis_label = ""
y_axis_label = "number of significant genes"
comparison_labels = default_comparison_labels # note: changing this won't change the order the comparisons appear in the x axis. Merely what they are labelled as.
direction_labels = c("up","down") # note: changing this won't change the order the bars appear in the x axis. Merely what they are labelled as.
bar_colours = default_two_tone_greyscale # note: changing this won't change the order the bars appear in the x axis. Merely what they are coloured as.
legend_position = "bottom"
data_label_size = 5
bar_outline_size = 1

ggp = make_number_of_significant_genes_barchart(x_axis_label,y_axis_label,comparison_labels,direction_labels,bar_colours,legend_position,data_label_size,bar_outline_size)
save_plot(ggp,plot_height,plot_width,"plots/number_of_significant_genes/number_of_significant_genes_barchart.png")

