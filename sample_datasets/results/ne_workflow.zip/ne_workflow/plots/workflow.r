###################################
##         Searchlight 2         ##
###################################



#############################
##    ne workflow     ##
#############################



##-------------------------##
##       R libraries       ##
##-------------------------##



##---- general libraries ----##
library(ggplot2)
library(reshape)


##---- heatmap libraries ----##
library(amap)


##---- table libraries ----##
library(grid)
library(gridExtra)
library(gtable)



##-------------------------##
##     Core Parameters     ##
##-------------------------##



##---- ne sample and group names ----##
samples = c("WT_R1","WT_R2","WT_R3","KO_R1","KO_R2","KO_R3","KO_RESCUE_R1","KO_RESCUE_R2","KO_RESCUE_R3")
sample_groups = c("WT","KO","KO_RESCUE")
sample_groupings = c("WT","WT","WT","KO","KO","KO","KO_RESCUE","KO_RESCUE","KO_RESCUE")
sample_groupings = factor(sample_groupings, levels = sample_groups)
samples_by_sample_group = list(c("WT_R1","WT_R2","WT_R3"),c("KO_R1","KO_R2","KO_R3"),c("KO_RESCUE_R1","KO_RESCUE_R2","KO_RESCUE_R3"))
sample_groups_by_SS_column = list(c("WT","KO","KO_RESCUE"))
sample_groupings_by_SS_column = list(c("WT","WT","WT","KO","KO","KO","KO_RESCUE","KO_RESCUE","KO_RESCUE"))
sample_sheet_column_names = c("sample_group")



##-------------------------##
##       Input Files       ##
##-------------------------##



##---- sets the working directory. If you move the SL2 folder please update this path ----##
setwd("/home/john/Downloads/TEMP/DESEQ2/results/all_genes/ne_workflow")


##---- ne input files ----##
ne_file = read.table(file="data/ne_matrix_symbols.csv", header=TRUE,row.names = 1, sep='\t', quote='',check.names = TRUE)



##-------------------------##
##       Parsed Data       ##
##-------------------------##



##---- parse ne matrix ----##
ne_matrix = ne_file[,samples]


##---- transpose and scale ne matrix ----##
ne_matrix_transposed = data.frame(t(ne_matrix))
colnames(ne_matrix_transposed) = rownames(ne_matrix)

ne_matrix_scaled = data.frame(t(scale(t(ne_matrix))))
rownames(ne_matrix_scaled) = rownames(ne_matrix)
ne_matrix_scaled[do.call(cbind, lapply(ne_matrix_scaled, is.nan))] <- 0
ne_matrix_scaled = ne_matrix_scaled[is.finite(rowSums(ne_matrix_scaled)), ]

ne_matrix_scaled_transposed = data.frame(t(ne_matrix_scaled))
colnames(ne_matrix_scaled_transposed) = rownames(ne_matrix_scaled)


##---- transpose and scale ne matrix across all SS columns ----##
ne_matrix_all_SS_columns = ne_matrix[,cbind(unlist(samples_by_sample_group))]
ne_matrix_all_SS_columns_transposed = data.frame(t(ne_matrix_all_SS_columns))
colnames(ne_matrix_all_SS_columns_transposed) = rownames(ne_matrix_all_SS_columns)

ne_matrix_all_SS_columns_scaled = data.frame(t(scale(t(ne_matrix_all_SS_columns))))
rownames(ne_matrix_all_SS_columns_scaled) = rownames(ne_matrix_all_SS_columns)
ne_matrix_all_SS_columns_scaled[do.call(cbind, lapply(ne_matrix_all_SS_columns_scaled, is.nan))] <- 0
ne_matrix_all_SS_columns_scaled = ne_matrix_all_SS_columns_scaled[is.finite(rowSums(ne_matrix_all_SS_columns_scaled)), ]

ne_matrix_all_SS_columns_scaled_transposed = data.frame(t(ne_matrix_all_SS_columns_scaled))
colnames(ne_matrix_all_SS_columns_scaled_transposed) = rownames(ne_matrix_all_SS_columns_scaled)



##-------------------------##
##   Default Aesthetics    ##
##-------------------------##



##---- SL2 Theme ----##
theme_SL2 <- function () { 
    theme_bw() %+replace% 
        theme(
	    panel.grid = element_blank(),
            panel.background = element_blank(),
            panel.border = element_rect(colour = "black", fill=NA, size=1),
            plot.background = element_blank(), 
            legend.background = element_rect(fill="transparent", colour=NA),
            legend.key = element_rect(fill="transparent", colour=NA),
            plot.title = element_text(size=16, margin = margin(b = 5),hjust=0,vjust=0.5, family="Arial", face="bold"),
            title = element_text(size = 16, margin = margin(b = 5),hjust=0,vjust=0.5, family="Arial", face="bold"),
            axis.text.y = element_text(size = 14, margin = margin(r = 5),hjust=1,vjust=0.5, family="Arial", face="bold",colour="black"),
            axis.text.x = element_text(size = 14, margin = margin(t = 5),hjust=0.5,vjust=1, family="Arial", face="bold",colour="black"), 
            axis.title.y = element_text(size = 16, margin = margin(r = 10),angle = 90,hjust=0.5,vjust=0.5, family="Arial", face="bold"),
            axis.title.x = element_text(size = 16, margin = margin(t = 10),hjust=0.5,vjust=1, family="Arial", face="bold"),
            legend.text=element_text(size=14, family="Arial", face="bold"),
            legend.title=element_blank(), 
            legend.key.size=unit(2.5,"line"),
            plot.margin=unit(c(0.4,0.4,0.4,0.4), "cm")
        )
}


##----- Default GGplot Colours Function -----##
gg_color_hue <- function(n) {
  hues = seq(15, 375, length = n + 1)
  hcl(h = hues, l = 65, c = 100)[1:n]
}


##---- Default Sample and Sample Group Colours by SS Column ----##
number_of_sample_groups = length(sample_groups)
default_sample_group_colours = gg_color_hue(number_of_sample_groups)
default_sample_group_colours_by_SS_column = list(default_sample_group_colours[1:3])
default_samples_colours_by_SS_column = list(c(default_sample_group_colours[1],default_sample_group_colours[1],default_sample_group_colours[1],default_sample_group_colours[2],default_sample_group_colours[2],default_sample_group_colours[2],default_sample_group_colours[3],default_sample_group_colours[3],default_sample_group_colours[3]))
default_samples_colours = default_samples_colours_by_SS_column[1]


##---- Default Sample Labels  ----##
default_sample_labels = c("WT_R1","WT_R2","WT_R3","KO_R1","KO_R2","KO_R3","KO_RESCUE_R1","KO_RESCUE_R2","KO_RESCUE_R3") # note: changing this won't change the order the samples appear on the plots. Merely what they are labelled as. 


##---- Default Sample Group Labels  ----##
default_sample_group_labels = c("WT","KO","KO_RESCUE") # note: changing this won't change the order the groups appear on the plots. Merely what they are labelled as.


##---- Default Three Tone Heatmap Colours  ----##
default_three_tone_heatmap_colours = c("blue","pink","red")



##-------------------------##
##     Helper Functions    ##
##-------------------------##



##---- Save Plot Function -----##
save_plot <- function(ggp,plot_height,plot_width,plot_path)
{
  png(plot_path, height=plot_height, width=plot_width, pointsize=5)
  print(ggp)
  dev.off()

  # clears all devices - as a safety measure
  while (dev.cur()>1) dev.off()
}


##----- Clustering Method -----##
cluster_matrix <- function(mx,cluster_x,cluster_y,distance_method,clustering_method,reorder_function)
{
  x.cluster = hclust(Dist(t(mx), method=distance_method), method=clustering_method)
  y.cluster = hclust(Dist(mx, method=distance_method), method=clustering_method)
  
  x.dd = as.dendrogram(x.cluster)
  y.dd = as.dendrogram(y.cluster)
  x.dd.reorder = reorder(x.dd,0,FUN=reorder_function)
  y.dd.reorder = reorder(y.dd,0,FUN=reorder_function)
  x.order = order.dendrogram(x.dd.reorder)
  y.order = order.dendrogram(y.dd.reorder)

  if(cluster_x == TRUE && cluster_y == TRUE) 
  {
      mx_clustered = mx[y.order,x.order]
  }
  
  if(cluster_x == TRUE && cluster_y == FALSE)
  {
      mx_clustered = mx[,x.order]
  }
  
  if(cluster_x == FALSE && cluster_y == TRUE)
  {
      mx_clustered = mx[y.order,]
  }
  if(cluster_x == FALSE && cluster_y == FALSE) 
  {
      mx_clustered = mx
  }
  return(mx_clustered)
}


##---- Save Table Function -----##
save_table <- function(gt,plot_height,plot_width,plot_path)
{
  png(plot_path, height=plot_height, width=plot_width, pointsize=5)
  grid.arrange(gt)
  dev.off()

  while (dev.cur()>1) dev.off()
}


##---- Top 10 Genes by Mean Expression Function ----##
get_top_10_genes_by_mean_expression <- function(index) {
  samples_in_sample_group = unlist(samples_by_sample_group[index])
  top_10_genes = row.names(head(ne_matrix[order(rowMeans(ne_matrix[,samples_in_sample_group]),decreasing=TRUE),],10))
  return(top_10_genes)
}



##-------------------------##
##      Plot Functions     ##
##-------------------------##



##----- Distribution of Expression Values Function -----##
make_distribution_of_expression_values_plot <- function(plot_sample,plot_colour,transparency,line_thickness,x_axis_label,y_axis_label,legend_position) 
{
  ggp = ggplot(ne_matrix, aes(log(x=ne_matrix[[plot_sample]]+0.001,10))) + geom_density(colour=plot_colour,fill=plot_colour, alpha=transparency,size=line_thickness) + xlab(x_axis_label) + ylab(y_axis_label) + ggtitle(plot_sample) + theme_SL2() + theme(legend.position=legend_position) + scale_x_continuous(expand=c(0,0)) + scale_y_continuous(expand=c(0,0))
  return(ggp)
}


##----- PCA Contribution of Components Function -----##
make_PCA_contribution_of_components_plot <- function(x_axis_label,y_axis_label,dot_size,dot_transparency,dot_colour,line_type,line_colour,line_size)
{

prcomp_data = prcomp(as.matrix(sapply(ne_matrix_scaled_transposed, as.numeric)))
vars = apply(prcomp_data$x, 2, var)
prcomp_props = data.frame(round(vars / sum(vars),4) * 100)
prcomp_props$PC = row.names(prcomp_props)
colnames(prcomp_props) = c("prop","PC")
prcomp_props$PC = factor(prcomp_props$PC, levels = row.names(prcomp_props))
ggp = ggplot(data=prcomp_props,aes(x=PC,y=prop,group=1)) + geom_line(linetype=line_type,colour=line_colour,size=line_size) + geom_point(size=dot_size,alpha=dot_transparency,colour=dot_colour) + xlab(x_axis_label) + ylab(y_axis_label) + theme_SL2() + theme(legend.position="None", legend.title = element_blank())                                              

return(ggp)
}


##----- PCA Scatter Plot Function -----##
make_PCA_scatterplot <- function(plot_sample_groupings,component_x,component_y,x_axis_label,y_axis_label,plot_sample_group_colours,plot_sample_group_labels,plot_sample_labels,dot_size,dot_transparency,legend_position,sample_label_size,show_proportion_of_variance)
{

  prcomp_data = prcomp(as.matrix(sapply(ne_matrix_scaled_transposed, as.numeric)))
  prcomp_coordinates = data.frame(prcomp_data$x)
    
  if (show_proportion_of_variance == TRUE) 
  {
    vars = apply(prcomp_data$x, 2, var)
    prop_x = round(vars[component_x] / sum(vars),4) * 100
    prop_y = round(vars[component_y] / sum(vars),4) * 100
    
    x_axis_label = paste(x_axis_label, " (",prop_x,"%)",sep="")
    y_axis_label = paste(y_axis_label, " (",prop_y,"%)",sep="")
  }
  
  ggp = ggplot(data=prcomp_coordinates, aes(x=prcomp_coordinates[,component_x], y=prcomp_coordinates[,component_y], colour=plot_sample_groupings, group=plot_sample_groupings,fill=plot_sample_groupings)) + geom_point(size=dot_size,alpha=dot_transparency) + scale_color_manual(values=plot_sample_group_colours,labels=plot_sample_group_labels, breaks=sample_groups) + scale_fill_manual(values=plot_sample_group_colours,labels=plot_sample_group_labels, breaks=sample_groups) + xlab(x_axis_label) + ylab(y_axis_label) + theme_SL2() + theme(legend.position=legend_position, legend.title = element_blank(), legend.spacing.x = unit(0.25, 'cm')) + geom_text(data=prcomp_coordinates,aes(label=plot_sample_labels),hjust=0.5, vjust=-1, size=sample_label_size, show.legend = FALSE) + xlim(c(min(prcomp_coordinates[,component_x])*1.25,max(prcomp_coordinates[,component_x])*1.25)) + ylim(c(min(prcomp_coordinates[,component_y])*1.25,max(prcomp_coordinates[,component_y])*1.25))                                                 
  return(ggp) 
}


##----- Correlation Analysis Heatmap Function  -----##
make_correlation_analysis_heatmap <- function(colours,sample_names,cluster_x,cluster_y,distance_method,clustering_method,reorder_function)
{
  ne_matrix_scaled_correlated = cor(ne_matrix_scaled,method="spearman")
  row.names(ne_matrix_scaled_correlated) = sample_names
  colnames(ne_matrix_scaled_correlated) = sample_names
  
  ne_matrix_scaled_correlated_clustered = cluster_matrix(ne_matrix_scaled_correlated,cluster_x,cluster_y,distance_method,clustering_method,reorder_function)
  ne_matrix_scaled_correlated_clustered_melted <- melt(ne_matrix_scaled_correlated_clustered)
  ne_matrix_scaled_correlated_clustered_melted$X1 = factor(ne_matrix_scaled_correlated_clustered_melted$X1, levels=colnames(ne_matrix_scaled_correlated_clustered))
  ne_matrix_scaled_correlated_clustered_melted$X2 = factor(ne_matrix_scaled_correlated_clustered_melted$X2, levels=row.names(ne_matrix_scaled_correlated_clustered))

  ggp = ggplot(ne_matrix_scaled_correlated_clustered_melted, aes(x = X1, y = X2, fill = value)) + geom_tile() + scale_fill_gradientn(limits=c(-1, 1),colours = colorRampPalette(colours)(100)) + ylab('') + xlab('') + theme_SL2() + theme(legend.position="right", legend.title = element_blank(), legend.spacing.x = unit(0.25, 'cm'),axis.text.x = element_text(angle = 90, hjust = 1), axis.ticks=element_blank()) + scale_x_discrete(expand=c(0,0)) + scale_y_discrete(expand=c(0,0))
  return(ggp)
}


##----- Most Expressed Genes Table Function  -----##
make_most_expressed_genes_table <- function(top_10_genes,header_size,text_size,border_thickness)
{
  ne_matrix_top_10 = ne_matrix[top_10_genes,]
  mean_matrix_top_10 = ne_matrix_top_10[,0]
  mean_matrix_top_10$Gene = rownames(mean_matrix_top_10)
  for (index in 1:length(sample_groups))
  { 
    mean_matrix_top_10[[sample_groups[index]]] = round(rowMeans(ne_matrix_top_10[,unlist(samples_by_sample_group[index])]),2)
  }

  table_theme <- gridExtra::ttheme_minimal(core = list(fg_params=list(cex = text_size)),colhead = list(fg_params=list(cex = header_size)))

  gt <- tableGrob(mean_matrix_top_10, theme=table_theme, rows=NULL)
  gt <- gtable_add_grob(gt,grobs = rectGrob(gp = gpar(fill = NA, lwd = border_thickness)),t = 2, b = nrow(gt), l = 1, r = ncol(gt))
  gt <- gtable_add_grob(gt,grobs = rectGrob(gp = gpar(fill = NA, lwd = border_thickness)),t = 1, l = 1, r = ncol(gt))
  gt <- gtable_add_grob(gt,grobs = rectGrob(gp = gpar(fill = NA, lwd = border_thickness)),t = 1, b = nrow(gt), l = 1, r = 1)
}


##----- Gene Expression Violin Plot Function  -----##
make_gene_expression_violin_plot <- function(matrix,gene,violin_transparency,violin_width,violin_line_thickness,violin_colours,violin_labels,trim_violin,jitter_dot_size,jitter_dot_colour,jitter_dot_width,summary_colour,summary_size,x_axis_label,y_axis_label,legend_position)
{
  ggp = ggplot(matrix, aes(x=sample_groupings, y=matrix[[gene]], color=sample_groupings, group=sample_groupings, fill=sample_groupings)) + geom_violin(trim=trim_violin, scale="width", width=violin_width, alpha = violin_transparency, size=violin_line_thickness) + geom_jitter(size=jitter_dot_size, colour=jitter_dot_colour, width=jitter_dot_width, height=0, show.legend = FALSE) + stat_summary(position=position_dodge(0.75), colour = summary_colour, size = summary_size, geom="pointrange", show.legend = FALSE) + scale_color_manual(values=violin_colours,breaks=sample_groups,labels=violin_labels,limits=sample_groups) + scale_fill_manual(values=violin_colours,breaks=sample_groups,labels=violin_labels,limits=sample_groups) + scale_x_discrete(breaks=sample_groups,labels=violin_labels,limits=sample_groups) + ylim(0, max(matrix[[gene]] * 1.25)) + xlab(x_axis_label) + ylab(y_axis_label) + ggtitle(gene) + theme_SL2() + theme(legend.position=legend_position, axis.text.x = element_text(angle = 45, hjust = 1))
  return(ggp)
}



##-------------------------##
##          Plots          ##
##-------------------------##



##----- Distribution of Expression Values -----##

plot_height = 250
plot_width = 250
transparency = 0.5
line_thickness = 1
x_axis_label = "expression (log10)"
y_axis_label = "density"
legend_position = "none"

for(plot_sample_index in 1:length(samples))
{
  plot_sample = samples[plot_sample_index]
  plot_colour = unlist(default_samples_colours[1])[plot_sample_index]
  ggp = make_distribution_of_expression_values_plot(plot_sample,plot_colour,transparency,line_thickness,x_axis_label,y_axis_label,legend_position)
  save_plot(ggp,plot_height,plot_width,paste("plots/distribution_of_expression_values/",plot_sample,"_distribution_of_expression_values.png",sep=""))
}


##----- PCA (Contribution of Components) -----##

plot_height = 300
plot_width = 400
x_axis_label = "component"
y_axis_label = "proportion of variance (%)"
dot_size = 4
dot_transparency = 1
dot_colour = "red"
line_type = "solid"
line_colour = "black"
line_size = 1

ggp = make_PCA_contribution_of_components_plot(x_axis_label,y_axis_label,dot_size,dot_transparency,dot_colour,line_type,line_colour,line_size)
save_plot(ggp,plot_height,plot_width,"plots/PCA/PCA_contribution_of_components.png")


##----- PCA (Scatter Plots) -----##

plot_height = 400
plot_width = 400
dot_size = 4
dot_transparency = 1
legend_position = "bottom"
show_proportion_of_variance = TRUE
plot_sample_group_labels = default_sample_group_labels
plot_sample_labels = default_sample_labels


for(index in 1:length(sample_sheet_column_names))
{
  plot_sample_groupings = unlist(sample_groupings_by_SS_column[index])
  plot_sample_groupings = factor(plot_sample_groupings, levels = sample_groups)
  plot_sample_group_colours = unlist(default_sample_group_colours_by_SS_column[index])

  component_x = 1
  component_y = 2
  x_axis_label = "PC1"
  y_axis_label = "PC2"
  sample_label_size = 4.5
  ggp = make_PCA_scatterplot(plot_sample_groupings,component_x,component_y,x_axis_label,y_axis_label,plot_sample_group_colours,plot_sample_group_labels,plot_sample_labels,dot_size,dot_transparency,legend_position,sample_label_size,show_proportion_of_variance)
  save_plot(ggp,plot_height,plot_width,paste("plots/PCA/",sample_sheet_column_names[index],"_PCA_1_vs_PCA_2_scatter_plot_labelled.png",sep=""))

  sample_label_size = 0 
  ggp = make_PCA_scatterplot(plot_sample_groupings,component_x,component_y,x_axis_label,y_axis_label,plot_sample_group_colours,plot_sample_group_labels,plot_sample_labels,dot_size,dot_transparency,legend_position,sample_label_size,show_proportion_of_variance)
  save_plot(ggp,plot_height,plot_width,paste("plots/PCA/",sample_sheet_column_names[index],"_PCA_1_vs_PCA_2_scatter_plot_unlabelled.png",sep=""))

  component_x = 3
  component_y = 4
  x_axis_label = "PC3"
  y_axis_label = "PC4"
  sample_label_size = 4.5
  ggp = make_PCA_scatterplot(plot_sample_groupings,component_x,component_y,x_axis_label,y_axis_label,plot_sample_group_colours,plot_sample_group_labels,plot_sample_labels,dot_size,dot_transparency,legend_position,sample_label_size,show_proportion_of_variance)
  save_plot(ggp,plot_height,plot_width,paste("plots/PCA/",sample_sheet_column_names[index],"_PCA_3_vs_PCA_4_scatter_plot_labelled.png",sep=""))

  sample_label_size = 0
  ggp = make_PCA_scatterplot(plot_sample_groupings,component_x,component_y,x_axis_label,y_axis_label,plot_sample_group_colours,plot_sample_group_labels,plot_sample_labels,dot_size,dot_transparency,legend_position,sample_label_size,show_proportion_of_variance)
  save_plot(ggp,plot_height,plot_width,paste("plots/PCA/",sample_sheet_column_names[index],"_PCA_3_vs_PCA_4_scatter_plot_unlabelled.png",sep=""))

}


##----- Correlation Analysis Heatmap -----##

plot_height = 600
plot_width = 750
colours = default_three_tone_heatmap_colours
sample_names = default_sample_labels
distance_method = "spearman"
clustering_method = "average"
reorder_function = "average"
cluster_x = FALSE
cluster_y = FALSE

ggp = make_correlation_analysis_heatmap(colours,sample_names,cluster_x,cluster_y,distance_method,clustering_method,reorder_function)
save_plot(ggp,plot_height,plot_width,"plots/correlation_analysis/correlation_analysis_heatmap.png")

cluster_x = TRUE
cluster_y = TRUE
ggp = make_correlation_analysis_heatmap(colours,sample_names,cluster_x,cluster_y,distance_method,clustering_method,reorder_function)
save_plot(ggp,plot_height,plot_width,"plots/correlation_analysis/correlation_analysis_heatmap_clustered.png")


##----- Most Expressed Genes (Tables) -----##

plot_height = 300
plot_width = 750
header_size = 1.25
text_size = 1.25
border_thickness = 2

for(sample_group_index in 1:length(sample_groups))
{
  sample_group = sample_groups[sample_group_index]
  top_10_genes = get_top_10_genes_by_mean_expression(sample_group_index)
  gt = make_most_expressed_genes_table(top_10_genes,header_size,text_size,border_thickness)
  save_table(gt,plot_height,plot_width,paste("plots/most_expressed_genes/",sample_group,"_most_expressed_genes_table.png",sep=""))
}


##----- Most Expressed Genes (Violin Plots) -----##

plot_height = 350
plot_width = 350
violin_transparency = 0.5
violin_width = 0.75
violin_line_thickness = 1
violin_colours = default_sample_group_colours 	# note: changing this won't change the order the groups appear in the x axis. Merely what they are coloured as.
violin_labels = default_sample_group_labels	# note: changing this won't change the order the groups appear in the x axis. Merely what they are named as.
trim_violin = FALSE
jitter_dot_size = 2
jitter_dot_colour = "black"
jitter_dot_width = 0.2
summary_colour = "red"
summary_size = 0.25
x_axis_label = ""
y_axis_label = "expression"
legend_position = "none"

for(sample_group_index in 1:length(sample_groups))
{
  sample_group = sample_groups[sample_group_index]
  top_10_genes = get_top_10_genes_by_mean_expression(sample_group_index)

  for (gene_index in 1:10)
  {
    gene = top_10_genes[gene_index]
    ggp = make_gene_expression_violin_plot(ne_matrix_all_SS_columns_transposed,gene,violin_transparency,violin_width,violin_line_thickness,violin_colours,violin_labels,trim_violin,jitter_dot_size,jitter_dot_colour,jitter_dot_width,summary_colour,summary_size,x_axis_label,y_axis_label,legend_position)
    save_plot(ggp,plot_height,plot_width,paste("plots/most_expressed_genes/",sample_group,"_no.",gene_index,"_most_expressed_gene.png",sep=""))
  }
}




##---- image and session info ----##
save.image("/home/john/Downloads/TEMP/DESEQ2/results/all_genes/ne_workflow/plots/workflow.rdata")
write.table(capture.output(sessionInfo()), file="/home/john/Downloads/TEMP/DESEQ2/results/all_genes/ne_workflow/plots/workflow_session_info.txt")
